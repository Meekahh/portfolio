package ca.dal.cs.csci3130.a3.access;

public class Patient extends AppUser{

    public Patient() {
        this.accessLevel = AccessLevel.patientAccessLevel;
    }

    @Override
    public AccessLevel getAccessLevel() {
        return this.accessLevel;
    }

    @Override
    public boolean canPlaceOnlineOrder() {
        return true;
    }

    @Override
    public boolean canSearchForPharmacist() {
        return true;
    }

    @Override
    public boolean canSearchForPatient() {
        return false;
    }

    @Override
    public boolean canSearchForOrder() {
        return false;
    }
}
