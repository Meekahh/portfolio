package ca.dal.cs.csci3130.a3.prescription;

import java.util.HashMap;

import ca.dal.cs.csci3130.a3.model.MedicineRepository;

public class BillingManager {
    Prescription prescription;
    HashMap<String, Integer> priceMap;

    public BillingManager() {
        this.priceMap = MedicineRepository.loadPriceMap();
    }

    public void setPrescription(Prescription prescription) {
        this.prescription = prescription;
    }

    protected int getRequestedCount() {
        return this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
    }

    public int calculateBill() {
        int requestedAmt = this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
        String medicine = this.prescription.getMedicineName();
        if (this.priceMap.containsKey(medicine)) {
            Integer price = this.priceMap.get(medicine);
            if (price != null) {
                return requestedAmt * price;
            }
        }
        return 0;
    }
}
