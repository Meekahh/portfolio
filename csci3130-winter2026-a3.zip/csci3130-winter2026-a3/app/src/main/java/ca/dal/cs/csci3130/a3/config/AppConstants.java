package ca.dal.cs.csci3130.a3.config;

public class AppConstants {

    public static final String PC_CARD = "PC";
    public static final String INITIAL_LOYALTY = "INITIAL_LOYALTY";
    public static final int INITIAL_PC_POINT = 1000;

    public static final String TRANSACTION_SUCCESSFUL = "Transaction successful";
    public static final String TRANSACTION_FAILED = "Transaction failed";

    public static final String PATIENT = "Patient";
    public static final String PHARMACIST = "Pharmacist";
    public static final String COURIER = "Courier";

    public static final String TYLENOL="Tylenol";
    public static final String ADVIL="Advil";
    public static final String MOTRIN="Motrin";
    public static final int LOW_STOCK_THRESHOLD=5;
    public static final String LOW_STOCK_MESSAGE="Low stock!";

}

