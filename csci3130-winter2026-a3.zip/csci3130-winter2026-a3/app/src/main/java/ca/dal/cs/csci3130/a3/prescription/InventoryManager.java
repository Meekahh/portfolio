package ca.dal.cs.csci3130.a3.prescription;

import java.util.HashMap;

import ca.dal.cs.csci3130.a3.config.AppConstants;
import ca.dal.cs.csci3130.a3.model.MedicineRepository;

public class InventoryManager {
    Prescription prescription;
    HashMap<String, Integer> inventory;

    public InventoryManager() {
        this.inventory = MedicineRepository.loadMedicineInventory();
    }

    public void setPrescription(Prescription prescription) {
        this.prescription = prescription;
    }

    protected int getRequestedCount() {
        return this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
    }

    protected boolean checkAvailability() {
        return this.inventory.containsKey(this.prescription.getMedicineName());
    }

    public boolean checkLowStock() {
        String medicine = this.prescription.getMedicineName();
        if (this.inventory.containsKey(medicine)) {
            Integer currentAmtInStock = this.inventory.get(medicine);
            if ((currentAmtInStock != null) && (currentAmtInStock < getRequestedCount())) {
                return true;
            }
        }

        return false;
    }

    public boolean updateInventory() {
        int totalRequested = this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
        String medicine = this.prescription.getMedicineName();
        if (this.inventory.containsKey(medicine)) {
            Integer currentCount = this.inventory.get(medicine);
            if (currentCount != null && totalRequested < currentCount) {
                currentCount = currentCount - totalRequested;
                this.inventory.put(medicine, currentCount);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
