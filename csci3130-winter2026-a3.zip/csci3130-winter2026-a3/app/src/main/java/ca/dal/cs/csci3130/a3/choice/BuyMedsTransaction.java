package ca.dal.cs.csci3130.a3.choice;


public class BuyMedsTransaction implements Transaction {

    int points2Buy;
    int MINIMUM_POINTS = 1000;

    public BuyMedsTransaction(int points2Buy) {
        this.points2Buy = points2Buy;
    }

    @Override
    public boolean performTransaction(ISmartPCCard card) {
        if (isLowPoints(card.getCurrentPoints())) {
            return false;
        }
        if (points2Buy > card.getCurrentPoints()) {
            return false;
        }

        card.setCurrentPoints(card.getCurrentPoints() - points2Buy);

        return true;
    }

    public boolean isLowPoints(int currentPoints) {
        return currentPoints < MINIMUM_POINTS;
    }


}
