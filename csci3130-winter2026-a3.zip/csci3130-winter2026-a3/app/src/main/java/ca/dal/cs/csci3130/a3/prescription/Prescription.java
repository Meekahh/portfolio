package ca.dal.cs.csci3130.a3.prescription;

public class Prescription {

    String medicineName;
    int dosePerDay;
    int numberOfDays;

    public Prescription(String medicineName, int dosePerDay, int numberOfDays) {
        this.medicineName = medicineName;
        this.dosePerDay = dosePerDay;
        this.numberOfDays = numberOfDays;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public int getDosePerDay() {
        return dosePerDay;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }
}
