package ca.dal.cs.csci3130.a3.notification;

import ca.dal.cs.csci3130.a3.config.AppConstants;

public class ReOrderService extends Observer {

    PrescriptionServiceTracker tracker;

    public ReOrderService(PrescriptionServiceTracker tracker) {
        this.tracker = tracker;
        this.tracker.attach(this);
    }

    @Override
    public void update(String message) {
        this.notification= message;
    }

    @Override
    public String getNotification() {
        return notification;
    }
}
