package ca.dal.cs.csci3130.a3.auth;

import ca.dal.cs.csci3130.a3.model.User;

public interface IUserRepository {
    public User findByEmail(String email);
}
