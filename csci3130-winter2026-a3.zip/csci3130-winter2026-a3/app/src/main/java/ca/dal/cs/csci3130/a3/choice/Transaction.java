package ca.dal.cs.csci3130.a3.choice;

public interface Transaction {
    public boolean performTransaction(ISmartPCCard card);
}
