package ca.dal.cs.csci3130.a3.access;

public class Courier extends AppUser{

    public Courier() {
        this.accessLevel = AccessLevel.courierAccessLevel;
    }

    @Override
    public AccessLevel getAccessLevel() {
        return this.accessLevel;
    }

    @Override
    public boolean canPlaceOnlineOrder() {
        return false;
    }

    @Override
    public boolean canSearchForPharmacist() {
        return false;
    }

    @Override
    public boolean canSearchForPatient() {
        return false;
    }

    @Override
    public boolean canSearchForOrder() {
        return true;
    }
}

