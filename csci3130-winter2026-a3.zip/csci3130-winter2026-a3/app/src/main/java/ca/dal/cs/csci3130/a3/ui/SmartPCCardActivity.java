package ca.dal.cs.csci3130.a3.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import ca.dal.cs.csci3130.a3.R;
import ca.dal.cs.csci3130.a3.choice.BuyMedsTransaction;
import ca.dal.cs.csci3130.a3.config.AppConstants;
import ca.dal.cs.csci3130.a3.choice.CashInTransaction;
import ca.dal.cs.csci3130.a3.choice.SmartPCPCCard;
import ca.dal.cs.csci3130.a3.choice.Transaction;
import ca.dal.cs.csci3130.a3.choice.TransferTransaction;
import ca.dal.cs.csci3130.a3.util.NumberUtility;

public class SmartPCCardActivity extends AppCompatActivity {

    public SmartPCPCCard smartPCCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pccard);
        this.loadSmartPCCard();
        this.showLoadedPCPoints();
        this.setupMakeTransactionButton();
    }

    protected int getPCPointFromSharedPref() {
        SharedPreferences sharedPreferences = getSharedPreferences(AppConstants.PC_CARD, MODE_PRIVATE);
        return sharedPreferences.getInt(AppConstants.INITIAL_LOYALTY, 0);
    }

    public void showLoadedPCPoints() {
        int points = this.smartPCCard.getCurrentPoints();
        TextView pointLabel = findViewById(R.id.currentPointLabel);
        pointLabel.setText(NumberUtility.format2Currency(points));
    }

    protected void showUpdatedPCPoints() {
        int points = (int) getUpdatePCPoints();
        TextView pointLabel = findViewById(R.id.currentPointLabel);
        pointLabel.setText(NumberUtility.format2Currency(points));
    }

    protected void loadSmartPCCard() {
        int points = getPCPointFromSharedPref();
        this.smartPCCard = new SmartPCPCCard(points);
    }

    protected int getPoint2Deduct() {
        EditText point2DeductBox = findViewById(R.id.point2DeductBox);
        return Integer.parseInt(point2DeductBox.getText().toString().trim());
    }

    protected Transaction getCashInTransaction(int point2Deduct) {
        return new CashInTransaction(point2Deduct);
    }

    protected Transaction getBuyMedsTransaction(int point2Deduct) {
        return new BuyMedsTransaction(point2Deduct);
    }

    protected Transaction getTransferTransaction() {
        SmartPCPCCard anotherCard = new SmartPCPCCard(0);
        return new TransferTransaction(anotherCard);
    }

    protected Transaction getSelectedTransaction() {
        RadioButton cashInButton = findViewById(R.id.cashInButton);
        RadioButton transferButton = findViewById(R.id.transferButton);
        RadioButton buyMedsButton = findViewById(R.id.buyMedsButton);

        if (cashInButton.isChecked()) {
            return getCashInTransaction(getPoint2Deduct());
        } else if (transferButton.isChecked()) {
            return getTransferTransaction();
        } else if (buyMedsButton.isChecked()) {
            return getBuyMedsTransaction(getPoint2Deduct());
        }
        return null;
    }

    protected boolean performTransaction() {
        Transaction transaction = getSelectedTransaction();
        if (transaction == null) {
            return false;
        }

        return this.smartPCCard.performTransaction(transaction);
    }

    protected double getUpdatePCPoints() {
        return this.smartPCCard.getCurrentPoints();
    }

    public void setupMakeTransactionButton() {
        Button makeTransaction = findViewById(R.id.makeTransactionButton);
        makeTransaction.setOnClickListener(view -> {
            if (performTransaction()) {
                showTransactionMessage(makeTransaction, AppConstants.TRANSACTION_SUCCESSFUL);
                showUpdatedPCPoints();
            } else {
                showTransactionMessage(makeTransaction, AppConstants.TRANSACTION_FAILED);
            }
        });
    }

    protected void showTransactionMessage(View view, String message) {
        Snackbar snackbar = Snackbar.make(view, message, Snackbar.LENGTH_LONG);
        snackbar.show();
    }
}