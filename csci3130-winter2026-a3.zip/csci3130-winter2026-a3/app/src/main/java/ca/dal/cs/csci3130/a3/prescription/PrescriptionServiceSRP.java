package ca.dal.cs.csci3130.a3.prescription;

public class PrescriptionServiceSRP {
    Prescription prescription;
    InventoryManager inventoryManager;
    BillingManager billingManager;

    public PrescriptionServiceSRP(Prescription prescription) {
        this.prescription = prescription;
    }

    public void setInventoryManager(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
        this.inventoryManager.setPrescription(this.prescription);
    }

    public void setBillingManager(BillingManager billingManager) {
        this.billingManager = billingManager;
        this.billingManager.setPrescription(this.prescription);
    }

    public boolean verifyPrescription() {
        if (this.prescription.numberOfDays > 0) {
            if (this.prescription.dosePerDay > 0) {
                return inventoryManager.checkAvailability();
            }
        }
        return false;
    }

    public boolean updateInventory() {
        return inventoryManager.updateInventory();
    }

    public int calculateBill() {
        return billingManager.calculateBill();
    }
}
