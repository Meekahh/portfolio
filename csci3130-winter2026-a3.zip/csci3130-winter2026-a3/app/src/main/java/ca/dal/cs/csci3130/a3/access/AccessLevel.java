package ca.dal.cs.csci3130.a3.access;

import ca.dal.cs.csci3130.a3.config.AppConstants;

public class AccessLevel {

    public static final AccessLevel patientAccessLevel = new AccessLevel(AppConstants.PATIENT);
    public static final AccessLevel pharmacistAccessLevel = new AccessLevel(AppConstants.PHARMACIST);
    public static final AccessLevel courierAccessLevel = new AccessLevel(AppConstants.COURIER);
    String userAccessLevel;

    public AccessLevel(String userAccessLevel) {
        this.userAccessLevel = userAccessLevel;
    }
}
