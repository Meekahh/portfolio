package ca.dal.cs.csci3130.a3.choice;

public class TransferTransaction implements Transaction {

    ISmartPCCard card;
    int MINIMUM_POINTS = 500;

    public TransferTransaction(ISmartPCCard anotherCard) {
        this.card = anotherCard;
    }

    @Override
    public boolean performTransaction(ISmartPCCard card) {
        if (isLowPoints(card.getCurrentPoints())) {
            return false;
        }

        this.card.setCurrentPoints(this.card.getCurrentPoints() + card.getCurrentPoints());
        card.setCurrentPoints(0);

        return true;
    }

    public boolean isLowPoints(int currentPoints) {
        return currentPoints < MINIMUM_POINTS;
    }
}
