package ca.dal.cs.csci3130.a3.model;


public class User {

    String email;
    String encodedPassword;
    String role;

    public User(String email, String encodedPassword, String role) {
        this.email = email;
        this.encodedPassword = encodedPassword;
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public String getEncodedPassword() {
        return encodedPassword;
    }

    public String getRole() {
        return role;
    }
}
