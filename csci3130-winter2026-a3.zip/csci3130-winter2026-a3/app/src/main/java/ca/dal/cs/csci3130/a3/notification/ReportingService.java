package ca.dal.cs.csci3130.a3.notification;

public class ReportingService extends Observer {

    PrescriptionServiceTracker tracker;

    public ReportingService(PrescriptionServiceTracker tracker) {
        this.tracker = tracker;
        this.tracker.attach(this);
    }

    @Override
    public void update(String message) {
        this.notification = message;
    }

    @Override
    public String getNotification() {
        return this.notification;
    }
}
