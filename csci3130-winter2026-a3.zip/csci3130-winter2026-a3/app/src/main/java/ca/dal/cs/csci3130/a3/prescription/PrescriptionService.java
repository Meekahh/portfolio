package ca.dal.cs.csci3130.a3.prescription;

import java.util.HashMap;

import ca.dal.cs.csci3130.a3.model.MedicineRepository;

public class PrescriptionService {
    Prescription prescription;
    HashMap<String, Integer> inventory;
    HashMap<String, Integer> priceMap;

    public PrescriptionService(Prescription prescription) {
        this.prescription = prescription;
        this.inventory = MedicineRepository.loadMedicineInventory();
        this.priceMap = MedicineRepository.loadPriceMap();
    }

    public boolean verifyPrescription() {
        if (this.prescription.numberOfDays > 0) {
            if (this.prescription.dosePerDay > 0) {
                return inventory.containsKey(this.prescription.getMedicineName());
            }
        }
        return false;
    }

    public boolean updateInventory() {
        int totalRequested = this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
        String medicine = this.prescription.getMedicineName();
        if (this.inventory.containsKey(medicine)) {
            Integer currentCount = this.inventory.get(medicine);
            if (currentCount != null && totalRequested < currentCount) {
                currentCount = currentCount - totalRequested;
                this.inventory.put(medicine, currentCount);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public int calculateBill() {
        int totalRequested = this.prescription.getDosePerDay() * this.prescription.getNumberOfDays();
        String medicine = this.prescription.getMedicineName();
        if (this.priceMap.containsKey(medicine)) {
            Integer unitPrice = this.priceMap.get(medicine);
            if (unitPrice != null) {
                return totalRequested * unitPrice;
            }
        }
        return 0;
    }
}
