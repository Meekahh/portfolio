package ca.dal.cs.csci3130.a3.notification;

import java.util.ArrayList;

import ca.dal.cs.csci3130.a3.config.AppConstants;
import ca.dal.cs.csci3130.a3.prescription.InventoryManager;
import ca.dal.cs.csci3130.a3.prescription.Prescription;
import ca.dal.cs.csci3130.a3.prescription.PrescriptionServiceSRP;

public class PrescriptionServiceTracker {

    InventoryManager inventoryManager;
    ArrayList<Observer> observers;
    String message;
    Prescription prescription;

    public PrescriptionServiceTracker(InventoryManager inventoryManager, Prescription prescription) {
        this.inventoryManager = inventoryManager;
        this.prescription = prescription;
        this.observers = new ArrayList<>();
    }

    public void trackPrescriptionService() {
        this.inventoryManager.setPrescription(this.prescription);
        this.inventoryManager.updateInventory();

        if (this.inventoryManager.checkLowStock()) {
            setWarningMessage(AppConstants.LOW_STOCK_MESSAGE);
        }
    }

    public void setWarningMessage(String message) {
        this.message = message;
        notifyObservers();
    }

    public void attach(Observer observer) {
        this.observers.add(observer);
    }

    protected void notifyObservers() {
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).update(this.message);
        }
    }
}
