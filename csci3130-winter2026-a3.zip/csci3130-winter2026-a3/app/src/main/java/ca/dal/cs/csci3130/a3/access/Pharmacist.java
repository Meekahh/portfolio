package ca.dal.cs.csci3130.a3.access;

public class Pharmacist extends AppUser{

    public Pharmacist() {
        this.accessLevel = AccessLevel.pharmacistAccessLevel;
    }

    @Override
    public AccessLevel getAccessLevel() {
        return this.accessLevel;
    }

    @Override
    public boolean canPlaceOnlineOrder() {
        return false;
    }

    @Override
    public boolean canSearchForPharmacist() {
        return false;
    }

    @Override
    public boolean canSearchForPatient() {
        return true;
    }

    @Override
    public boolean canSearchForOrder() {
        return true;
    }
}

