package ca.dal.cs.csci3130.a3.model;

import java.util.HashMap;

public class MedicineRepository {
    public static HashMap<String, Integer> loadMedicineInventory() {
        HashMap<String, Integer> inventory = new HashMap<>();
        inventory.put("Tylenol", 100);
        inventory.put("Advil", 15);
        inventory.put("Motrin", 100);
        return inventory;
    }

    public static HashMap<String, Integer> loadPriceMap() {
        HashMap<String, Integer> priceMap = new HashMap<>();
        priceMap.put("Tylenol", 1);
        priceMap.put("Advil", 2);
        priceMap.put("Motrin", 1);
        return priceMap;
    }
}
