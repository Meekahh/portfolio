package ca.dal.cs.csci3130.a3.auth;

public interface IPasswordMatcher {
    public boolean matches(String entered, String stored);
}
