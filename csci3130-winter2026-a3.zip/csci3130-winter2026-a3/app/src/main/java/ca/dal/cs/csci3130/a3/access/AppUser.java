package ca.dal.cs.csci3130.a3.access;

public abstract class AppUser {

    public AccessLevel accessLevel;

    public abstract boolean canPlaceOnlineOrder();
    public abstract boolean canSearchForPharmacist();
    public abstract boolean canSearchForPatient();
    public abstract boolean canSearchForOrder();
    public abstract AccessLevel getAccessLevel();
}
