package ca.dal.cs.csci3130.a3.auth;

import ca.dal.cs.csci3130.a3.model.User;

public class LogInManager {
    IUserRepository userRepository;
    IPasswordMatcher passwordMatcher;

    public LogInManager(IUserRepository repository, IPasswordMatcher matcher) {
        this.userRepository = repository;
        this.passwordMatcher = matcher;
    }

    public boolean logIn(String email, String encodedPassword) {
        User user = this.userRepository.findByEmail(email);
        if (user == null) return false;
        String password = user.getEncodedPassword();
        return this.passwordMatcher.matches(encodedPassword, password);
    }
}

