package ca.dal.cs.csci3130.a3.notification;

public abstract class Observer {
    PrescriptionServiceTracker tracker;
    String notification = "";

    public abstract void update(String message);

    public abstract String getNotification();
}
