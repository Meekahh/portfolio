package ca.dal.cs.csci3130.a3.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.List;

import ca.dal.cs.csci3130.a3.R;
import ca.dal.cs.csci3130.a3.access.AppUser;
import ca.dal.cs.csci3130.a3.access.Courier;
import ca.dal.cs.csci3130.a3.access.Patient;
import ca.dal.cs.csci3130.a3.access.Pharmacist;
import ca.dal.cs.csci3130.a3.config.AppConstants;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        this.loadRoleSpinner();
        this.setupEnterButton();
        this.setupPCCardButton();
        this.setupPrescriptionButton();
        this.loadPCDetails();
    }

    protected void loadRoleSpinner() {
        List<String> roles = new ArrayList<>();
        roles.add("Select a role");
        roles.add(AppConstants.PATIENT);
        roles.add(AppConstants.PHARMACIST);
        roles.add(AppConstants.COURIER);
        Spinner roleSpinner = findViewById(R.id.roleSpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        adapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        roleSpinner.setAdapter(adapter);
    }

    protected String getSelectedRole() {
        Spinner roleSpinner = findViewById(R.id.roleSpinner);
        return roleSpinner.getSelectedItem().toString();
    }

    protected AppUser getAppUser(String role) {
        switch (role) {
            case AppConstants.PATIENT:
                return new Patient();
            case AppConstants.PHARMACIST:
                return new Pharmacist();
            case AppConstants.COURIER:
                return new Courier();
            default:
                return null;
        }
    }


    protected void setupEnterButton() {
        Button enterButton = findViewById(R.id.enterButton);
        enterButton.setOnClickListener(view -> {
            String role = getSelectedRole();
            AppUser user = getAppUser(role);
            manageUserPanel(user);
        });
    }

    public void manageUserPanel(AppUser user) {
        if (user == null) return;
        clearOldPanels();

        managePharmacistSearchPanelDisplay(user.canSearchForPharmacist());
        manageOrderPanelDisplay(user.canPlaceOnlineOrder());

        managePatientSearchPanelDisplay(user.canSearchForPatient());
        manageOrderSearchPanelDisplay(user.canSearchForOrder());
    }

    protected void clearOldPanels() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        for (Fragment fragment : manager.getFragments()) {
            transaction.remove(fragment);
        }
        transaction.commit();
    }

    protected FragmentTransaction getFragmentTransaction() {
        FragmentManager manager = getSupportFragmentManager();
        return manager.beginTransaction();
    }

    protected void managePatientSearchPanelDisplay(boolean hasAccess) {
        FragmentTransaction transaction = getFragmentTransaction();
        PatientSearchFragment patientSearchFragment = new PatientSearchFragment();
        if (hasAccess) {
            showPanel(transaction, R.id.patientSearchContainer, patientSearchFragment);
        } else {
            removePanel(patientSearchFragment, transaction);
        }
        transaction.commit();
    }

    protected void managePharmacistSearchPanelDisplay(boolean hasAccess) {
        FragmentTransaction transaction = getFragmentTransaction();
        PharmacistSearchFragment pharmacistSearchFragment = new PharmacistSearchFragment();
        if (hasAccess) {
            showPanel(transaction, R.id.pharmacistSearchContainer, pharmacistSearchFragment);
        } else {
            removePanel(pharmacistSearchFragment, transaction);
        }
        transaction.commit();
    }

    protected void manageOrderSearchPanelDisplay(boolean hasAccess) {
        FragmentTransaction transaction = getFragmentTransaction();
        OrderSearchFragment orderSearchFragment = new OrderSearchFragment();
        if (hasAccess) {
            showPanel(transaction, R.id.orderSearchContainer, orderSearchFragment);
        } else {
            removePanel(orderSearchFragment, transaction);
        }
        transaction.commit();
    }

    protected void manageOrderPanelDisplay(boolean hasAccess) {
        FragmentTransaction transaction = getFragmentTransaction();
        OnlineOrderFragment onlineOrderFragment = new OnlineOrderFragment();
        if (hasAccess) {
            showPanel(transaction, R.id.orderContainer, onlineOrderFragment);
        } else {
            removePanel(onlineOrderFragment, transaction);
        }
        transaction.commit();
    }

    protected void showPanel(FragmentTransaction transaction, int containerID, Fragment fragment) {
        transaction.replace(containerID, fragment);
    }

    protected void removePanel(Fragment fragment, FragmentTransaction transaction) {
        transaction.remove(fragment);
    }

    protected void setupPCCardButton() {
        Button pcCard = findViewById(R.id.managePCButton);
        pcCard.setOnClickListener(view -> move2PCCard());
    }


    protected void move2PCCard() {
        Intent pcCardIntent = new Intent(this, SmartPCCardActivity.class);
        startActivity(pcCardIntent);
    }

    protected void loadPCDetails() {
        SharedPreferences sharedPref = getSharedPreferences(AppConstants.PC_CARD, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(AppConstants.INITIAL_LOYALTY, AppConstants.INITIAL_PC_POINT);
        editor.apply();
    }

    protected void setupPrescriptionButton() {
        Button prescriptionButton = findViewById(R.id.managePrescriptionButton);
        prescriptionButton.setOnClickListener(view -> move2PrescriptionPage());
    }

    protected void move2PrescriptionPage() {
        Intent prescriptionIntent = new Intent(this, PrescriptionActivity.class);
        startActivity(prescriptionIntent);
    }
}