package ca.dal.cs.csci3130.a3.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import ca.dal.cs.csci3130.a3.R;
import ca.dal.cs.csci3130.a3.config.AppConstants;
import ca.dal.cs.csci3130.a3.prescription.BillingManager;
import ca.dal.cs.csci3130.a3.prescription.InventoryManager;
import ca.dal.cs.csci3130.a3.prescription.Prescription;
import ca.dal.cs.csci3130.a3.prescription.PrescriptionServiceSRP;

public class PrescriptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);
        this.loadMedicineSpinner();
        this.loadDoseSpinner();
        this.loadDaysSpinner();
        this.setupCalculateBillButton();
    }

    protected void loadMedicineSpinner() {
        Spinner medicineSpinner = findViewById(R.id.medicineSpinner);
        List<String> medicines = new ArrayList<>();
        medicines.add("Select a medicine");
        medicines.add(AppConstants.TYLENOL);
        medicines.add(AppConstants.ADVIL);
        medicines.add(AppConstants.MOTRIN);

        ArrayAdapter<String> medicineAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, medicines);
        medicineAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        medicineSpinner.setAdapter(medicineAdapter);
    }

    protected void loadDoseSpinner() {
        Spinner doseSpinner = findViewById(R.id.doseSpinner);
        List<String> doses = new ArrayList<>();
        doses.add("Select a dose");
        doses.add("1");
        doses.add("2");
        doses.add("3");
        ArrayAdapter<String> doseAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, doses);
        doseAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        doseSpinner.setAdapter(doseAdapter);
    }

    protected void loadDaysSpinner() {
        Spinner daysSpinner = findViewById(R.id.daysSpinner);
        List<String> days = new ArrayList<>();
        days.add("Select a duration");
        days.add("3");
        days.add("5");
        days.add("7");
        ArrayAdapter<String> daysAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, days);
        daysAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        daysSpinner.setAdapter(daysAdapter);
    }


    protected String getSelectedMedicine() {
        Spinner medicineSpinner = findViewById(R.id.medicineSpinner);
        return medicineSpinner.getSelectedItem().toString();
    }

    protected int getSelectedDose() {
        Spinner doseSpinner = findViewById(R.id.doseSpinner);
        return Integer.parseInt(doseSpinner.getSelectedItem().toString());
    }

    protected int getSelectedDuration() {
        Spinner daysSpinner = findViewById(R.id.daysSpinner);
        return Integer.parseInt(daysSpinner.getSelectedItem().toString());
    }

    protected double calculateBill() {
        String medicine = getSelectedMedicine();
        int dose = getSelectedDose();
        int duration = getSelectedDuration();

        Prescription prescription = new Prescription(medicine, dose, duration);
        PrescriptionServiceSRP service = new PrescriptionServiceSRP(prescription);

        BillingManager billingManager = new BillingManager();
        service.setBillingManager(billingManager);

        return service.calculateBill();
    }

    protected void setupCalculateBillButton() {
        Button calculateBillButton = findViewById(R.id.calculateBillButton);
        calculateBillButton.setOnClickListener(view -> {
            double totalPrice = calculateBill();
            showPrice(totalPrice);
        });
    }

    protected void showPrice(double totalDiscount) {
        TextView discountLabel = findViewById(R.id.totalPriceLabel);
        discountLabel.setText(String.format("$%s", totalDiscount));
    }
}