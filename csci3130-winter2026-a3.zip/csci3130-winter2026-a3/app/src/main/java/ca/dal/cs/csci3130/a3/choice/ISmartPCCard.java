package ca.dal.cs.csci3130.a3.choice;

public interface ISmartPCCard {
    public boolean performTransaction(Transaction transaction);

    public int getCurrentPoints();

    public void setCurrentPoints(int points);
}
