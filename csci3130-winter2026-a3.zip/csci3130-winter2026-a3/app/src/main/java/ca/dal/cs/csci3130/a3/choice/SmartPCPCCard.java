package ca.dal.cs.csci3130.a3.choice;

public class SmartPCPCCard implements ISmartPCCard {

    int currentPoints;

    public SmartPCPCCard(int points) {
        this.currentPoints = points;
    }

    public boolean performTransaction(Transaction transaction) {
        return transaction.performTransaction(this);
    }

    public int getCurrentPoints() {
        return this.currentPoints;
    }

    public void setCurrentPoints(int points) {
        this.currentPoints = points;
    }
}


