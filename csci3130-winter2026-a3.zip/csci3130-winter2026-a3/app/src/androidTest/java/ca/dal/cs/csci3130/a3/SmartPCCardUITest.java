package ca.dal.cs.csci3130.a3;

import static org.junit.Assert.assertNotNull;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.cs.csci3130.a3.config.AppConstants;

@RunWith(AndroidJUnit4.class)
public class SmartPCCardUITest {

    private UiDevice device;
    public String launchPackage = "ca.dal.cs.csci3130.a3";
    public int LAUNCH_TIMEOUT = 5000;

    @Before
    public void setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        Intent launcherIntent = context.getPackageManager().getLaunchIntentForPackage(launchPackage);
        assertNotNull(launcherIntent);
        launcherIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(launcherIntent);
        device.wait(Until.hasObject(By.pkg(launchPackage).depth(0)), LAUNCH_TIMEOUT);
    }

    @Test
    public void testCashIn() throws UiObjectNotFoundException {
        UiObject pcButton=device.findObject(new UiSelector().text("MANAGE PC POINTS"));
        pcButton.clickAndWaitForNewWindow();
        UiObject point2DeductBox=device.findObject(new UiSelector().text("Enter an amount"));
        point2DeductBox.setText("500");
        UiObject cashInRB=device.findObject(new UiSelector().text("Cash In"));
        cashInRB.click();
        UiObject transactionButton=device.findObject(new UiSelector().text("MAKE TRANSACTION"));
        transactionButton.click();
        UiObject statusLabel=device.findObject(new UiSelector().text(AppConstants.TRANSACTION_SUCCESSFUL));
        Assert.assertTrue(statusLabel.exists());
    }

    @Test
    public void testTransfer() throws UiObjectNotFoundException {
        UiObject pcButton=device.findObject(new UiSelector().text("MANAGE PC POINTS"));
        pcButton.clickAndWaitForNewWindow();
        UiObject transferRB=device.findObject(new UiSelector().text("Transfer"));
        transferRB.click();
        UiObject transactionButton=device.findObject(new UiSelector().text("MAKE TRANSACTION"));
        transactionButton.click();
        UiObject statusLabel=device.findObject(new UiSelector().text(AppConstants.TRANSACTION_SUCCESSFUL));
        Assert.assertTrue(statusLabel.exists());
    }


    @Test
    public void testBuyMeds() throws UiObjectNotFoundException {
        UiObject pcButton=device.findObject(new UiSelector().text("MANAGE PC POINTS"));
        pcButton.clickAndWaitForNewWindow();
        UiObject point2DeductBox=device.findObject(new UiSelector().text("Enter an amount"));
        point2DeductBox.setText("2500");
        UiObject buyMedsRB=device.findObject(new UiSelector().text("Buy Meds"));
        buyMedsRB.click();
        UiObject transactionButton=device.findObject(new UiSelector().text("MAKE TRANSACTION"));
        transactionButton.click();
        UiObject statusLabel=device.findObject(new UiSelector().text(AppConstants.TRANSACTION_FAILED));
        Assert.assertTrue(statusLabel.exists());
    }
}
