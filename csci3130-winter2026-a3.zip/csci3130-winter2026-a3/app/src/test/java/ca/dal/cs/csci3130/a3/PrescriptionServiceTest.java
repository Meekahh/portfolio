package ca.dal.cs.csci3130.a3;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.dal.cs.csci3130.a3.prescription.BillingManager;
import ca.dal.cs.csci3130.a3.prescription.InventoryManager;
import ca.dal.cs.csci3130.a3.prescription.PrescriptionService;
import ca.dal.cs.csci3130.a3.prescription.Prescription;
import ca.dal.cs.csci3130.a3.prescription.PrescriptionServiceSRP;

public class PrescriptionServiceTest {

    InventoryManager inventoryManager;
    BillingManager billingManager;

    @Before
    public void setup() {
        this.inventoryManager = new InventoryManager();
        this.billingManager = new BillingManager();
    }

    @Test
    public void testVerifyPrescription() {
        Prescription prescription = new Prescription("Tylenol", 3, 5);
        PrescriptionService prescriptionService = new PrescriptionService(prescription);
        Assert.assertTrue(prescriptionService.verifyPrescription());
    }

    @Test
    public void testUpdateInventory() {
        Prescription prescription = new Prescription("Advil", 3, 5);
        PrescriptionService prescriptionService = new PrescriptionService(prescription);
        Assert.assertFalse(prescriptionService.updateInventory());
    }

    @Test
    public void testCalculateBill() {
        Prescription prescription = new Prescription("Motrin", 3, 7);
        PrescriptionService prescriptionService = new PrescriptionService(prescription);
        Assert.assertEquals(21, prescriptionService.calculateBill());
    }

    @Test
    public void testVerifyPrescriptionSRP() {
        Prescription prescription = new Prescription("Tylenol", 3, 5);
        PrescriptionServiceSRP prescriptionService = new PrescriptionServiceSRP(prescription);
        prescriptionService.setInventoryManager(inventoryManager);
        Assert.assertTrue(prescriptionService.verifyPrescription());
    }

    @Test
    public void testUpdateInventorySRP() {
        Prescription prescription = new Prescription("Advil", 3, 5);
        PrescriptionServiceSRP prescriptionService = new PrescriptionServiceSRP(prescription);
        prescriptionService.setInventoryManager(inventoryManager);
        Assert.assertFalse(prescriptionService.updateInventory());
    }

    @Test
    public void testCalculateBillSRP() {
        Prescription prescription = new Prescription("Motrin", 3, 7);
        PrescriptionServiceSRP prescriptionService = new PrescriptionServiceSRP(prescription);
        prescriptionService.setInventoryManager(inventoryManager);
        prescriptionService.setBillingManager(billingManager);
        Assert.assertEquals(21, prescriptionService.calculateBill());
    }


}
