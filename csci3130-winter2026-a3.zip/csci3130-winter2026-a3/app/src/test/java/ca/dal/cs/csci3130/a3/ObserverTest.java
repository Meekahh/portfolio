package ca.dal.cs.csci3130.a3;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.dal.cs.csci3130.a3.config.AppConstants;
import ca.dal.cs.csci3130.a3.notification.PrescriptionServiceTracker;
import ca.dal.cs.csci3130.a3.notification.Observer;
import ca.dal.cs.csci3130.a3.notification.ReOrderService;
import ca.dal.cs.csci3130.a3.notification.ReportingService;
import ca.dal.cs.csci3130.a3.prescription.InventoryManager;
import ca.dal.cs.csci3130.a3.prescription.Prescription;

public class ObserverTest {

    InventoryManager inventoryManager;
    Prescription prescription1;
    Prescription prescription2;

    @Before
    public void setup() {
        this.inventoryManager = new InventoryManager();
        this.prescription1 = new Prescription("Advil", 3, 4);
        this.prescription2 = new Prescription("Tylenol", 2, 5);
    }

    @Test
    public void testSendLowStockWarning() {
        PrescriptionServiceTracker tracker = new PrescriptionServiceTracker(this.inventoryManager, this.prescription1);
        Observer reorder = new ReOrderService(tracker);
        Observer reporting = new ReportingService(tracker);
        tracker.trackPrescriptionService();
        Assert.assertEquals(AppConstants.LOW_STOCK_MESSAGE, reorder.getNotification());
        Assert.assertEquals(AppConstants.LOW_STOCK_MESSAGE, reporting.getNotification());
    }

    @Test
    public void testSendNoWarning() {
        PrescriptionServiceTracker tracker = new PrescriptionServiceTracker(this.inventoryManager, this.prescription2);
        Observer reorder = new ReOrderService(tracker);
        Observer reporting = new ReportingService(tracker);
        tracker.trackPrescriptionService();
        Assert.assertEquals("", reorder.getNotification());
        Assert.assertEquals("", reporting.getNotification());
    }
}
