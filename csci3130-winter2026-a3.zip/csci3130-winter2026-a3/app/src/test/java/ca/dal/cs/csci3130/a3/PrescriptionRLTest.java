package ca.dal.cs.csci3130.a3;

import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import ca.dal.cs.csci3130.a3.ui.PrescriptionActivity;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36)
public class PrescriptionRLTest {

    ActivityController<PrescriptionActivity> controller;
    PrescriptionActivity shadow;

    @Before
    public void setup() {
        this.controller = Robolectric.buildActivity(PrescriptionActivity.class).setup();
        this.shadow = controller.get();
    }

    @Test
    public void testCalculateBillSRP(){
        Spinner medicineSpinner=this.shadow.findViewById(R.id.medicineSpinner);
        medicineSpinner.performClick();
        medicineSpinner.setSelection(1);
        Spinner doseSpinner=this.shadow.findViewById(R.id.doseSpinner);
        doseSpinner.performClick();
        doseSpinner.setSelection(2);
        Spinner daysSpinner=this.shadow.findViewById(R.id.daysSpinner);
        daysSpinner.performClick();
        daysSpinner.setSelection(2);
        Button calculateBillButton=this.shadow.findViewById(R.id.calculateBillButton);
        calculateBillButton.performClick();
        TextView priceLabel=this.shadow.findViewById(R.id.totalPriceLabel);
        Assert.assertEquals("$10.0", priceLabel.getText());
    }
}
