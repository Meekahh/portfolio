package ca.dal.cs.csci3130.a3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import ca.dal.cs.csci3130.a3.choice.BuyMedsTransaction;
import ca.dal.cs.csci3130.a3.choice.CashInTransaction;
import ca.dal.cs.csci3130.a3.choice.SmartPCPCCard;
import ca.dal.cs.csci3130.a3.choice.Transaction;
import ca.dal.cs.csci3130.a3.choice.TransferTransaction;
import ca.dal.cs.csci3130.a3.choice.PCCard;
import ca.dal.cs.csci3130.a3.choice.ISmartPCCard;


public class SmartPCCardTest {

    @Test
    public void testOldCardOperations() {
        PCCard card = new PCCard(3500);
        card.performTransaction(1, 500, null);
        assertTrue(card.cashIn(1000));
        PCCard newCard = new PCCard(0);
        assertTrue(card.transfer(newCard));
        assertEquals(2000, newCard.getCurrentPoints());
        assertFalse(card.cashIn(500));
    }

    @Test
    public void testCashIn() {
        ISmartPCCard card = new SmartPCPCCard(3500);
        Transaction transaction = new CashInTransaction(1200);
        assertTrue(card.performTransaction(transaction));
        assertEquals(2300, card.getCurrentPoints());
        assertTrue(card.performTransaction(transaction));
        assertEquals(1100, card.getCurrentPoints());
    }

    @Test
    public void testTransfer() {
        ISmartPCCard firstCard = new SmartPCPCCard(3500);
        ISmartPCCard secondCard = new SmartPCPCCard(100);
        Transaction transaction = new TransferTransaction(secondCard);
        assertTrue(firstCard.performTransaction(transaction));
        assertEquals(0, firstCard.getCurrentPoints());
        assertEquals(3600, secondCard.getCurrentPoints());
    }

    @Test
    public void testBuyMeds() {
        ISmartPCCard card = new SmartPCPCCard(2500);
        Transaction transaction = new BuyMedsTransaction(1000);
        assertTrue(card.performTransaction(transaction));
        assertEquals(1500, card.getCurrentPoints());
        assertTrue(card.performTransaction(transaction));
        assertEquals(500, card.getCurrentPoints());
    }

    @Test
    public void testAllTransactions() {
        ISmartPCCard firstCard = new SmartPCPCCard(2500);
        ISmartPCCard secondCard = new SmartPCPCCard(0);

        Transaction cashIn = new CashInTransaction(1000);
        assertTrue(firstCard.performTransaction(cashIn));
        assertEquals(1500, firstCard.getCurrentPoints());

        Transaction buyMeds = new BuyMedsTransaction(900);
        assertTrue(firstCard.performTransaction(buyMeds));
        assertEquals(600, firstCard.getCurrentPoints());

        Transaction transfer = new TransferTransaction(secondCard);
        assertTrue(firstCard.performTransaction(transfer));
        assertEquals(0, firstCard.getCurrentPoints());
        assertEquals(600, secondCard.getCurrentPoints());
    }
}
