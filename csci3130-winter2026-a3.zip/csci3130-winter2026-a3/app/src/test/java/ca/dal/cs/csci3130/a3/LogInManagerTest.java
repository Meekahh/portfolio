package ca.dal.cs.csci3130.a3;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import ca.dal.cs.csci3130.a3.auth.IPasswordMatcher;
import ca.dal.cs.csci3130.a3.auth.IUserRepository;
import ca.dal.cs.csci3130.a3.auth.LogInManager;
import ca.dal.cs.csci3130.a3.model.User;
import ca.dal.cs.csci3130.a3.util.PasswordUtility;

public class LogInManagerTest {

    IUserRepository mockedRepository;
    IPasswordMatcher mockedMatcher;
    String patientEmail = "patient@dal.ca";
    String patientPassword = PasswordUtility.makeHash("pass123");
    String pharmacistEmail = "pharmacist@dal.ca";
    String pharmacistPassword = PasswordUtility.makeHash("pass456");
    String courierEmail = "courier@dal.ca";
    String courierPassword = PasswordUtility.makeHash("pass789");

    @Before
    public void setup() {
            // Variable Declaration Zone
        mockedRepository = Mockito.mock(IUserRepository.class);
        mockedMatcher = Mockito.mock(IPasswordMatcher.class);

        User patientLogIn = new User(patientEmail, patientPassword, "patient");
        User pharmacistLogIn = new User(pharmacistEmail, pharmacistPassword, "pharmacist");
        User courierLogIn = new User(courierEmail, courierPassword, "courier");

            // Adding the mock behaviours
        Mockito.when(mockedRepository.findByEmail(patientEmail)).thenReturn(patientLogIn);
        Mockito.when(mockedRepository.findByEmail(pharmacistEmail)).thenReturn(pharmacistLogIn);
        Mockito.when(mockedRepository.findByEmail(courierEmail)).thenReturn(courierLogIn);

            // Correct patient password should return true, everything else false
        Mockito.when(mockedMatcher.matches(patientPassword, patientPassword)).thenReturn(true);
    }

    @Test
    public void tesPatientLogInSuccess() {
        LogInManager manager = new LogInManager(this.mockedRepository, this.mockedMatcher);
        Assert.assertTrue(manager.logIn(patientEmail, patientPassword));
        Mockito.verify(this.mockedRepository, Mockito.times(1)).findByEmail(patientEmail);
        Mockito.verify(this.mockedMatcher, Mockito.times(1)).matches(patientPassword, patientPassword);
    }

    @Test
    public void testPharmacistLogInFailed() {
        LogInManager manager = new LogInManager(this.mockedRepository, this.mockedMatcher);
        Assert.assertFalse(manager.logIn(pharmacistEmail, patientPassword));
        Mockito.verify(this.mockedRepository, Mockito.times(1)).findByEmail(pharmacistEmail);
        Mockito.verify(this.mockedMatcher, Mockito.times(0)).matches(pharmacistPassword, pharmacistPassword);
    }

    @Test
    public void testCourierLogInFailed() {
        LogInManager manager = new LogInManager(this.mockedRepository, this.mockedMatcher);
        Assert.assertFalse(manager.logIn(patientEmail, courierPassword));
        Mockito.verify(this.mockedRepository, Mockito.times(0)).findByEmail(courierEmail);
        Mockito.verify(this.mockedMatcher, Mockito.times(0)).matches(courierPassword, courierPassword);
    }
}
