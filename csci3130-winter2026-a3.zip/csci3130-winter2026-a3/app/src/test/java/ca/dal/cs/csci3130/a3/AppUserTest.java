package ca.dal.cs.csci3130.a3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import ca.dal.cs.csci3130.a3.access.AccessLevel;
import ca.dal.cs.csci3130.a3.access.AppUser;
import ca.dal.cs.csci3130.a3.access.Courier;
import ca.dal.cs.csci3130.a3.access.Patient;
import ca.dal.cs.csci3130.a3.access.Pharmacist;
import ca.dal.cs.csci3130.a3.config.AppConstants;


public class AppUserTest {

    @Test
    public void testPatientAccess() {
        AppUser appUser = new Patient();
        assertEquals(AccessLevel.patientAccessLevel, appUser.getAccessLevel());
        assertTrue(appUser.canPlaceOnlineOrder());
        assertTrue(appUser.canSearchForPharmacist());
        assertFalse(appUser.canSearchForOrder());
        assertFalse(appUser.canSearchForPatient());
    }

    @Test
    public void testPharmacistAccess() {
        AppUser appUser = new Pharmacist();
        assertEquals(AccessLevel.pharmacistAccessLevel, appUser.getAccessLevel());
        assertTrue(appUser.canSearchForOrder());
        assertTrue(appUser.canSearchForPatient());
        assertFalse(appUser.canPlaceOnlineOrder());
        assertFalse(appUser.canSearchForPharmacist());
    }

    @Test
    public void testCourierAccess() {
        AppUser appUser = new Courier();
        assertEquals(AccessLevel.courierAccessLevel, appUser.getAccessLevel());
        assertTrue(appUser.canSearchForOrder());
        assertFalse(appUser.canSearchForPatient());
        assertFalse(appUser.canPlaceOnlineOrder());
        assertFalse(appUser.canSearchForPharmacist());
    }

    @Test
    public void testAllUserAccess() {
        AppUser appUser1 = new Patient();
        AppUser appUser2 = new Pharmacist();
        AppUser appUser3 = new Courier();
        assertTrue(appUser1.canPlaceOnlineOrder());
        assertTrue(appUser2.canSearchForPatient());
        assertTrue(appUser3.canSearchForOrder());
    }
}
