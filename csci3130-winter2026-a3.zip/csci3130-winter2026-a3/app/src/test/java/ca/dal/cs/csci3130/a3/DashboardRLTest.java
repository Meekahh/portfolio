package ca.dal.cs.csci3130.a3;

import static android.os.Looper.getMainLooper;
import static org.robolectric.Shadows.shadowOf;

import android.widget.Button;
import android.widget.Spinner;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import ca.dal.cs.csci3130.a3.ui.DashboardActivity;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36)
public class DashboardRLTest {

    ActivityController<DashboardActivity> controller;
    DashboardActivity shadow;

    @Before
    public void setup() {
        this.controller = Robolectric.buildActivity(DashboardActivity.class).setup();
        this.shadow = this.controller.get();
    }

    @Test
    public void testPatientAccess() {
        Spinner roleSpinner = this.shadow.findViewById(R.id.roleSpinner);
        roleSpinner.performClick();
        roleSpinner.setSelection(1);
        Button enterButton = this.shadow.findViewById(R.id.enterButton);
        enterButton.performClick();
        shadowOf(getMainLooper()).idle();
        Button placeOrderButton = this.shadow.findViewById(R.id.placeOrderButton);
        Assert.assertNotNull(placeOrderButton);
        Button searchPharmacistButton = this.shadow.findViewById(R.id.searchPharmacistButton);
        Assert.assertNotNull(searchPharmacistButton);
    }

    @Test
    public void testPharmacistAccess() {
        Spinner roleSpinner = this.shadow.findViewById(R.id.roleSpinner);
        roleSpinner.performClick();
        roleSpinner.setSelection(2);
        Button enterButton = this.shadow.findViewById(R.id.enterButton);
        enterButton.performClick();
        shadowOf(getMainLooper()).idle();
        Button searchPatientButton = this.shadow.findViewById(R.id.searchPatientButton);
        Assert.assertNotNull(searchPatientButton);
        Button searchOrderButton = this.shadow.findViewById(R.id.searchOrderButton);
        Assert.assertNotNull(searchOrderButton);
    }

    @Test
    public void testCourierAccess() {
        Spinner roleSpinner = this.shadow.findViewById(R.id.roleSpinner);
        roleSpinner.performClick();
        roleSpinner.setSelection(3);
        Button enterButton = this.shadow.findViewById(R.id.enterButton);
        enterButton.performClick();
        shadowOf(getMainLooper()).idle();
        Button searchOrderButton = this.shadow.findViewById(R.id.searchOrderButton);
        Assert.assertNotNull(searchOrderButton);
    }
}
