package ca.dal.cs.csci3130.a1;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_main);

            android.widget.EditText netIDInput = findViewById(R.id.netIDEditField);
            Spinner programSpinner = findViewById(R.id.programSpinner);
            Spinner yearSpinner = findViewById(R.id.graduationYearSpinner);
            android.widget.Button button = findViewById(R.id.checkValidStudentButton);

                button.setOnClickListener(v -> {
                String netID = netIDInput.getText().toString().trim();
                String program = programSpinner.getSelectedItem().toString();
                String gradYear = yearSpinner.getSelectedItem().toString();

                    // First I check if the ID has 2 letters, then I check if it has 6 numbers
                boolean checkIdValid = netID.matches("^[a-zA-Z]{2}[0-9]{6}$");

                    /* Then the other all programs are valid (so just make sure it's not empty) and
                    * all besides 2025 are valid for grad year */
                boolean checkProgValid = !program.isEmpty();
                boolean checkYrValid = Integer.parseInt(gradYear) >= 2026;

                String toastMessage;
                if (checkIdValid && checkProgValid && checkYrValid) {
                    toastMessage = "VALID" + ": " + netID + ", " + program + ", " + gradYear;
                } else {
                    toastMessage = "NOT VALID" + ": " + netID + ", " + program + ", " + gradYear;
                }
                android.widget.Toast.makeText(this, toastMessage, android.widget.Toast.LENGTH_LONG).show();
            });
        }

    public void setupGraduationYearSpinner() {
            /* Never ended up using this, but my plan was to try and fill up
            * the graduation year spinner with a ton of years since for some reason
            * when I read it the first time I thought it needed to go on infinitely */

        ArrayList<String> futureYears = new ArrayList<>();

        int currentYear = 2026;
        int maxYear = 2200;
        while (currentYear <= maxYear) {
            futureYears.add(String.valueOf(currentYear));
            currentYear++;
        }
    }
}

