# CSCI3130-Winter2026-A1

The base code for A1

