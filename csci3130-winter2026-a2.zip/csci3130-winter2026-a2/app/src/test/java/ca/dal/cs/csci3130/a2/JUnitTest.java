package ca.dal.cs.csci3130.a2;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import ca.dal.cs.csci3130.a2.core.CredentialValidator;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class JUnitTest {
    CredentialValidator validator;

    @Before
    public void setup() {
        validator = new CredentialValidator();
    }

    @Test
    public void checkIfBannerIDIsEmpty() {
        assertTrue(validator.isEmptyBannerID(""));
        assertFalse(validator.isEmptyBannerID("xyz$56"));
    }

    @Test
    public void checkIfBannerIDIsValid() {
        assertTrue(validator.isValidBannerID("B00881245"));
    }

    @Test
    public void checkIfBannerIDIsInvalid() {
        assertFalse(validator.isValidBannerID("B88036452"));
        assertFalse(validator.isValidBannerID("abc12345"));
    }

    @Test
    public void checkIfEmailIsValid() {
        assertTrue(validator.isValidEmailAddress("abc123@dal.ca"));
    }

    @Test
    public void checkIfEmailIsInvalid() {
        assertFalse(validator.isValidEmailAddress("abc.123dal.ca"));
    }

    @Test
    public void checkIfEmailIsNotFromDAL() {
        assertFalse(validator.isDALEmailAddress("abc123@gmail.com"));
    }

    @Test
    public void checkIfTermIsValid() {
        assertTrue(validator.isValidTerm("Winter 2026"));
    }

    @Test
    public void checkIfTermIsInvalid() {
        assertFalse(validator.isValidTerm("Fall 2025"));
    }
}