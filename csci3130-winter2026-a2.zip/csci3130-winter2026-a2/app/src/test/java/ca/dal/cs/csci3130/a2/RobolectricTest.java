package ca.dal.cs.csci3130.a2;

import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import ca.dal.cs.csci3130.a2.ui.MainActivity;


@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36)
public class RobolectricTest {

    ActivityController<MainActivity> controller;
    MainActivity shadow;
    Context context;

    @Before
    public void setup() {
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        shadow = controller.get();
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void checkIfBannerIDIsEmpty() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc.123@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals(context.getString(R.string.EMPTY_BANNER_ID));
    }

    @Test
    public void checkIfBannerIDIsValid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881234");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc.123@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals("");
    }

    @Test
    public void checkIfBannerIDIsInvalid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B88001234");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc.123@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals(context.getString(R.string.INVALID_BANNER_ID));
    }

    @Test
    public void checkIfEmailIsValid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881213");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc456@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals("");
    }

    @Test
    public void checkIfEmailIsInvalid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881213");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc456.dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals(context.getString(R.string.INVALID_EMAIL_ADDRESS));
    }

    @Test
    public void checkIfEmailIsNotFromDAL() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881213");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc456@mit.edu");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(2);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals(context.getString(R.string.INVALID_DAL_EMAIL));
    }

    @Test
    public void checkIfTermIsValid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881213");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc456@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(3);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals("");
    }

    @Test
    public void checkIfTermIsInvalid() {
        EditText bannerIDBox = shadow.findViewById(R.id.bannerIDBox);
        bannerIDBox.setText("B00881213");
        EditText emailBox = shadow.findViewById(R.id.emailBox);
        emailBox.setText("abc456@dal.ca");
        Spinner termSpinner = shadow.findViewById(R.id.termSpinner);
        termSpinner.performClick();
        termSpinner.setSelection(1);
        RadioButton studentRB = shadow.findViewById(R.id.studentRB);
        studentRB.performClick();
        Button registerButton = shadow.findViewById(R.id.registerButton);
        registerButton.performClick();
        TextView statusLabel = shadow.findViewById(R.id.statusLabel);
        assert statusLabel.getText().equals(context.getString(R.string.INVALID_TERM));
    }
}
