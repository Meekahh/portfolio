package ca.dal.cs.csci3130.a2.data;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseCRUD {
    private FirebaseDatabase database = null;
    private DatabaseReference bannerIDRef = null;
    private DatabaseReference emailRef = null;
    private DatabaseReference termRef = null;
    private DatabaseReference roleRef = null;
    private String extractedBannerID;
    private String extractedEmail;
    private String extractedTerm;
    private String extractedRole;

    private DatabaseReference regRef;

    public FirebaseCRUD(FirebaseDatabase database) {
        this.database = database;

        initializeDatabaseRefs();
        initializeDatabaseRefListeners();
    }

    protected DatabaseReference getBannerIDRef() {
        return this.database.getReference("bannerID");
    }

    public void setBannerID(String bannerID) {
        this.bannerIDRef.setValue(bannerID);
    }

    protected void setBannerIDListener() {
        this.bannerIDRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                extractedBannerID = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    protected void setEmailListener() {
        this.emailRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                extractedEmail = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    protected void setRoleListener() {
        this.roleRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                extractedRole = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    protected void setTermListener() {
        this.termRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                extractedTerm = snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void saveCredentials(String bannerID, String email, String term, String role) {
        bannerIDRef.setValue(bannerID);
        emailRef.setValue(email);
        termRef.setValue(term);
        roleRef.setValue(role);
    }
    /*Several methods/features were deleted from here!*/


    protected void initializeDatabaseRefs() {
        this.bannerIDRef = database.getReference("bannerID");
        this.emailRef = database.getReference("email");
        this.termRef = database.getReference("term");
        this.roleRef = database.getReference("role");
    }

    protected void initializeDatabaseRefListeners() {
        this.setBannerIDListener();
        this.setEmailListener();
        this.setRoleListener();
        this.setTermListener();
        //add other listeners
    }

    public String getExtractedBannerID() {
        return this.extractedBannerID;
    }

    public String getExtractedEmail() {
        return this.extractedEmail;
    }

    public String getExtractedTerm() {
        return this.extractedTerm;
    }

    public String getExtractedRole() {
        return this.extractedRole;
    }
}
