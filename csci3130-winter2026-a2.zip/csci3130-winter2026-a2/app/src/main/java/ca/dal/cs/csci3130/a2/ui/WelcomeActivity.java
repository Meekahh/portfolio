package ca.dal.cs.csci3130.a2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.FirebaseDatabase;

import ca.dal.cs.csci3130.a2.data.FirebaseCRUD;
import ca.dal.cs.csci3130.a2.R;

public class WelcomeActivity extends AppCompatActivity {

    private FirebaseCRUD crud;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        crud = new FirebaseCRUD(FirebaseDatabase.getInstance());

        showWelcomeMessage();
        setupRetrieveButton();
    }

    protected void showWelcomeMessage() {
        TextView welcomeLabel = findViewById(R.id.welcomeLabel);

        Intent intent = getIntent();
        String message = intent.getStringExtra("welcomeMessage");

        welcomeLabel.setText(message);
    }


    protected void setupRetrieveButton() {
        Button retrieveButton = findViewById(R.id.retrieveFromDBButton);
        retrieveButton.setOnClickListener(v -> {
            String bannerID = crud.getExtractedBannerID();
            String email = crud.getExtractedEmail();
            String term = crud.getExtractedTerm();
            String role = crud.getExtractedRole();
            String message = bannerID + "-" + email + "-" + term + "-" + role;

            showRetrievedItems(retrieveButton, message);
        });
    }

    protected void showRetrievedItems(View retrieveButton, String message) {
        Snackbar.make(retrieveButton, message, Snackbar.LENGTH_LONG).show();
    }
}