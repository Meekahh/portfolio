package ca.dal.cs.csci3130.a2.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

import ca.dal.cs.csci3130.a2.core.CredentialValidator;
import ca.dal.cs.csci3130.a2.data.FirebaseCRUD;
import ca.dal.cs.csci3130.a2.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static String WELCOME_MESSAGE = "ca.dal.csci3130.a2.welcome";
    FirebaseDatabase database = null;
    FirebaseCRUD crud = null;
    CredentialValidator validator;

        // Keys (changing to use constants since the literals were annoying)
    public static String BANNER_KEY = "bannerKey";
    public static String EMAIL_KEY = "emailKey";
    public static String TERM_KEY = "termKey";
    public static String ROLE_KEY = "roleKey";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.loadTermSpinner();
        this.setupRegistrationButton();

        validator = new CredentialValidator();
        crud = new FirebaseCRUD(FirebaseDatabase.getInstance());
    }

    protected void loadTermSpinner() {
        Spinner termSpinner = findViewById(R.id.termSpinner);
        List<String> terms = new ArrayList<>();
        terms.add("Select your term");
        terms.add("Fall 2025");
        terms.add("Winter 2026");
        terms.add("Spring 2026");
        terms.add("Fall 2026");
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, terms);
        spinnerAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        termSpinner.setAdapter(spinnerAdapter);
    }

    protected void setupRegistrationButton() {
        Button registerButton = findViewById(R.id.registerButton);
        registerButton.setOnClickListener(this);
    }

    protected String getBannerID() {
        EditText bannerIDBox = findViewById(R.id.bannerIDBox);
        return bannerIDBox.getText().toString();
    }

    protected void setStatusMessage(String message) {
        TextView statusLabel = findViewById(R.id.statusLabel);
        statusLabel.setText(message.trim());
    }

    protected String getEmail() {
        EditText emailBox = findViewById(R.id.emailBox);
        return emailBox.getText().toString();
    }

    protected String getTerm() {
        Spinner termSpinner = findViewById(R.id.termSpinner);
        return termSpinner.getSelectedItem().toString();
    }

    protected String getRole() {
        RadioButton studentRB = findViewById(R.id.studentRB);
        RadioButton instructorRB = findViewById(R.id.instructorRB);

        if (studentRB.isChecked()) {
            return "Student";
        } else if (instructorRB.isChecked()) {
            return "Instructor";
        }

        return "";
    }

    @Override
    public void onClick(View view) {
        String bannerID = getBannerID();
        String email = getEmail();
        String term = getTerm();
        String role = getRole();

        String errorMessage = "";

            // Banner ID validation
        if (!validator.isValidBannerID(bannerID)) {
            errorMessage = "Invalid Banner ID";
        }

            // Email validation
        if (!validator.isDALEmailAddress(email)) {
            errorMessage = "Invalid DAL email address";
        }
        if (!validator.isValidEmailAddress(email)) {
            errorMessage = "Invalid email address";
        }

            // Term validation
        if (!validator.isValidTerm(term)) {
            errorMessage = "Invalid term";
        }



        if (bannerID.trim().isEmpty()) {
            errorMessage = getResources().getString(R.string.EMPTY_BANNER_ID);
        }
        if (!errorMessage.isEmpty()) {
            setStatusMessage(errorMessage);
            return;
        }

            // Save to Firebase and then move onto the welcome screen
        saveToDatabase(bannerID, email, term, role);
        String welcomeMessage = prepareWelcomeMessage(bannerID, email, term, role);
        move2Welcome(welcomeMessage);
    }

    protected void saveToDatabase(String bannerID, String email, String term, String role) {
        crud.saveCredentials(bannerID, email, term, role);
    }

    protected String prepareWelcomeMessage(String bannerID, String email, String term, String role) {
        return "Hello " + bannerID + "! A welcome email is sent to " + email + ". Your term: " + term + ". Your role: " + role;
    }

    protected void move2Welcome(String message) {
        Intent intent = new Intent(this, WelcomeActivity.class);
        intent.putExtra("welcomeMessage", message);
        startActivity(intent);
    }
}