package ca.dal.cs.csci3130.a2.core;

import androidx.core.util.PatternsCompat;

public class CredentialValidator {
    public boolean isEmptyBannerID(String bannerID) {
        return bannerID.isEmpty();
    }

    public boolean isValidBannerID(String bannerID) {
        String bannerIdRegex = "^B00\\d{6}$";
        return bannerID.matches(bannerIdRegex);
    }

    public boolean isEmptyEmailAddress(String emailAddress) {
        return false;
    }

    public boolean isValidEmailAddress(String emailAddress) {
        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z]+\\.[A-Za-z]+$";
        return emailAddress.matches(emailRegex);
    }

    public boolean isEmptyTerm(String term) {
        return false;
    }

    public boolean isDALEmailAddress(String emailAddress) {
        String dalEmailRegex = "^[A-Za-z0-9._%+-]+@dal\\.ca$";
        return emailAddress.matches(dalEmailRegex);
    }

    public boolean isValidTerm(String term) {
        if (term == null) {
            return false;
        }
        if (term.equals("Select your term")) {
            return false;
        }


        return term.equals("Winter 2026")
                || term.equals("Spring 2026")
                || term.equals("Fall 2026");
    }
}
