package ca.dal.cs.csci3130.a2;

import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class UIAutomatorTest {

    private static final int LAUNCH_TIMEOUT = 5000;
    final String launcherPackage = "ca.dal.cs.csci3130.a2";
    private UiDevice device;

    @Before
    public void setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent appIntent = context.getPackageManager().getLaunchIntentForPackage(launcherPackage);
        Assert.assertNotNull(appIntent);
        appIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(appIntent);
        device.wait(Until.hasObject(By.pkg(launcherPackage).depth(0)), LAUNCH_TIMEOUT);
    }

    @Test
    public void checkIfLandingPageIsVisible() {
        UiObject bannerIDBox = device.findObject(new UiSelector().textContains("Banner ID"));
        assertTrue(bannerIDBox.exists());
        UiObject emailIDBox = device.findObject(new UiSelector().textContains("Email"));
        assertTrue(emailIDBox.exists());
        UiObject termSpinner = device.findObject(new UiSelector().textContains("Select your term"));
        assertTrue(termSpinner.exists());
        UiObject studentRB = device.findObject(new UiSelector().text("Student"));
        assertTrue(studentRB.exists());
        UiObject registerButton = device.findObject(new UiSelector().text("REGISTER"));
        assertTrue(registerButton.exists());
    }

    @Test
    public void checkIfMoved2WelcomePage() throws UiObjectNotFoundException {
        UiObject bannerIDBox = device.findObject(new UiSelector().textContains("Banner ID"));
        bannerIDBox.setText("B00885236");
        UiObject emailIDBox = device.findObject(new UiSelector().textContains("Email"));
        emailIDBox.setText("abc.123@dal.ca");
        UiObject termSpinner = device.findObject(new UiSelector().textContains("Select your term"));
        termSpinner.click();
        List<UiObject2> roles = device.findObjects(By.res("android:id/text1"));
        roles.get(3).click();
        UiObject studentRB = device.findObject(new UiSelector().text("Student"));
        studentRB.click();
        UiObject registerButton = device.findObject(new UiSelector().text("REGISTER"));
        registerButton.clickAndWaitForNewWindow();
        UiObject welcomeLabel = device.findObject(new UiSelector().textContains("Hello"));
        assertTrue(welcomeLabel.exists());
    }

    @Test
    public void checkIfCredentialsAreRetrieved() throws UiObjectNotFoundException {
        /*Buggy test, fix the test method*/
        UiObject bannerIDBox = device.findObject(new UiSelector().textContains("Banner ID"));
        bannerIDBox.setText("B00885236");
        UiObject emailIDBox = device.findObject(new UiSelector().textContains("Email"));
        emailIDBox.setText("abc.123@dal.ca");
        UiObject termSpinner = device.findObject(new UiSelector().textContains("Select your term"));
        termSpinner.click();
        UiObject termSelection = device.findObject(new UiSelector().text("Spring 2026"));
        termSelection.click();
        UiObject studentRB = device.findObject(new UiSelector().text("Student"));
        studentRB.click();
        UiObject registerButton = device.findObject(new UiSelector().text("REGISTER"));
        registerButton.clickAndWaitForNewWindow();
        UiObject welcomeLabel = device.findObject(new UiSelector().textContains("Hello"));
        assertTrue(welcomeLabel.exists());
        UiObject retrieveButton = device.findObject(new UiSelector().text("RETRIEVE CREDENTIALS"));
        retrieveButton.click();
        UiObject snackBar = device.findObject(new UiSelector().textContains("B00885236-abc.123@dal.ca-Spring 2026-Student"));
        assertTrue(snackBar.exists());
    }
}
