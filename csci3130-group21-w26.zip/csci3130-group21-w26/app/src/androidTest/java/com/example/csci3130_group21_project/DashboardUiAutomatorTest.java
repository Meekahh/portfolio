package com.example.csci3130_group21_project;

import android.content.Context;
import android.content.Intent;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertNotNull;

import com.example.csci3130_group21_project.views.StudentDashboardActivity;
import com.example.csci3130_group21_project.views.TutorDashboardActivity;

@RunWith(AndroidJUnit4.class)
public class DashboardUiAutomatorTest {
    private static final int LAUNCH_TIMEOUT = 5000;
    private static final String APP_PACKAGE = "com.example.csci3130_group21_project";
    private UiDevice device;
    private Context context;

    @Before
    public void setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        context = ApplicationProvider.getApplicationContext();
    }

    private void launchActivity(Class<?> activityClass) {
        final Intent intent = new Intent(context, activityClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        device.wait(Until.hasObject(By.pkg(APP_PACKAGE).depth(0)), LAUNCH_TIMEOUT);
    }

    @Test
    public void testStudentDashboardIsVisible() {
        launchActivity(StudentDashboardActivity.class);
        checkIfDashboardElementsAreVisible();
    }

    @Test
    public void testTutorDashboardIsVisible() {
        launchActivity(TutorDashboardActivity.class);
        checkIfDashboardElementsAreVisible();
    }

    private void checkIfDashboardElementsAreVisible() {
        UiObject2 welcomeMessage = device.findObject(By.res(APP_PACKAGE, "welcomeMessage"));
        assertNotNull("Welcome message not found", welcomeMessage);

        UiObject2 userName = device.findObject(By.res(APP_PACKAGE, "userName"));
        assertNotNull("User name not found", userName);

        UiObject2 userStatus = device.findObject(By.res(APP_PACKAGE, "userStatus"));
        assertNotNull("User status not found", userStatus);

        UiObject2 logoutButton = device.findObject(By.res(APP_PACKAGE, "logoutButton"));
        assertNotNull("Logout button not found", logoutButton);
    }
}

