package com.example.csci3130_group21_project;

import android.content.Context;
import android.content.Intent;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import com.example.csci3130_group21_project.views.PostTutorialActivity;
import com.google.firebase.auth.FirebaseAuth;

import java.util.concurrent.CountDownLatch;

/**
 * UI Automator tests for {@link PostTutorialActivity}.
 * Verifies that the post tutorial form displays correctly, shows errors
 * for invalid input, and hides errors on valid submission.
 */
@RunWith(AndroidJUnit4.class)
public class PostTutorialUiAutomatorTest {

    private static final String APP_LINK = "com.example.csci3130_group21_project";
    private UiDevice device;
    private Context context;

    /**
     * Sets up the UI device and context before each test,
     * and signs in anonymously to satisfy Firebase authentication requirements.
     */
    @Before
    public void setup() throws InterruptedException {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        context = ApplicationProvider.getApplicationContext();

        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance().signInAnonymously()
                .addOnCompleteListener(task -> latch.countDown());
        latch.await(10, java.util.concurrent.TimeUnit.SECONDS);
    }

    /**
     * Launches {@link PostTutorialActivity}.
     */
    private void launchActivity() {
        final Intent intent = new Intent(context, PostTutorialActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        device.wait(Until.hasObject(By.pkg(APP_LINK).depth(0)), 5000);
    }

    /**
     * Fills all form fields with the provided values.
     */
    private void fillForm(String title, String description, String subject, String location,
                          String date, String time, String maxStudents, String duration, String fee) {
        UiObject2 titleBox = device.findObject(By.res(APP_LINK, "titleBox"));
        if (titleBox != null) { titleBox.clear(); titleBox.setText(title); }

        UiObject2 descriptionBox = device.findObject(By.res(APP_LINK, "descriptionBox"));
        if (descriptionBox != null) { descriptionBox.clear(); descriptionBox.setText(description); }

        UiObject2 subjectBox = device.findObject(By.res(APP_LINK, "subjectBox"));
        if (subjectBox != null) { subjectBox.clear(); subjectBox.setText(subject); }

        UiObject2 locationBox = device.findObject(By.res(APP_LINK, "locationBox"));
        if (locationBox != null) { locationBox.clear(); locationBox.setText(location); }

        UiObject2 dateBox = device.findObject(By.res(APP_LINK, "dateBox"));
        if (dateBox != null) { dateBox.clear(); dateBox.setText(date); }

        UiObject2 timeBox = device.findObject(By.res(APP_LINK, "timeBox"));
        if (timeBox != null) { timeBox.clear(); timeBox.setText(time); }

        UiObject2 maxStudentsBox = device.findObject(By.res(APP_LINK, "maxStudentsBox"));
        if (maxStudentsBox != null) { maxStudentsBox.clear(); maxStudentsBox.setText(maxStudents); }

        UiObject2 durationBox = device.findObject(By.res(APP_LINK, "durationBox"));
        if (durationBox != null) { durationBox.clear(); durationBox.setText(duration); }

        UiObject2 feeBox = device.findObject(By.res(APP_LINK, "feeBox"));
        if (feeBox != null) { feeBox.clear(); feeBox.setText(fee); }
    }

    /**
     * Clicks the submit button and waits for the app to respond.
     */
    private void submit() {
        UiObject2 postBtn = device.findObject(By.res(APP_LINK, "postBtn"));
        if (postBtn != null) postBtn.click();
        device.wait(Until.hasObject(By.pkg(APP_LINK).depth(0)), 5000);
    }

    /**
     * Verifies that all form fields and the submit button are visible on load.
     */
    @Test
    public void testAllFieldsVisible() {
        launchActivity();

        assertNotNull(device.findObject(By.res(APP_LINK, "titleBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "descriptionBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "subjectBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "locationBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "dateBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "timeBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "maxStudentsBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "durationBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "feeBox")));
        assertNotNull(device.findObject(By.res(APP_LINK, "postBtn")));
    }

    /**
     * Verifies that the error text is hidden when the activity first loads.
     */
    @Test
    public void testErrorTextHiddenOnLoad() {
        launchActivity();
        assertNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that no error is shown after submitting a fully valid form.
     */
    @Test
    public void testValidSubmissionHidesErrorText() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "10", "60", "15.0");
        submit();

        assertNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the title field is empty.
     */
    @Test
    public void testEmptyTitle() {
        launchActivity();

        fillForm("", "Description", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the description field is empty.
     */
    @Test
    public void testEmptyDescription() {
        launchActivity();

        fillForm("Title", "", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the subject field is empty.
     */
    @Test
    public void testEmptySubject() {
        launchActivity();

        fillForm("Title", "Description", "", "20 Location Street",
                "2026-03-20", "12:00", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the location field is empty.
     */
    @Test
    public void testEmptyLocation() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "",
                "2026-03-20", "12:00", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the date is not in YYYY-MM-DD format.
     */
    @Test
    public void testInvalidDate() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "not-a-date", "12:00", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the time is not in HH:MM format.
     */
    @Test
    public void testInvalidTime() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "2026-03-20", "99:99", "10", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when max students is zero.
     */
    @Test
    public void testZeroMaxStudents() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "0", "60", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when duration is zero.
     */
    @Test
    public void testZeroDuration() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "10", "0", "15.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when the fee is negative.
     */
    @Test
    public void testNegativeFee() {
        launchActivity();

        fillForm("Title", "Description", "Subject", "20 Location Street",
                "2026-03-20", "12:00", "10", "60", "-1.0");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }

    /**
     * Verifies that an error is shown when all fields are empty.
     */
    @Test
    public void testAllFieldsEmpty() {
        launchActivity();

        fillForm("", "", "", "", "", "", "", "", "");
        submit();

        assertNotNull(device.findObject(By.res(APP_LINK, "errorText")));
    }
}