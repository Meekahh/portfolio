package com.example.csci3130_group21_project;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class UIAutomatorTestLogin {
    final String launcherPackage = "com.example.csci3130_group21_project";

    private static final int LAUNCH_TIMEOUT = 5000;
    private UiDevice device;

    @Before
    public void setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        Context context = ApplicationProvider.getApplicationContext();
        final Intent appIntent = new Intent(context, com.example.csci3130_group21_project.views.LoginActivity.class);
        appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(appIntent);
        device.wait(Until.hasObject(By.pkg(launcherPackage).depth(0)), LAUNCH_TIMEOUT);
    }

    @Test
    public void checkIfLoginPageIsVisible() throws UiObjectNotFoundException {
        UiObject emailBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/emailAddress"));
        emailBox.waitForExists(LAUNCH_TIMEOUT);
        assertTrue(emailBox.exists());
        UiObject passwordBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/password"));
        passwordBox.waitForExists(LAUNCH_TIMEOUT);
        assertTrue(passwordBox.exists());
        UiObject loginButton = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/loginButton"));
        loginButton.waitForExists(LAUNCH_TIMEOUT);
        assertTrue(loginButton.exists());
        UiObject fPasswordButton = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/forgotPasswordButton"));
        fPasswordButton.waitForExists(LAUNCH_TIMEOUT);
        assertTrue(fPasswordButton.exists());
    }

    @Test
    public void checkIfCredentialsAreValid() throws UiObjectNotFoundException{
        UiObject emailBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/emailAddress"));
        emailBox.setText("ab123456@dal.ca");
        UiObject passwordBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/password"));
        passwordBox.setText("securePassword123!");
        UiObject loginButton = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/loginButton"));
        loginButton.click();
        UiObject messageLabel = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/messageLabel"));
        assertEquals("INVALID_CREDENTIALS",messageLabel.getText());
    }

    @Test
    public void checkIfCredentialsAreInvalid() throws UiObjectNotFoundException{
        UiObject emailBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/emailAddress"));
        emailBox.setText("a123@dal.ca");
        UiObject passwordBox = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/password"));
        passwordBox.setText("notsecurepassword");
        UiObject loginButton = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/loginButton"));
        loginButton.click();
        UiObject messageLabel = device.findObject(new UiSelector().resourceId(launcherPackage + ":id/messageLabel"));
        assertEquals("INVALID_EMAIL_OR_PASSWORD",messageLabel.getText());
    }

}
