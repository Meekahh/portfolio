package com.example.csci3130_group21_project;

import android.content.Context;
import android.content.Intent;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.Until;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;

import com.example.csci3130_group21_project.views.PaymentPaypalActivity;

/**
 * UI tests for the payment screen
 */
@RunWith(AndroidJUnit4.class)
public class PaymentUiAutomatorTest {

    private static final String APP = "com.example.csci3130_group21_project";
    private UiDevice device;
    private Context context;

    @Before
        // Setup
    public void setup() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        context = ApplicationProvider.getApplicationContext();
    }

    private void launch() {
        Intent intent = new Intent(context, PaymentPaypalActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        device.wait(Until.hasObject(By.pkg(APP).depth(0)), 5000);
    }

    @Test
    public void testUiVisible() {
        launch();
        assertNotNull(device.findObject(By.res(APP, "paymentTutorialTitle")));
        assertNotNull(device.findObject(By.res(APP, "paymentAmount")));
        assertNotNull(device.findObject(By.res(APP, "cardHolderNameBox")));
        assertNotNull(device.findObject(By.res(APP, "cardNumberBox")));
        assertNotNull(device.findObject(By.res(APP, "expiryDateBox")));
        assertNotNull(device.findObject(By.res(APP, "cvvBox")));
        assertNotNull(device.findObject(By.res(APP, "submitPaymentBtn")));
    }

    @Test
        // Empty card
    public void testErrorEmpty() {
        launch();
        device.findObject(By.res(APP, "submitPaymentBtn")).click();
        UiObject2 err = device.wait(Until.findObject(By.res(APP, "paymentErrorText")), 2000);
        assertNotNull(err);
        assertEquals("Invalid name or card number", err.getText());
    }

    @Test
        // Wrong card
    public void testErrorCard() {
        launch();
        device.findObject(By.res(APP, "cardHolderNameBox")).setText("Test User");
        device.findObject(By.res(APP, "cardNumberBox")).setText("123");
        device.findObject(By.res(APP, "submitPaymentBtn")).click();
        UiObject2 err = device.wait(Until.findObject(By.res(APP, "paymentErrorText")), 2000);
        assertNotNull(err);
        assertEquals("Invalid name or card number", err.getText());
    }
}
