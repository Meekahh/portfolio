package com.example.csci3130_group21_project;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import android.content.Context;
import android.content.Intent;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.Until;

import com.example.csci3130_group21_project.views.ViewTutorialActivity;
import com.google.firebase.auth.FirebaseAuth;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;

/**
 * UI Automator tests for {@link ViewTutorialActivity}.
 * Verifies that the tutorial detail page loads and displays correctly
 * when given a valid post ID, and handles missing post IDs gracefully.
 */
@RunWith(AndroidJUnit4.class)
public class ViewTutorialUiAutomatorTest {

    private static final String APP_PACKAGE = "com.example.csci3130_group21_project";
    private static final String TEST_POST_ID = "-OniWbCX40IGZmmf5EWR";

    private UiDevice device;
    private Context context;

    /**
     * Sets up the UI device and context before each test,
     * and signs in anonymously to satisfy Firebase authentication requirements.
     */
    @Before
    public void setup() throws InterruptedException {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        context = ApplicationProvider.getApplicationContext();

        CountDownLatch latch = new CountDownLatch(1);
        FirebaseAuth.getInstance().signInAnonymously()
                .addOnCompleteListener(task -> latch.countDown());
        latch.await(10, java.util.concurrent.TimeUnit.SECONDS);
    }

    /**
     * Launches {@link ViewTutorialActivity} with the test post ID.
     */
    private void launchActivity() {
        final Intent intent = new Intent(context, ViewTutorialActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("postID", TEST_POST_ID);
        context.startActivity(intent);
        device.wait(Until.hasObject(By.pkg(APP_PACKAGE).depth(0)), 5000);
    }

    /**
     * Verifies that all tutorial detail fields are visible after the activity loads.
     */
    @Test
    public void testAllFieldsVisible() {
        launchActivity();

        assertNotNull(device.findObject(By.res(APP_PACKAGE, "topicText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "tutorText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "dateTimeText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "durationText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "locationText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "feeText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "statusText")));
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "descriptionText")));
    }

    /**
     * Verifies that the register button is visible when the post has available seats.
     */
    @Test
    public void testRegisterButtonVisible() {
        launchActivity();
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "registerBtn")));
    }

    /**
     * Verifies that the map button is visible when the post has a non-empty location.
     */
    @Test
    public void testMapButtonVisible() {
        launchActivity();
        assertNotNull(device.findObject(By.res(APP_PACKAGE, "mapBtn")));
    }

    /**
     * Verifies that the activity finishes and shows no content
     * when launched without a post ID.
     */
    @Test
    public void testNoPostIdEndsActivity() {
        final Intent intent = new Intent(context, ViewTutorialActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        device.wait(Until.hasObject(By.pkg(APP_PACKAGE).depth(0)), 5000);

        assertNull(device.findObject(By.res(APP_PACKAGE, "topicText")));
    }
}