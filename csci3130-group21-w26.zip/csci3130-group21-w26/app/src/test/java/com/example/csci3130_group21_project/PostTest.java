package com.example.csci3130_group21_project;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.example.csci3130_group21_project.core.TutorialPostValidator;

import org.junit.Test;

/**
 * Unit tests for {@link TutorialPostValidator}.
 * Verifies that validation passes for valid input and fails correctly
 * for each type of invalid input across all fields.
 */
public class PostTest {

    private final TutorialPostValidator validator = new TutorialPostValidator();

    /**
     * Verifies that a fully valid post passes validation with no errors.
     */
    @Test
    public void testValidPost() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertTrue(r.isValid);
        assertTrue(r.error.isEmpty());
    }

    /**
     * Verifies that an empty title fails validation.
     */
    @Test
    public void testInvalidTitle() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a whitespace-only title fails validation.
     */
    @Test
    public void testWhitespaceTitle() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "    ",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that an empty subject fails validation.
     */
    @Test
    public void testInvalidSubject() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a whitespace-only subject fails validation.
     */
    @Test
    public void testWhitespaceSubject() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "     ",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that an empty description fails validation.
     */
    @Test
    public void testInvalidDescription() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a whitespace-only description fails validation.
     */
    @Test
    public void testWhitespaceDescription() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "     ",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that an empty location fails validation.
     */
    @Test
    public void testInvalidLocation() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a whitespace-only location fails validation.
     */
    @Test
    public void testWhitespaceLocation() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "     ",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a date not in YYYY-MM-DD format fails validation.
     */
    @Test
    public void testInvalidDate() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "not-a-date",
                "12:00",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a time not in HH:MM format fails validation.
     */
    @Test
    public void testInvalidTime() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "99:99",
                "10",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that zero max students fails validation.
     */
    @Test
    public void testZeroMaxStudents() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "0",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a negative max students value fails validation.
     */
    @Test
    public void testNegativeMaxStudents() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "-1",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a non-numeric max students value fails validation.
     */
    @Test
    public void testNonNumberMaxStudents() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "aaa",
                "60",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that zero duration fails validation.
     */
    @Test
    public void testZeroDuration() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "0",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a negative duration fails validation.
     */
    @Test
    public void testNegativeDuration() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "-1",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a non-numeric duration fails validation.
     */
    @Test
    public void testNonNumberDuration() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "aaa",
                "15.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a negative fee fails validation.
     */
    @Test
    public void testNegativeFee() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "-1.0"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that a non-numeric fee fails validation.
     */
    @Test
    public void testNonNumberFee() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "Title",
                "Description",
                "Subject",
                "20 Location Street",
                "2026-03-20",
                "12:00",
                "10",
                "60",
                "aaa"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }

    /**
     * Verifies that all invalid fields together fail validation.
     */
    @Test
    public void testAllInvalid() {
        TutorialPostValidator.ValidationResult r = validator.validate(
                "",
                "",
                "",
                "",
                "not-a-date",
                "99:99",
                "-1",
                "-1",
                "-1"
        );

        assertFalse(r.isValid);
        assertNotNull(r.error);
        assertFalse(r.error.isEmpty());
    }
}