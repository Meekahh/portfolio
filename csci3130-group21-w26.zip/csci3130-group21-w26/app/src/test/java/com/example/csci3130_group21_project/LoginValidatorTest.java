package com.example.csci3130_group21_project;


import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.*;

import com.example.csci3130_group21_project.core.Login;
import com.example.csci3130_group21_project.core.LoginValidator;


/**
 * Unit tests for Login validation logic.
 * These are placed in src/test to run quickly on the JVM.
 */
public class LoginValidatorTest {


    private LoginValidator validator;


    @Before
    public void setUp() {
        validator = new LoginValidator();
    }


    @Test
    public void emailIsEmpty() {
        assertFalse(validator.validateEmail(""));
    }


    @Test
    public void passwordIsEmpty() {
        assertFalse(validator.validatePassword(""));
    }


    @Test
    public void emailIsNull() {
        assertFalse(validator.validateEmail(null));
    }


    @Test
    public void passwordIsNull() {
        assertFalse(validator.validatePassword(null));
    }


    @Test
    public void invalidEmailFormats() {
        // Missing letters
        assertFalse(validator.validateEmail("123456@dal.ca"));
        // Too many letters
        assertFalse(validator.validateEmail("abc123456@dal.ca"));
        // Too few digits
        assertFalse(validator.validateEmail("ab12345@dal.ca"));
        // Too many digits
        assertFalse(validator.validateEmail("ab1234567@dal.ca"));
        // Wrong domain
        assertFalse(validator.validateEmail("ab123456@gmail.com"));
        assertFalse(validator.validateEmail("ab123456@dal.com"));
    }


    //This takes a DAL email and checks if it is valid
    @Test
    public void validEmail() {
        assertTrue(validator.validateEmail("ab123456@dal.ca"));
    }

    //This takes a password and checks if it is valid
    @Test
    public void validPassword() {
        assertTrue(validator.validatePassword("securePassword123!"));
    }

    @Test
    public void invalidEmail() {
        assertFalse(validator.validateEmail("uy!123456@dal.ca"));
    }

    @Test
    public void invalidPassword() {
        assertFalse(validator.validatePassword("securePassword"));
    }
}
