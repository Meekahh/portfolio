package com.example.csci3130_group21_project;

import static org.junit.Assert.*;

import com.example.csci3130_group21_project.core.RegistrationScreen;

import org.junit.Test;

public class SignupTest {

    @Test
    public void testValidSignup() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John Snow",
                "1234567890",
                "student",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertTrue(signup.email.isValid());
        assertTrue(signup.password.isValid());
        assertTrue(signup.name.isValid());
        assertTrue(signup.contactNum.isValid());
        assertTrue(signup.role.isValid());
        assertTrue(signup.securityQuestion.isValid());
        assertTrue(signup.securityAnswer.isValid());
        assertNull(signup.email.getErrorMsg());
        assertNull(signup.password.getErrorMsg());
        assertNull(signup.name.getErrorMsg());
        assertNull(signup.contactNum.getErrorMsg());
        assertNull(signup.role.getErrorMsg());
        assertNull(signup.securityQuestion.getErrorMsg());
        assertNull(signup.securityAnswer.getErrorMsg());
    }

    @Test
    public void testInvalidEmail() {
        RegistrationScreen signup = new RegistrationScreen(
                "invalid-email",
                "Password1",
                "John Snow",
                "1234567890",
                "student",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.email.isValid());
        assertNotNull(signup.email.getErrorMsg());
    }

    @Test
    public void testInvalidPassword() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "pass",  // too short, no number
                "John Snow",
                "1234567890",
                "student",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.password.isValid());
        assertNotNull(signup.password.getErrorMsg());
    }

    @Test
    public void testInvalidName() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John123",
                "1234567890",
                "student",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.name.isValid());
        assertNotNull(signup.name.getErrorMsg());
    }

    @Test
    public void testInvalidContact() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John Snow",
                "123abc",  // invalid format
                "student",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.contactNum.isValid());
        assertNotNull(signup.contactNum.getErrorMsg());
    }

    @Test
    public void testInvalidRole() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John Snow",
                "1234567890",
                "USER",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.role.isValid());
        assertNotNull(signup.role.getErrorMsg());
    }

    @Test
    public void testMultipleInvalid() {
        RegistrationScreen signup = new RegistrationScreen(
                "invalid-email",
                "short",
                "123Name",
                "12abc",
                "USER",
                "What is your pet's name?",
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.email.isValid());
        assertFalse(signup.password.isValid());
        assertFalse(signup.name.isValid());
        assertFalse(signup.contactNum.isValid());
        assertFalse(signup.role.isValid());
    }

    @Test
    public void testInvalidSecurityQuestion() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John Snow",
                "1234567890",
                "student",
                "",  // empty question
                "fluffy"
        );

        signup.validateAll();

        assertFalse(signup.securityQuestion.isValid());
        assertNotNull(signup.securityQuestion.getErrorMsg());
    }

    @Test
    public void testInvalidSecurityAnswer() {
        RegistrationScreen signup = new RegistrationScreen(
                "user@example.com",
                "Password1",
                "John Snow",
                "1234567890",
                "student",
                "What is your pet's name?",
                ""  // empty answer
        );

        signup.validateAll();

        assertFalse(signup.securityAnswer.isValid());
        assertNotNull(signup.securityAnswer.getErrorMsg());
    }
}