package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import android.content.Context;
import android.widget.TextView;

import androidx.test.core.app.ApplicationProvider;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.views.StudentDashboardActivity;
import com.example.csci3130_group21_project.views.TutorDashboardActivity;
import com.google.firebase.FirebaseApp;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36)
public class TutorDashboardRobolectricTest {
    @Mock
    private Dashboard mockDashboard;

    @Mock
    private SearchTutorial mockSearchTutorial;

    private TutorDashboardActivity activity;

    ActivityController<TutorDashboardActivity> controller;
    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        when(mockDashboard.getUserStatus()).thenReturn("Tutor");
        when(mockDashboard.getWelcomeMessage()).thenReturn("Welcome to Dal Tutor App");

        this.controller = Robolectric.buildActivity(TutorDashboardActivity.class);
        this.activity = controller.get();

        activity.setDashboard(mockDashboard);
        activity.setSearchTutorial(mockSearchTutorial);

        controller.create().start().resume().visible();
    }

    @Test
    public void checkIfUserRoleExists() {
        TextView userRole = activity.findViewById(R.id.userStatus);
        assertNotNull(userRole);
        assertEquals("Tutor", userRole.getText().toString());
    }

    @Test
    public void checkIfWelcomeMessageExists(){
        TextView welcomeMessage = activity.findViewById(R.id.welcomeMessage);
        assertNotNull(welcomeMessage);
        assertEquals("Welcome to Dal Tutor App", welcomeMessage.getText().toString());
    }

}
