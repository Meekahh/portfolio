package com.example.csci3130_group21_project.core;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashMap;

public class TutorialRegistrationManagerTest {

    @Mock
    private Tutorial mockTutorial;

    private TutorialRegistrationManager manager;
    private final String studentId = "student123";

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        manager = new TutorialRegistrationManager(mockTutorial);
    }

    @Test
    public void testHasSpace_ReturnsTrueWhenAvailable() {
        when(mockTutorial.getStudentCount()).thenReturn(5);
        when(mockTutorial.getMaxStudents()).thenReturn(10);
        
        assertTrue("Should have space when current count is less than max", manager.hasSpace());
    }

    @Test
    public void testHasSpace_ReturnsFalseWhenFull() {
        when(mockTutorial.getStudentCount()).thenReturn(10);
        when(mockTutorial.getMaxStudents()).thenReturn(10);
        
        assertFalse("Should not have space when tutorial is full", manager.hasSpace());
    }

    @Test
    public void testIsStudentAlreadyRegistered_ReturnsTrue() {
        HashMap<String, String> registrations = new HashMap<>();
        registrations.put(studentId, "CONFIRMED");
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrations);
        
        assertTrue("Should return true if student ID is in registrations", manager.isStudentAlreadyRegistered(studentId));
    }

    @Test
    public void testIsStudentAlreadyRegistered_ReturnsFalse() {
        when(mockTutorial.getRegistrationsMap()).thenReturn(new HashMap<>());

        assertFalse("Should return false if student ID is not in registrations", manager.isStudentAlreadyRegistered(studentId));
    }

    @Test
    public void testRegisterStudent_Success() {
        HashMap<String, String> registrations = new HashMap<>();
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrations);
        when(mockTutorial.getStudentCount()).thenReturn(0);
        when(mockTutorial.getMaxStudents()).thenReturn(5);

        String result = manager.registerStudent(studentId);

        assertEquals("SUCCESS", result);
        assertTrue("Student should be added to registrations", registrations.containsKey(studentId));
        assertEquals("CONFIRMED", registrations.get(studentId));
        verify(mockTutorial).setStudentCount(1);
    }

    @Test
    public void testRegisterStudent_FailsWhenAlreadyRegistered() {
        HashMap<String, String> registrations = new HashMap<>();
        registrations.put(studentId, "CONFIRMED");
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrations);

        String result = manager.registerStudent(studentId);

        assertEquals("ALREADY_REGISTERED", result);
        verify(mockTutorial, never()).setStudentCount(anyInt());
    }

    @Test
    public void testRegisterStudent_FailsWhenTutorialFull() {
        when(mockTutorial.getRegistrationsMap()).thenReturn(new HashMap<>());
        when(mockTutorial.getStudentCount()).thenReturn(10);
        when(mockTutorial.getMaxStudents()).thenReturn(10);

        String result = manager.registerStudent(studentId);

        assertEquals("TUTORIAL_FULL", result);
        verify(mockTutorial, never()).setStudentCount(anyInt());
    }
}
