package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import android.app.Activity;
import android.widget.EditText;
import android.widget.TextView;

import com.example.csci3130_group21_project.core.LoginValidator;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.example.csci3130_group21_project.views.LoginActivity;
import com.example.csci3130_group21_project.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class RoboElectricLoginTest {

    private ActivityController<LoginActivity> controller;
    private LoginActivity activity;

    @Mock
    private LoginValidator mockValidator;

    @Mock
    private FirebaseManager mockFirebaseManager;
    
    @Mock
    private DatabaseReference mockDatabaseRef;
    
    @Mock
    private DataSnapshot mockSnapshot;

    @Before
    public void setup() {

        MockitoAnnotations.openMocks(this);

        controller = Robolectric.buildActivity(LoginActivity.class);
        activity = controller.get();

        activity.setLoginValidator(mockValidator);
        activity.setFirebaseManager(mockFirebaseManager);
        
        // Mock role fetch process
        when(mockFirebaseManager.getDatabaseReference()).thenReturn(mockDatabaseRef);
        when(mockDatabaseRef.child(anyString())).thenReturn(mockDatabaseRef);
        
        Task<DataSnapshot> mockGetTask = Tasks.forResult(mockSnapshot);
        when(mockDatabaseRef.get()).thenReturn(mockGetTask);
        when(mockSnapshot.exists()).thenReturn(true);
        when(mockSnapshot.getValue(String.class)).thenReturn("student");

        controller.create().start().resume();
    }

    @Test
    public void testInvalidEmail_ShowsErrorMessage() {
        when(mockValidator.validateEmail(anyString())).thenReturn(false);
        when(mockValidator.validatePassword(anyString())).thenReturn(true);

        clickLoginButton();

        TextView messageLabel = activity.findViewById(R.id.messageLabel);
        assertEquals("INVALID_EMAIL_OR_PASSWORD", messageLabel.getText().toString());

        verify(mockFirebaseManager, never()).signIn(any(Activity.class), anyString(), anyString(), any(OnCompleteListener.class));
    }

    @Test
    public void testInvalidPassword_ShowsErrorMessage() {
        when(mockValidator.validateEmail(anyString())).thenReturn(true);
        when(mockValidator.validatePassword(anyString())).thenReturn(false);

        clickLoginButton();

        TextView messageLabel = activity.findViewById(R.id.messageLabel);
        assertEquals("INVALID_EMAIL_OR_PASSWORD", messageLabel.getText().toString());

        verify(mockFirebaseManager, never()).signIn(any(Activity.class), anyString(), anyString(), any(OnCompleteListener.class));
    }

    @Test
    public void testValidCredentials_AndSuccessfulLogin_ShowsSuccessMessage() {
        when(mockValidator.validateEmail(anyString())).thenReturn(true);
        when(mockValidator.validatePassword(anyString())).thenReturn(true);
        
        Task<AuthResult> successfulTask = Tasks.forResult(null);
        FirebaseUser mockUser = mock(FirebaseUser.class);
        when(mockFirebaseManager.getCurrentUser()).thenReturn(mockUser);
        when(mockUser.getUid()).thenReturn("test_uid");

        doAnswer(invocation -> {
            OnCompleteListener<AuthResult> listener = invocation.getArgument(3);
            listener.onComplete(successfulTask);
            return null;
        }).when(mockFirebaseManager).signIn(any(Activity.class), anyString(), anyString(), any(OnCompleteListener.class));

        setCredentialsAndClick("test@dal.ca", "password123");

        TextView messageLabel = activity.findViewById(R.id.messageLabel);
        assertEquals("LOGIN_SUCCESSFUL", messageLabel.getText().toString());
    }

    @Test
    public void testValidCredentials_AndFailedLogin_ShowsFailedMessage() {
        when(mockValidator.validateEmail(anyString())).thenReturn(true);
        when(mockValidator.validatePassword(anyString())).thenReturn(true);

        Task<AuthResult> failedTask = Tasks.forException(new Exception("Login failed"));

        doAnswer(invocation -> {
            OnCompleteListener<AuthResult> listener = invocation.getArgument(3);
            listener.onComplete(failedTask);
            return null;
        }).when(mockFirebaseManager).signIn(any(Activity.class), anyString(), anyString(), any(OnCompleteListener.class));

        setCredentialsAndClick("test@dal.ca", "password123");

        TextView messageLabel = activity.findViewById(R.id.messageLabel);
        assertEquals("INVALID_CREDENTIALS", messageLabel.getText().toString());
    }

    // Helper method
    private void clickLoginButton() {
        activity.findViewById(R.id.loginButton).performClick();
    }

    private void setCredentialsAndClick(String email, String password) {
        EditText emailField = activity.findViewById(R.id.emailAddress);
        EditText passwordField = activity.findViewById(R.id.password);
        emailField.setText(email);
        passwordField.setText(password);
        clickLoginButton();
    }
}
