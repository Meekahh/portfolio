package com.example.csci3130_group21_project;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.Tutorial;
import com.example.csci3130_group21_project.core.TutorialRegistrationManager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TutorialRegistrationManagerTest {

    @Mock
    private Tutorial mockTutorial;

    private TutorialRegistrationManager manager;
    private final String studentId = "student123";

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        manager = new TutorialRegistrationManager(mockTutorial);
    }

    @Test
    public void testHasSpace_ReturnsTrueWhenAvailable() {
        when(mockTutorial.getStudentCount()).thenReturn(5);
        when(mockTutorial.getMaxStudents()).thenReturn(10);
        
        assertTrue("Should have space when current count is less than max", manager.hasSpace());
    }

    @Test
    public void testHasSpace_ReturnsFalseWhenFull() {
        when(mockTutorial.getStudentCount()).thenReturn(10);
        when(mockTutorial.getMaxStudents()).thenReturn(10);
        
        assertFalse("Should not have space when tutorial is full", manager.hasSpace());
    }

    @Test
    public void testIsStudentAlreadyRegistered_ReturnsTrue() {
        HashMap<String, String> registrationsMap = new HashMap<>();
        registrationsMap.put(studentId, "CONFIRMED");
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrationsMap);
        
        assertTrue("Should return true if student ID is in registrations", manager.isStudentAlreadyRegistered(studentId));
    }

    @Test
    public void testIsStudentAlreadyRegistered_ReturnsFalse() {
        when(mockTutorial.getRegistrationsMap()).thenReturn(new HashMap<>());
        
        assertFalse("Should return false if student ID is not in registrations", manager.isStudentAlreadyRegistered(studentId));
    }

    @Test
    public void testRegisterStudent_Success() {
        HashMap<String, String> registrationsMap = new HashMap<>();
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrationsMap);
        when(mockTutorial.getStudentCount()).thenReturn(0);
        when(mockTutorial.getMaxStudents()).thenReturn(5);

        String result = manager.registerStudent(studentId);

        assertEquals("SUCCESS", result);
        verify(mockTutorial).addRegistration(any(Registration.class));
        verify(mockTutorial).setStudentCount(1);
    }

    @Test
    public void testRegisterStudent_FailsWhenAlreadyRegistered() {
        HashMap<String, String> registrationsMap = new HashMap<>();
        registrationsMap.put(studentId, "CONFIRMED");
        when(mockTutorial.getRegistrationsMap()).thenReturn(registrationsMap);

        String result = manager.registerStudent(studentId);

        assertEquals("ALREADY_REGISTERED", result);
        verify(mockTutorial, never()).setStudentCount(anyInt());
    }

    @Test
    public void testRegisterStudent_FailsWhenTutorialFull() {
        when(mockTutorial.getRegistrationsMap()).thenReturn(new HashMap<>());
        when(mockTutorial.getStudentCount()).thenReturn(10);
        when(mockTutorial.getMaxStudents()).thenReturn(10);

        String result = manager.registerStudent(studentId);

        assertEquals("TUTORIAL_FULL", result);
        verify(mockTutorial, never()).setStudentCount(anyInt());
    }
}
