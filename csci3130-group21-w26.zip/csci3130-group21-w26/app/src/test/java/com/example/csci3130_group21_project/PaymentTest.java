package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.example.csci3130_group21_project.core.PaymentNotification;
import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.Tutorial;

import org.junit.Test;

import java.util.List;

public class PaymentTest {
    @Test
    public void testTutorCanSeeStudentWithActiveRegistration() {
        Tutorial tutorial = new Tutorial("CSCI 3130");
        Registration registration = new Registration("student123","Pending");
        registration.pay();
        tutorial.addRegistration(registration);

        List<Registration> registrations = tutorial.getRegistrations();
        assertEquals(1, registrations.size());
        assertEquals("student123", registrations.get(0).getStudentName());
        assertEquals("CONFIRMED", registrations.get(0).getStatus());
        assertTrue(registrations.get(0).getPay());
    }

    @Test
    public void testTutorReceivesConfirmationWhenPaymentSuccessful() {
        Registration registration = new Registration("student123","Pending");
        registration.pay();
        String notification = PaymentNotification.notify(registration);
        assertNotNull(notification);
        assertEquals("Payment confirmed for student123", notification);
    }

    @Test
    public void testTutorDoesNotReceivesConfirmationWhenNoPaymentMade() {
        Registration registration = new Registration("student123","Pending");
        String notification = PaymentNotification.notify(registration);
        assertNull(notification);
    }

    @Test
    public void testPaidRegisterInformationIsRecorded() {
        Tutorial tutorial = new Tutorial("CSCI 3130");
        tutorial.setMaxStudents(5);

        Registration reg1 = new Registration("student123", "PENDING");
        Registration reg2 = new Registration("student456", "PENDING");
        reg1.pay();

        tutorial.addRegistration(reg1);
        tutorial.addRegistration(reg2);

        Registration recorded = tutorial.getRegistrations()
                .stream()
                .filter(r -> r.getStudentName().equals("student123"))
                .findFirst()
                .orElse(null);

        assertNotNull(recorded);
        assertTrue(recorded.getPay());
        assertEquals("CONFIRMED", recorded.getStatus());
    }

    @Test
    public void testNotPaidRegisterInformationIsRecorded() {
        Tutorial tutorial = new Tutorial("CSCI 3130");
        tutorial.setMaxStudents(5);

        Registration reg1 = new Registration("student123", "PENDING");
        Registration reg2 = new Registration("student456", "PENDING");
        reg1.pay();

        tutorial.addRegistration(reg1);
        tutorial.addRegistration(reg2);

        Registration recorded = tutorial.getRegistrations()
                .stream()
                .filter(r -> r.getStudentName().equals("student456"))
                .findFirst()
                .orElse(null);

        assertNotNull(recorded);
        assertFalse(recorded.getPay());
        assertEquals("PENDING", recorded.getStatus());
    }


        // Student payment
    @Test
    public void testStudentPaySuccess() {
        Registration reg = new Registration("student123", "PENDING");
        reg.pay();
        assertTrue(reg.getPay());
    }

    @Test
    public void testStudentStatusActive() {
        Registration reg = new Registration("student123", "PENDING");
        reg.pay();
        assertEquals("CONFIRMED", reg.getStatus());
    }

    @Test
    public void testStudentShowConfirm() {
        Registration reg = new Registration("student123", "PENDING");
        reg.pay();
        assertNotNull(PaymentNotification.notify(reg));
    }
}
