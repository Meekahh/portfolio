package com.example.csci3130_group21_project;

import static org.junit.Assert.*;

import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.Tutorial;

import org.junit.Test;

import java.util.List;

public class ViewRegistrationsTest {

    @Test
    public void testRegisteredStudentsAreListed() {

        Tutorial tutorial = new Tutorial("Java Programming");

        tutorial.addRegistration(new Registration("Joe", "CONFIRMED"));
        tutorial.addRegistration(new Registration("Bob", "CONFIRMED"));

        List<Registration> registrations = tutorial.getRegistrations();

        assertEquals(2, registrations.size());
    }

    @Test
    public void testRegistrationShowsStudentNameAndStatus() {

        Tutorial tutorial = new Tutorial("Java Programming");

        Registration reg = new Registration("Joe", "CONFIRMED");
        tutorial.addRegistration(reg);

        Registration stored = tutorial.getRegistrations().get(0);

        assertEquals("Joe", stored.getStudentName());
        assertEquals("CONFIRMED", stored.getStatus());
    }

    @Test
    public void testEmptyRegistrationsList() {

        Tutorial tutorial = new Tutorial("Java Programming");

        List<Registration> registrations = tutorial.getRegistrations();

        assertTrue(registrations.isEmpty());
    }

    @Test
    public void testTotalRegisteredStudentsCount() {

        Tutorial tutorial = new Tutorial("Java Programming");

        tutorial.addRegistration(new Registration("Joe", "CONFIRMED"));
        tutorial.addRegistration(new Registration("Bob", "CONFIRMED"));
        tutorial.addRegistration(new Registration("Ben", "CONFIRMED"));

        int total = tutorial.getRegistrations().size();

        assertEquals(3, total);
    }
}
