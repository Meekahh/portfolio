package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.core.Tutorial;
import com.example.csci3130_group21_project.views.StudentDashboardActivity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import java.util.ArrayList;
import java.util.List;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class StudentDashboardAfterSearchTest {

    @Mock
    private SearchTutorial mockSearchTutorial;

    @Mock
    private Dashboard mockDashboard;

    private StudentDashboardActivity activity;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        when(mockDashboard.getUserStatus()).thenReturn("Student");
        when(mockDashboard.getWelcomeMessage()).thenReturn("Welcome");

        ActivityController<StudentDashboardActivity> controller = Robolectric.buildActivity(StudentDashboardActivity.class);
        activity = controller.get();
        
        activity.setDashboard(mockDashboard);
        activity.setSearchTutorial(mockSearchTutorial);

        controller.create().start().resume().visible();
    }

    @Test
    public void testRecyclerViewUpdatesAfterSearch() {
        ArgumentCaptor<SearchTutorial.FirebaseCallback> callbackCaptor = ArgumentCaptor.forClass(SearchTutorial.FirebaseCallback.class);
        verify(mockSearchTutorial).getAllTutorials(callbackCaptor.capture());

        List<Tutorial> mockList = new ArrayList<>();
        mockList.add(mock(Tutorial.class));
        mockList.add(mock(Tutorial.class));

        callbackCaptor.getValue().onCallback(mockList);

        RecyclerView recyclerView = activity.findViewById(R.id.recyclerView);
        assertEquals(2, recyclerView.getAdapter().getItemCount());
    }
}
