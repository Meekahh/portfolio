package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.test.core.app.ApplicationProvider;

import com.example.csci3130_group21_project.database.FirebaseManager;
import com.example.csci3130_group21_project.views.LoginActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowLooper;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class FirebaseLoginTest {

    private LoginActivity activity;

    @Mock
    private FirebaseAuth mAuth;

    @Mock
    private Task<AuthResult> mTask;

    @Mock
    private FirebaseDatabase mockDatabase;

    @Mock
    private DatabaseReference mockDatabaseRef;

    @Mock
    private FirebaseManager mockFirebaseManager;

    @Mock
    private FirebaseUser mockUser;

    @Mock
    private DataSnapshot mockSnapshot;

    private MockedStatic<FirebaseAuth> mockedAuthStatic;
    private MockedStatic<FirebaseDatabase> mockedDatabaseStatic;
    private MockedStatic<FirebaseManager> mockedManagerStatic;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        if (FirebaseApp.getApps(ApplicationProvider.getApplicationContext()).isEmpty()) {
            FirebaseApp.initializeApp(ApplicationProvider.getApplicationContext());
        }

        mockedAuthStatic = Mockito.mockStatic(FirebaseAuth.class);
        mockedAuthStatic.when(FirebaseAuth::getInstance).thenReturn(mAuth);

        mockedDatabaseStatic = Mockito.mockStatic(FirebaseDatabase.class);
        mockedDatabaseStatic.when(FirebaseDatabase::getInstance).thenReturn(mockDatabase);
        when(mockDatabase.getReference(anyString())).thenReturn(mockDatabaseRef);

        mockedManagerStatic = Mockito.mockStatic(FirebaseManager.class);
        mockedManagerStatic.when(FirebaseManager::getInstance).thenReturn(mockFirebaseManager);
        
        when(mockFirebaseManager.getCurrentUser()).thenReturn(mockUser);
        when(mockUser.getUid()).thenReturn("test_uid");
        
        when(mockFirebaseManager.getDatabaseReference()).thenReturn(mockDatabaseRef);
        when(mockDatabaseRef.child(anyString())).thenReturn(mockDatabaseRef);
        
        Task<DataSnapshot> mockGetTask = Tasks.forResult(mockSnapshot);
        when(mockDatabaseRef.get()).thenReturn(mockGetTask);
        when(mockSnapshot.exists()).thenReturn(true);
        when(mockSnapshot.getValue(String.class)).thenReturn("student");

        activity = Robolectric.buildActivity(LoginActivity.class).create().start().resume().get();
    }

    @After
    public void tearDown() {
        if (mockedAuthStatic != null) {
            mockedAuthStatic.close();
        }
        if (mockedDatabaseStatic != null) {
            mockedDatabaseStatic.close();
        }
        if (mockedManagerStatic != null) {
            mockedManagerStatic.close();
        }
    }

    @Test
    public void testLoginSuccess() {
        EditText email = activity.findViewById(R.id.emailAddress);
        EditText password = activity.findViewById(R.id.password);
        Button loginButton = activity.findViewById(R.id.loginButton);
        TextView message = activity.findViewById(R.id.messageLabel);

        email.setText("ab123456@dal.ca");
        password.setText("ValidPass123!");

        when(mTask.isSuccessful()).thenReturn(true);

        doAnswer(invocation -> {
            OnCompleteListener<AuthResult> listener = invocation.getArgument(3);
            if (listener != null) {
                listener.onComplete(mTask);
            }
            return null;
        }).when(mockFirebaseManager).signIn(
                any(Activity.class),
                eq("ab123456@dal.ca"),
                eq("ValidPass123!"),
                any(OnCompleteListener.class)
        );

        loginButton.performClick();

        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();

        verify(mockFirebaseManager).signIn(
                any(Activity.class),
                eq("ab123456@dal.ca"),
                eq("ValidPass123!"),
                any(OnCompleteListener.class)
        );

        assertEquals("LOGIN_SUCCESSFUL", message.getText().toString());
    }

    @Test
    public void testLoginFailure() {
        EditText email = activity.findViewById(R.id.emailAddress);
        EditText password = activity.findViewById(R.id.password);
        Button loginButton = activity.findViewById(R.id.loginButton);
        TextView message = activity.findViewById(R.id.messageLabel);

        email.setText("ab123456@dal.ca");
        password.setText("ValidPass123!");

        when(mTask.isSuccessful()).thenReturn(false);

        doAnswer(invocation -> {
            OnCompleteListener<AuthResult> listener = invocation.getArgument(3);
            if (listener != null) {
                listener.onComplete(mTask);
            }
            return null;
        }).when(mockFirebaseManager).signIn(
                any(Activity.class),
                eq("ab123456@dal.ca"),
                eq("ValidPass123!"),
                any(OnCompleteListener.class)
        );

        loginButton.performClick();
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();

        verify(mockFirebaseManager).signIn(
                any(Activity.class),
                eq("ab123456@dal.ca"),
                eq("ValidPass123!"),
                any(OnCompleteListener.class)
        );

        assertEquals("INVALID_CREDENTIALS", message.getText().toString());
    }

    @Test
    public void testInvalidEmail() {
        EditText email = activity.findViewById(R.id.emailAddress);
        EditText password = activity.findViewById(R.id.password);
        Button loginButton = activity.findViewById(R.id.loginButton);
        TextView message = activity.findViewById(R.id.messageLabel);

        email.setText("invalid-email");
        password.setText("ValidPass123!");

        loginButton.performClick();
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();

        assertEquals("INVALID_EMAIL_OR_PASSWORD", message.getText().toString());
    }

    @Test
    public void testInvalidPassword() {
        EditText email = activity.findViewById(R.id.emailAddress);
        EditText password = activity.findViewById(R.id.password);
        Button loginButton = activity.findViewById(R.id.loginButton);
        TextView message = activity.findViewById(R.id.messageLabel);

        email.setText("ab123456@dal.ca");
        password.setText("short");

        loginButton.performClick();
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks();

        assertEquals("INVALID_EMAIL_OR_PASSWORD", message.getText().toString());
    }
}
