package com.example.csci3130_group21_project;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.core.Tutorial;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

public class SearchTutorialTest {

    @Mock
    private DatabaseReference mockDatabaseReference;

    @Mock
    private SearchTutorial.FirebaseCallback mockCallback;

    @Mock
    private DataSnapshot mockDataSnapshot;

    @Mock
    private DatabaseError mockDatabaseError;

    private SearchTutorial searchTutorial;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        searchTutorial = new SearchTutorial(mockDatabaseReference);
    }

    @Test
    public void testGetAllTutorials_Success() {
        Tutorial mockTutorial = mock(Tutorial.class);
        DataSnapshot childSnapshot = mock(DataSnapshot.class);
        
        when(mockDataSnapshot.getChildren()).thenReturn(Collections.singletonList(childSnapshot));
        when(childSnapshot.getValue(Tutorial.class)).thenReturn(mockTutorial);

        searchTutorial.getAllTutorials(mockCallback);
        ArgumentCaptor<ValueEventListener> listenerCaptor = ArgumentCaptor.forClass(ValueEventListener.class);
        verify(mockDatabaseReference).addListenerForSingleValueEvent(listenerCaptor.capture());

        listenerCaptor.getValue().onDataChange(mockDataSnapshot);

        verify(mockCallback).onCallback(any(List.class));
    }

    @Test
    public void testGetAllTutorials_Error() {
        when(mockDatabaseError.getMessage()).thenReturn("Database error");

        searchTutorial.getAllTutorials(mockCallback);
        ArgumentCaptor<ValueEventListener> listenerCaptor = ArgumentCaptor.forClass(ValueEventListener.class);
        verify(mockDatabaseReference).addListenerForSingleValueEvent(listenerCaptor.capture());

        listenerCaptor.getValue().onCancelled(mockDatabaseError);

        verify(mockCallback).onError("Database error");
    }
}
