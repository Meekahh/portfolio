package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.robolectric.Shadows.shadowOf;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.views.StudentDashboardActivity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class StudentDashboardLogoutTest {

    @Mock
    private Dashboard mockDashboard;

    private StudentDashboardActivity activity;

    ActivityController<StudentDashboardActivity> controller;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        this.controller = Robolectric.buildActivity(StudentDashboardActivity.class);
        this.activity = controller.get();

        activity.setDashboard(mockDashboard);

        controller.create().start().resume().visible();
    }

    @Test
    public void logoutButtonIsVisibleTest() {
        Button logoutButton = activity.findViewById(R.id.logoutButton);
        assertNotNull(logoutButton);
        assertEquals(View.VISIBLE, logoutButton.getVisibility());
    }

    @Test
    public void logoutButtonSingleClickNavigatesAwayTest() {
        activity.findViewById(R.id.logoutButton).performClick();
        Intent intent = shadowOf(activity).getNextStartedActivity();
        assertNotNull("A single click should trigger navigation away from dashboard", intent);
    }
}
