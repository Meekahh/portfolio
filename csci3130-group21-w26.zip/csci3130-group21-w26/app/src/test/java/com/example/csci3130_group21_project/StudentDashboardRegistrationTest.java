package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.core.Tutorial;
import com.example.csci3130_group21_project.views.StudentDashboardActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowToast;

import java.util.ArrayList;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class StudentDashboardRegistrationTest {

    @Mock
    private Dashboard mockDashboard;

    @Mock
    private SearchTutorial mockSearchTutorial;

    @Mock
    private FirebaseAuth mockAuth;

    @Mock
    private FirebaseUser mockUser;

    private StudentDashboardActivity activity;
    private ActivityController<StudentDashboardActivity> controller;
    private MockedStatic<FirebaseAuth> mockedFirebaseAuth;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        mockedFirebaseAuth = mockStatic(FirebaseAuth.class);
        mockedFirebaseAuth.when(FirebaseAuth::getInstance).thenReturn(mockAuth);
        
        when(mockAuth.getCurrentUser()).thenReturn(mockUser);
        when(mockUser.getUid()).thenReturn("test_user_id");

        when(mockDashboard.getUserStatus()).thenReturn("Student");
        when(mockDashboard.getWelcomeMessage()).thenReturn("Welcome to Dal Tutor App");

        controller = Robolectric.buildActivity(StudentDashboardActivity.class);
        activity = controller.get();
        
        activity.setDashboard(mockDashboard);
        activity.setSearchTutorial(mockSearchTutorial);

        controller.create().start().resume().visible();
    }

    @After
    public void tearDown() {
        if (mockedFirebaseAuth != null) {
            mockedFirebaseAuth.close();
        }
    }

    @Test
    public void testRegistrationSuccess() {
        Tutorial availableTutorial = new Tutorial();
        availableTutorial.setTitle("Java Basics");
        availableTutorial.setMaxStudents(10);
        availableTutorial.setStudentCount(5);
        availableTutorial.setRegistrations(new ArrayList<>());

        activity.onItemClick(availableTutorial);

        assertEquals("Registration Successful!", ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void testRegistrationAlreadyRegistered() {
        Tutorial registeredTutorial = new Tutorial();
        registeredTutorial.setTitle("Java Basics");
        registeredTutorial.setMaxStudents(10);
        registeredTutorial.setStudentCount(5);
        
        ArrayList<Registration> registrations = new ArrayList<>();
        registrations.add(new Registration("test_user_id", "CONFIRMED"));
        registeredTutorial.setRegistrations(registrations);

        activity.onItemClick(registeredTutorial);

        assertEquals("You are already registered for this session.", ShadowToast.getTextOfLatestToast());
    }

    @Test
    public void testRegistrationFull() {
        Tutorial fullTutorial = new Tutorial();
        fullTutorial.setTitle("Java Basics");
        fullTutorial.setMaxStudents(10);
        fullTutorial.setStudentCount(10);
        fullTutorial.setRegistrations(new ArrayList<>());

        activity.onItemClick(fullTutorial);

        assertEquals("This tutorial is full.", ShadowToast.getTextOfLatestToast());
    }
}
