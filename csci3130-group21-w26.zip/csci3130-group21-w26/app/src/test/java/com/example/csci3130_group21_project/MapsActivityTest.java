package com.example.csci3130_group21_project;

import static org.junit.Assert.*;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.csci3130_group21_project.database.TutorialSession;
import com.example.csci3130_group21_project.views.MapsActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MapsActivityTest {

    @Rule
    public ActivityScenarioRule<MapsActivity> activityRule =
            new ActivityScenarioRule<>(MapsActivity.class);

    @Test
    public void testMapLoaded() {

        activityRule.getScenario().onActivity(activity -> {

            // In unit tests, onMapReady() is never called because the Maps SDK
            // requires Google Play Services on a real device/emulator.
            // We verify the activity itself launched successfully instead.
            assertNotNull(activity);

            // placeholder: marker verification covered by instrumented tests
            boolean markersAdded = true;

            assertTrue(markersAdded);
        });
    }


    @Test
    public void testMarkersDisplayed() {

        activityRule.getScenario().onActivity(activity -> {

            // placeholder until multiple markers are implemented
            boolean multipleMarkersDisplayed = true;

            assertTrue(multipleMarkersDisplayed);
        });
    }

    @Test
    public void testMarkerClickShowsPopup() {

        activityRule.getScenario().onActivity(activity -> {

            // placeholder until marker click listener is implemented
            boolean popupDisplayed = true;

            assertTrue(popupDisplayed);
        });
    }

    @Test
    public void testPopupNavigatesToDetails() {

        activityRule.getScenario().onActivity(activity -> {

            // placeholder until navigation logic exists
            boolean navigatedToDetails = true;

            assertTrue(navigatedToDetails);
        });
    }

    // --- Unit tests for marker formatting logic ---
    // These test buildMarkerTitle() and buildMarkerSnippet() directly without
    // needing a real GoogleMap, since those methods are pure string formatting.

    @Test
    public void testTutorialSessionHasNoArgConstructor() {
        // Firebase requires a no-arg constructor to deserialize session data.
        // If someone removes it, Firebase crashes at runtime — catch it here.
        TutorialSession empty = new TutorialSession();
        assertNull(empty.tutorName);
        assertNull(empty.subject);
        assertEquals(0.0, empty.latitude, 0.0);
        assertEquals(0.0, empty.longitude, 0.0);
    }

    @Test
    public void testMarkerTitleContainsSubjectAndTutor() {
        MapsActivity activity = new MapsActivity();
        TutorialSession session = new TutorialSession();
        session.tutorName = "Ahmed";
        session.subject = "CSCI 2110";
        session.locationName = "Killam Library";
        session.date = "2026-03-15";
        session.time = "3:00 PM";

        String title = activity.buildMarkerTitle(session);

        assertTrue(title.contains("CSCI 2110"));
        assertTrue(title.contains("Ahmed"));
    }

    @Test
    public void testMarkerSnippetContainsLocationDateAndTime() {
        MapsActivity activity = new MapsActivity();
        TutorialSession session = new TutorialSession();
        session.tutorName = "Sara";
        session.subject = "MATH 1000";
        session.locationName = "Studley Gym";
        session.date = "2026-03-20";
        session.time = "2:00 PM";

        String snippet = activity.buildMarkerSnippet(session);

        assertTrue(snippet.contains("Studley Gym"));
        assertTrue(snippet.contains("2026-03-20"));
        assertTrue(snippet.contains("2:00 PM"));
    }

    @Test
    public void testDifferentSessionsProduceDifferentTitles() {
        MapsActivity activity = new MapsActivity();

        TutorialSession s1 = new TutorialSession();
        s1.tutorName = "Ahmed";
        s1.subject = "CSCI 2110";
        s1.locationName = "Killam";
        s1.date = "2026-03-15";
        s1.time = "3:00 PM";

        TutorialSession s2 = new TutorialSession();
        s2.tutorName = "Sara";
        s2.subject = "MATH 1000";
        s2.locationName = "Studley Gym";
        s2.date = "2026-03-20";
        s2.time = "2:00 PM";

        assertNotEquals(activity.buildMarkerTitle(s1), activity.buildMarkerTitle(s2));
    }

    @Test
    public void testDefaultCameraTargetIsHalifax() {
        // If this drifts, students open the map and see the wrong city.
        assertEquals(44.6366, MapsActivity.HALIFAX.latitude, 0.001);
        assertEquals(-63.5917, MapsActivity.HALIFAX.longitude, 0.001);
    }
}
