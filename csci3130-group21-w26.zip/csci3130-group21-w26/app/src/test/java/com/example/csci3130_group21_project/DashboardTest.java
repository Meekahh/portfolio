package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.database.UserData;

import org.junit.Test;


public class DashboardTest {

    @Test
    public void getUserStatusTest() {
        UserData mockUserData = mock(UserData.class);
        when(mockUserData.getUserStatus()).thenReturn("student");

        Dashboard dashboard = new Dashboard();
        dashboard.setUserData(mockUserData);
        String status = dashboard.getUserStatus();

        assertEquals("student", status);
    }

    @Test
    public void getWelcomeMessageTest() {
        UserData mockUserData = mock(UserData.class);
        when(mockUserData.getWelcomeMessage()).thenReturn("Welcome, Mock User!");

        Dashboard dashboard = new Dashboard();
        dashboard.setUserData(mockUserData);
        String message = dashboard.getWelcomeMessage();

        assertEquals("Welcome, Mock User!", message);
    }
}
