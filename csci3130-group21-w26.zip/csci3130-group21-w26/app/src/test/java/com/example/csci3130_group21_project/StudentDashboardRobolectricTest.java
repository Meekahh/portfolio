package com.example.csci3130_group21_project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import android.widget.TextView;

import androidx.test.core.app.ApplicationProvider;

import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.example.csci3130_group21_project.views.StudentDashboardActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseUser;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
public class StudentDashboardRobolectricTest {

    @Mock
    private Dashboard mockDashboard;

    @Mock
    private SearchTutorial mockSearchTutorial;

    @Mock
    private FirebaseManager mockFirebaseManager;

    @Mock
    private FirebaseUser mockUser;

    private StudentDashboardActivity activity;
    private MockedStatic<FirebaseManager> mockedManagerStatic;

    @Before
    public void setup(){
        MockitoAnnotations.openMocks(this);

        // Initialize FirebaseApp for the test environment
        if (FirebaseApp.getApps(ApplicationProvider.getApplicationContext()).isEmpty()) {
            FirebaseApp.initializeApp(ApplicationProvider.getApplicationContext());
        }

        mockedManagerStatic = mockStatic(FirebaseManager.class);
        mockedManagerStatic.when(FirebaseManager::getInstance).thenReturn(mockFirebaseManager);
        
        // Mock current user
        when(mockFirebaseManager.getCurrentUser()).thenReturn(mockUser);
        when(mockUser.getUid()).thenReturn("test_uid");

        when(mockDashboard.getUserStatus()).thenReturn("Student");
        when(mockDashboard.getWelcomeMessage()).thenReturn("Welcome to Dal Tutor App");

        ActivityController<StudentDashboardActivity> controller = Robolectric.buildActivity(StudentDashboardActivity.class);
        activity = controller.get();

        // Inject mocks before onCreate()
        activity.setDashboard(mockDashboard);
        activity.setSearchTutorial(mockSearchTutorial);

        controller.create().start().resume().visible();
    }

    @After
    public void tearDown() {
        if (mockedManagerStatic != null) {
            mockedManagerStatic.close();
        }
    }

    @Test
    public void testUserStatus() {
        TextView status = activity.findViewById(R.id.userStatus);
        assertNotNull(status);
        assertEquals("Student", status.getText().toString());
    }

    @Test
    public void testWelcomeMessage() {
        TextView welcomeMessage = activity.findViewById(R.id.welcomeMessage);
        assertNotNull(welcomeMessage);
        assertEquals("Welcome to Dal Tutor App", welcomeMessage.getText().toString());
    }
}
