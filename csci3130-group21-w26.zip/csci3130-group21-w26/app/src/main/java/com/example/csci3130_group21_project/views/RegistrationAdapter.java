package com.example.csci3130_group21_project.views;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.Registration;

import java.util.List;

public class RegistrationAdapter extends RecyclerView.Adapter<RegistrationAdapter.ViewHolder> {

    private List<Registration> registrationList;

    public RegistrationAdapter(List<Registration> registrationList) {
        this.registrationList = registrationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_registered_student, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Registration reg = registrationList.get(position);
        holder.studentName.setText(reg.getStudentName());
        holder.status.setText(reg.getStatus());
        
        if (reg.getPay()) {
            holder.paymentStatus.setVisibility(View.VISIBLE);
            holder.paymentStatus.setText("Paid for");
        } else {
            holder.paymentStatus.setVisibility(View.VISIBLE);
            holder.paymentStatus.setText("Not paid for");
            holder.paymentStatus.setTextColor(holder.itemView.getContext().getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    @Override
    public int getItemCount() {
        return registrationList.size();
    }

    public void updateData(List<Registration> newList) {
        this.registrationList = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView studentName, status, paymentStatus;

        public ViewHolder(View itemView) {
            super(itemView);
            studentName = itemView.findViewById(R.id.studentName);
            status = itemView.findViewById(R.id.registrationStatus);
            paymentStatus = itemView.findViewById(R.id.paymentStatus);
        }
    }
}
