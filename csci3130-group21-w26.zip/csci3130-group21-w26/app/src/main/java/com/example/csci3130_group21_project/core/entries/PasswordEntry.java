package com.example.csci3130_group21_project.core.entries;

import com.example.csci3130_group21_project.core.Entry;

public class PasswordEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.isEmpty()) {
            isValid = false;
            errorMsg = "Password is required";
            return;
        }

        if (content.length() != content.replaceAll("\\s+", "").length()) {
            isValid = false;
            errorMsg = "Password can't have any spaces";
            return;
        }

        if (content.length() < 8) {
            isValid = false;
            errorMsg = "Password must be at least 8 characters long";
            return;
        }

        if (!content.matches(".*\\d.*")) {
            isValid = false;
            errorMsg = "Password must contain at least one number";
            return;
        }

        super.validate();
    }
}
