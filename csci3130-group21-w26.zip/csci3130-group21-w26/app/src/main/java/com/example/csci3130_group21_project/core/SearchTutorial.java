package com.example.csci3130_group21_project.core;

import androidx.annotation.NonNull;

import com.example.csci3130_group21_project.database.FirebaseManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.ArrayList;


public class SearchTutorial {
    private FirebaseManager firebaseManager;
    private DatabaseReference databaseReference;

    public interface FirebaseCallback {
        void onCallback(List<Tutorial> list);
        void onError(String message);
    }

    // Default constructor for production
    public SearchTutorial(){
        this.firebaseManager = new FirebaseManager();
        this.databaseReference = firebaseManager.getDatabaseReference("tutorial");
    }

    public SearchTutorial(DatabaseReference databaseReference) {
        this.databaseReference = databaseReference;
    }

    public void getAllTutorials(FirebaseCallback callback) {
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Tutorial> tutorialList = new ArrayList<>();

                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    Tutorial tutorial = snapshot.getValue(Tutorial.class);
                    if (tutorial != null) {
                        tutorial.setTutorialId(snapshot.getKey());
                        tutorialList.add(tutorial);
                    }
                }

                if(callback != null) {
                    callback.onCallback(tutorialList);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (callback != null) {
                    callback.onError(error.getMessage());
                }
            }
        });
    }
}
