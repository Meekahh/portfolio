package com.example.csci3130_group21_project.core.entries;

import com.example.csci3130_group21_project.core.Entry;

public class ContactNumEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.isEmpty()) {
            isValid = false;
            errorMsg = "Contact Number is required";
            return;
        }

        String contactNum = content.replaceAll("[\\s()\\-]", "");
        String numRegex = "^\\d*$";

        if (contactNum.length() < 10) {
            isValid = false;
            errorMsg = "Contact Number is an incorrect length (ensure you include the area code)";
            return;
        }

        if (!contactNum.matches(numRegex)) {
            isValid = false;
            errorMsg = "Contact Number contains illegal characters";
            return;
        }

        super.validate();
    }
}
