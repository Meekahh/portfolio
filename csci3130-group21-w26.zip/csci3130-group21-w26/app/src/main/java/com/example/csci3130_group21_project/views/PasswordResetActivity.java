package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.HashUtil;
import com.example.csci3130_group21_project.database.FirebaseManager;

public class PasswordResetActivity extends AppCompatActivity {

    private EditText emailBox, answerBox, newPassBox;
    private TextView questionText;
    private Button nextBtn, resetBtn;
    private View answerLayout, newPasswordLayout, step2Divider;

    private FirebaseManager db;

    // saved after step 1
    private String foundUserKey = null;          // username key in Firebase
    private String foundAnswerHash = null;       // securityAnswerHash from Firebase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        emailBox = findViewById(R.id.resetEmail);
        answerBox = findViewById(R.id.resetAnswer);
        newPassBox = findViewById(R.id.resetNewPassword);
        questionText = findViewById(R.id.securityQuestionText);
        nextBtn = findViewById(R.id.nextButton);
        resetBtn = findViewById(R.id.resetPasswordButton);
        answerLayout = findViewById(R.id.answerLayout);
        newPasswordLayout = findViewById(R.id.newPasswordLayout);
        step2Divider = findViewById(R.id.step2Divider);

        // hide step 2 first
        questionText.setVisibility(View.GONE);
        answerLayout.setVisibility(View.GONE);
        newPasswordLayout.setVisibility(View.GONE);
        resetBtn.setVisibility(View.GONE);
        step2Divider.setVisibility(View.GONE);

        db = FirebaseManager.getInstance();

        nextBtn.setOnClickListener(v -> step1_findEmail());
        resetBtn.setOnClickListener(v -> step2_reset());
    }

    private void step1_findEmail() {
        String email = emailBox.getText().toString().trim();

        if (email.isEmpty()) {
            toast("enter your email");
            return;
        }

        db.findUserByEmail(email, result -> {
            if (!result.found) {
                toast("email not found");
                return;
            }

            // save for step 2
            foundUserKey = result.userKey;
            foundAnswerHash = result.securityAnswerHash;

            // show question + step2 ui
            questionText.setText(result.securityQuestion == null ? "Security Question" : result.securityQuestion);
            questionText.setVisibility(View.VISIBLE);
            answerLayout.setVisibility(View.VISIBLE);
            newPasswordLayout.setVisibility(View.VISIBLE);
            resetBtn.setVisibility(View.VISIBLE);
            step2Divider.setVisibility(View.VISIBLE);

            toast("email found, answer the question");
        });
    }

    private void step2_reset() {
        if (foundUserKey == null || foundAnswerHash == null) {
            toast("please enter email first");
            return;
        }

        String ans = answerBox.getText().toString().trim();
        String newPass = newPassBox.getText().toString().trim();

        if (ans.isEmpty() || newPass.isEmpty()) {
            toast("fill everything");
            return;
        }

        if (newPass.length() < 8) {
            toast("password needs 8+ chars");
            return;
        }

        // normalize answer
        String normalizedAns = ans.toLowerCase().trim();
        String ansHash = HashUtil.sha256(normalizedAns);

        if (!ansHash.equals(foundAnswerHash)) {
            toast("wrong answer");
            return;
        }

        String passHash = HashUtil.sha256(newPass);

        db.updatePasswordHash(foundUserKey, passHash, success -> {
            if (success) {
                toast("password changed. go login");
                finish();
            } else {
                toast("reset failed, try again");
            }
        });
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }
}
