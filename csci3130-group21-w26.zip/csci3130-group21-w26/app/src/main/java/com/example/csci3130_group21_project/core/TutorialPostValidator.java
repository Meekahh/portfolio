package com.example.csci3130_group21_project.core;
import java.util.ArrayList;
import java.util.List;

public class TutorialPostValidator {

    public static class ValidationResult{
        public final boolean isValid;
        public final List<String> error;

        public ValidationResult(boolean isValid, List<String> error){
            this.isValid = isValid;
            this.error = error;
        }

    }

    public ValidationResult validate(String title, String description, String subject,
                                     String location, String date, String time,
                                     String maxStudent, String duration, String fee) {
        List<String> error = new ArrayList<>();

        title = title == null ? "" : title;
        description = description == null ? "" : description;
        subject = subject == null ? "" : subject;
        location = location == null ? "" : location;
        date = date == null ? "" : date;
        time = time == null ? "" : time;
        maxStudent = maxStudent == null ? "" : maxStudent;
        duration = duration == null ? "" : duration;
        fee = fee == null ? "" : fee;

        if (title.isBlank()) {
            error.add("Title is missing pls add");
        }
        if (description.isBlank()) {
            error.add("Description is missing pls add");
        }
        if (subject.isBlank()) {
            error.add("subject is missing pls add");
        }
        if (location.isBlank()) {
            error.add("location is missing pls add");
        }
        if (date.isBlank()) {
            error.add("Date is missing pls add");
        }
        if (time.isBlank()) {
            error.add("time is missing pls add");
        }
        if (maxStudent.isBlank()) {
            error.add("max students is missing pls add");
        }
        if (duration.isBlank()) {
            error.add("duration is missing pls add");
        }
        if (fee.isBlank()) {
            error.add("fee is missing pls add");
        }

        if (!date.isBlank() && !date.trim().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            error.add("incorrect date");
        }

        if (!time.isBlank() && !time.trim().matches("^([01]\\d|2[0-3]):([0-5]\\d)$")) {
            error.add("incorrect time");
        }

        if (!maxStudent.isBlank()) {
            try {
                int max = Integer.parseInt(maxStudent.trim());
                if (max <= 0) {
                    error.add("Max student should not be zero");
                }
            } catch (Exception e) {
                error.add("max student must be number");
            }
        }

        if (!duration.isBlank()) {
            try {
                int d = Integer.parseInt(duration.trim());
                if (d <= 0) {
                    error.add("duration must be greater than zero");
                }
            } catch (Exception e) {
                error.add("duration must be number");
            }
        }

        if (!fee.isBlank()) {
            try {
                double f = Double.parseDouble(fee.trim());
                if (f < 0) {
                    error.add("fee cannot be negative");
                }
            } catch (Exception e) {
                error.add("fee must be number");
            }
        }

        return new ValidationResult(error.isEmpty(), error);
    }
}




