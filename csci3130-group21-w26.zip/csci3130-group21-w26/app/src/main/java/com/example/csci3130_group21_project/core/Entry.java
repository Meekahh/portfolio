package com.example.csci3130_group21_project.core;

public class Entry {
    protected String content;
    protected boolean isValid = false;
    protected String errorMsg;

    public void setContent(String incoming) {
        content = incoming;
    }

    public boolean isValid() {
        return isValid;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
    protected void validate() {
        isValid = true;
        errorMsg = null;
    }
}
