package com.example.csci3130_group21_project.core;

/**
 * Handles tutor payment notifications
 */
public class PaymentNotification {
        // Notify
    public static String notify(Registration reg) {
        if (reg.getPay()) {
            return "Payment confirmed for " + reg.getStudentName();
        }

        return null;
    }
}
