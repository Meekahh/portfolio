package com.example.csci3130_group21_project.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Tutorial implements Serializable {
        // Fields
    private String title, description, subject, tutorName, location, date, time;
    private double fee;
    private int duration, maxStudents, studentCount;
    private HashMap<String, String> registrations;
    private String tutorialId;


        // Init
    public Tutorial() {
        this.registrations = new LinkedHashMap<>();
    }

    public Tutorial(String title) {
        this.title = title;
        this.registrations = new LinkedHashMap<>();
    }


        // Get/Set
    public String getTitle() { return title; }
    public void setTitle(String t) { title = t; }

    public String getDescription() { return description; }
    public void setDescription(String d) { description = d; }

    public String getSubject() { return subject; }
    public void setSubject(String s) { subject = s; }

    public String getTutorName() { return tutorName; }
    public void setTutorName(String n) { tutorName = n; }

    public String getLocation() { return location; }
    public void setLocation(String l) { location = l; }

    public String getDate() { return date; }
    public void setDate(String d) { date = d; }

    public String getTime() { return time; }
    public void setTime(String t) { time = t; }

    public double getFee() { return fee; }
    public void setFee(double f) { fee = f; }

    public int getDuration() { return duration; }
    public void setDuration(int d) { duration = d; }

    public int getStudentCount() { return studentCount; }
    public void setStudentCount(int c) { studentCount = c; }

    public int getMaxStudents(){ return maxStudents; }
    public void setMaxStudents(int m){ maxStudents = m; }

    public String getTutorialId() { return tutorialId; }
    public void setTutorialId(String id) { tutorialId = id; }


        // Registry
    public HashMap<String, String> getRegistrationsMap() {
        if (registrations == null) registrations = new LinkedHashMap<>();
        return registrations;
    }

    public List<Registration> getRegistrations() {
        if (registrations == null) return new ArrayList<>();
        List<Registration> list = new ArrayList<>();
        for (Map.Entry<String, String> entry : registrations.entrySet()) {
            String val = entry.getValue();
            if (val != null && val.contains("|")) {
                String[] p = val.split("\\|");
                list.add(new Registration(entry.getKey(), p[0], Boolean.parseBoolean(p[1])));
            } else {
                list.add(new Registration(entry.getKey(), val));
            }
        }
        return list;
    }

    public void setRegistrations(List<Registration> list) {
        this.registrations = new LinkedHashMap<>();
        if (list != null) {
            for (Registration reg : list) addRegistration(reg);
        }
    }

    public void addRegistration(Registration reg) {
        if (registrations == null) registrations = new LinkedHashMap<>();
        registrations.put(reg.getStudentName(), reg.getStatus() + "|" + reg.getPay());
    }
}
