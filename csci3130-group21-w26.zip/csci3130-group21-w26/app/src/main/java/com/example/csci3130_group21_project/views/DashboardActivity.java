package com.example.csci3130_group21_project.views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.Dashboard;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.example.csci3130_group21_project.database.UserData;
import com.google.firebase.auth.FirebaseUser;

public abstract class DashboardActivity extends AppCompatActivity {

    private Dashboard dashboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (this.dashboard == null) {
            this.dashboard = new Dashboard();
            
            FirebaseUser user = FirebaseManager.getInstance().getCurrentUser();
            if (user != null) {
                this.dashboard.setUserData(new UserData(user));
            } else {
                // Fail-safe: Redirect to login if user session is lost
                redirectToLogin();
            }
        }
    }

    private void redirectToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void setDashboard(Dashboard dashboard) {
        this.dashboard = dashboard;
    }

    protected void updateCommonUI() {

        if (dashboard == null || dashboard.getUserStatus() == null) return;

        TextView userStatusView = findViewById(R.id.userStatus);
        TextView welcomeMessageView = findViewById(R.id.welcomeMessage);

        String statusText = dashboard.getUserStatus();
        String welcomeText = dashboard.getWelcomeMessage();

        if (userStatusView != null) userStatusView.setText(statusText);
        if (welcomeMessageView != null) welcomeMessageView.setText(welcomeText);
    }

    protected void setupLogout(int buttonId) {
        if (findViewById(buttonId) != null) {
            findViewById(buttonId).setOnClickListener(v -> {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            });
        }
    }
}
