package com.example.csci3130_group21_project.core.entries;

import com.example.csci3130_group21_project.core.Entry;

public class NameEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.isEmpty()) {
            isValid = false;
            errorMsg = "Name is required";
            return;
        }

        String nameRegex = "^[A-Za-z]+([ '-][A-Za-z]+)*$";

        if (!content.matches(nameRegex)) {
            isValid = false;
            errorMsg = "Name can only have letters, spaces, -, or '";
            return;
        }

        super.validate();
    }
}
