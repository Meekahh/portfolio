package com.example.csci3130_group21_project.database;

import android.app.Activity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.csci3130_group21_project.core.TutorialPost;

/**
 * A central class to manage Firebase instances for the application.
 */
public class FirebaseManager {
    private static FirebaseManager instance;
    private final FirebaseAuth mAuth;
    private final FirebaseDatabase database;
    private final DatabaseReference mDatabase;

    public FirebaseManager() {
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        mDatabase = database.getReference();
    }

    public static synchronized FirebaseManager getInstance() {
        if (instance == null) {
            instance = new FirebaseManager();
        }
        return instance;
    }

    public FirebaseAuth getAuth() {
        return mAuth;
    }

    public DatabaseReference getDatabaseReference() {
        return mDatabase;
    }

    public DatabaseReference getDatabaseReference(String path) {
        return mDatabase.child(path);
    }

    public DatabaseReference getDbRef() {
        return mDatabase;
    }

    public void signIn(Activity activity, String email, String password, OnCompleteListener<AuthResult> listener) {
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(activity, listener);
    }

    public FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    public void write(String value) {
        mDatabase.setValue(value);
    }

    public void read(ValueEventListener listener) {
        mDatabase.addValueEventListener(listener);
    }

    // Finds a user by matching user email.
    // Returns the matching username key + question + answerHash via callback.
    public void findUserByEmail(String email, UserLookupCallback cb) {
        mDatabase.get()
                .addOnSuccessListener(snapshot -> {
                    String target = email.trim().toLowerCase();

                    for (DataSnapshot userSnap : snapshot.getChildren()) {
                        String dbEmail = userSnap.child("email").getValue(String.class);
                        if (dbEmail == null) continue;

                        if (dbEmail.trim().toLowerCase().equals(target)) {
                            String key = userSnap.getKey();
                            String question = userSnap.child("securityQuestion").getValue(String.class);
                            String answerHash = userSnap.child("securityAnswerHash").getValue(String.class);

                            if (cb != null) cb.onResult(new UserLookupResult(true, key, question, answerHash));
                            return;
                        }
                    }

                    if (cb != null) cb.onResult(new UserLookupResult(false, null, null, null));
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onResult(new UserLookupResult(false, null, null, null));
                });
    }

    // Updates a user's password hash by their username key.
    public void updatePasswordHash(String usernameKey, String newHash, BoolCallback cb) {
        mDatabase.child(usernameKey)
                .child("passwordHash")
                .setValue(newHash)
                .addOnSuccessListener(unused -> {
                    if (cb != null) cb.onResult(true);
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onResult(false);
                });
    }

    // Callbacks and result types

    public interface BoolCallback {
        void onResult(boolean value);
    }

    public interface UserLookupCallback {
        void onResult(UserLookupResult result);
    }

    public static class UserLookupResult {
        public final boolean found;
        public final String userKey;
        public final String securityQuestion;
        public final String securityAnswerHash;

        public UserLookupResult(boolean found, String userKey, String securityQuestion, String securityAnswerHash) {
            this.found = found;
            this.userKey = userKey;
            this.securityQuestion = securityQuestion;
            this.securityAnswerHash = securityAnswerHash;
        }
    }

    public interface PostCreateCallback{
        void onSuccess(String postID);
        void onFailure(String message);
    }

    public void createTutorialPost(com.example.csci3130_group21_project.core.TutorialPost post, PostCreateCallback crCallback){
        DatabaseReference postsRef = mDatabase.child("tutorialPosts");
        String key = postsRef.push().getKey();

        if(key == null){
            if (crCallback != null) crCallback.onFailure("post id create fail");
            return;
        }

        post.postID = key;

        postsRef.child(key)
                .setValue(post)
                .addOnSuccessListener(unused -> {
                    if (crCallback != null) crCallback.onSuccess(key);
                })
                .addOnFailureListener(e -> {
                    if (crCallback != null) crCallback.onFailure(e.getMessage() == null ? "unknown error" : e.getMessage());
                });
    }

    public interface TutorialPostCallback {
        void onSuccess(TutorialPost post);
        void onFailure(String message);
    }

    public interface TutorialPostsCallback {
        void onSuccess(java.util.List<TutorialPost> posts);
        void onFailure(String message);
    }

    public void getTutorialPostById(String postId, TutorialPostCallback cb) {
        mDatabase.child("tutorialPosts").child(postId).get()
                .addOnSuccessListener(snapshot -> {
                    TutorialPost post = snapshot.getValue(TutorialPost.class);
                    if (post == null) {
                        if (cb != null) cb.onFailure("tutorial not found");
                    } else {
                        if (post.postID == null || post.postID.isEmpty()) {
                            post.postID = snapshot.getKey();
                        }
                        if (cb != null) cb.onSuccess(post);
                    }
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onFailure(e.getMessage() == null ? "unknown error" : e.getMessage());
                });
    }

    public void searchTutorialPosts(String keyword, TutorialPostsCallback cb) {
        mDatabase.child("tutorialPosts").get()
                .addOnSuccessListener(snapshot -> {

                    java.util.List<com.example.csci3130_group21_project.core.TutorialPost> posts =
                            new java.util.ArrayList<>();

                    String target = keyword == null ? "" : keyword.trim().toLowerCase();

                    for (DataSnapshot postSnap : snapshot.getChildren()) {
                        com.example.csci3130_group21_project.core.TutorialPost post =
                                postSnap.getValue(com.example.csci3130_group21_project.core.TutorialPost.class);

                        if (post == null) continue;

                        String title = post.title == null ? "" : post.title.toLowerCase();
                        String subject = post.subject == null ? "" : post.subject.toLowerCase();
                        String location = post.location == null ? "" : post.location.toLowerCase();
                        String description = post.description == null ? "" : post.description.toLowerCase();

                        if (title.contains(target) || subject.contains(target)
                                || location.contains(target) || description.contains(target)) {
                            posts.add(post);
                        }
                    }

                    if (cb != null) cb.onSuccess(posts);
                })
                .addOnFailureListener(e -> {
                    if (cb != null) cb.onFailure(e.getMessage() == null ? "unknown error" : e.getMessage());
                });
    }
}
