package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.TutorialPost;
import com.example.csci3130_group21_project.core.TutorialPostValidator;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.google.firebase.auth.FirebaseUser;

/**
 * Activity that allows a tutor to create and submit a new tutorial post.
 * Collects input from the user, validates all fields using {@link TutorialPostValidator},
 * and writes a new {@link TutorialPost} to Firebase on success.
 */
public class PostTutorialActivity extends AppCompatActivity {

    private EditText titleBox, descriptionBox, subjectBox, locationBox, dateBox, timeBox, maxStudentsBox;
    private EditText durationBox, feeBox;

    private TextView errorText;
    private Button postbtn;

    private final FirebaseManager db = FirebaseManager.getInstance();
    private final TutorialPostValidator validator = new TutorialPostValidator();

    /**
     * Initializes the activity, sets up the layout, and attaches the submit button listener.
     *
     * @param savedInstanceState the previously saved instance state, if any
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_tutorial);

        titleBox = findViewById(R.id.titleBox);
        descriptionBox = findViewById(R.id.descriptionBox);
        subjectBox = findViewById(R.id.subjectBox);
        locationBox = findViewById(R.id.locationBox);
        dateBox = findViewById(R.id.dateBox);
        timeBox = findViewById(R.id.timeBox);
        maxStudentsBox = findViewById(R.id.maxStudentsBox);

        durationBox = findViewById(R.id.durationBox);
        feeBox = findViewById(R.id.feeBox);

        errorText = findViewById(R.id.errorText);
        postbtn = findViewById(R.id.postBtn);

        postbtn.setOnClickListener(v -> submit());
    }

    /**
     * Reads all form fields, validates them, and submits a new {@link TutorialPost}
     * to Firebase if validation passes. Shows an error message if validation fails
     * or if the Firebase write is unsuccessful.
     */
    private void submit() {
        String title = titleBox.getText().toString();
        String description = descriptionBox.getText().toString();
        String subject = subjectBox.getText().toString();
        String location = locationBox.getText().toString();
        String date = dateBox.getText().toString();
        String time = timeBox.getText().toString();
        String maxStudents = maxStudentsBox.getText().toString();

        String duration = durationBox.getText().toString();
        String fee = feeBox.getText().toString();

        TutorialPostValidator.ValidationResult r =
                validator.validate(title, description, subject, location, date, time, maxStudents, duration, fee);

        if (!r.isValid) {
            showError(r);
            return;
        }

        hideError();
        postbtn.setEnabled(false);

        FirebaseUser u = db.getCurrentUser();
        String userId = (u == null) ? "" : u.getUid();
        String tutorName = (u == null || u.getDisplayName() == null) ? "" : u.getDisplayName();

        int maxStudent = Integer.parseInt(maxStudents.trim());
        int durationValue = Integer.parseInt(duration.trim());
        double feeValue = Double.parseDouble(fee.trim());

        TutorialPost post = new TutorialPost(
                title.trim(),
                description.trim(),
                subject.trim(),
                userId,
                tutorName,
                location.trim(),
                date.trim(),
                time.trim(),
                maxStudent,
                durationValue,
                feeValue
        );

        db.createTutorialPost(post, new FirebaseManager.PostCreateCallback() {
            @Override
            public void onSuccess(String postID) {
                postbtn.setEnabled(true);
                Toast.makeText(PostTutorialActivity.this, "Post create succesfully!!", Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onFailure(String message) {
                postbtn.setEnabled(true);
                errorText.setVisibility(TextView.VISIBLE);
                errorText.setText("Failed to create post: " + message);
            }
        });
    }

    /**
     * Displays the validation error messages returned by {@link TutorialPostValidator}.
     *
     * @param r the validation result containing the list of error messages to display
     */
    private void showError(TutorialPostValidator.ValidationResult r) {
        errorText.setVisibility(TextView.VISIBLE);
        StringBuilder sb = new StringBuilder();
        for (String e : r.error) {
            sb.append(" ").append(e).append("\n");
        }
        errorText.setText(sb.toString().trim());
    }

    /**
     * Hides the error text view and clears any previously displayed error message.
     */
    private void hideError() {
        errorText.setVisibility(TextView.GONE);
        errorText.setText("");
    }
}