package com.example.csci3130_group21_project.views;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.Tutorial;
import java.util.List;

public class TutorialSearchAdapter extends RecyclerView.Adapter<TutorialSearchAdapter.ViewHolder> {
    private List<Tutorial> tutorialList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Tutorial tutorial);
    }

    public TutorialSearchAdapter(List<Tutorial> tutorialList, OnItemClickListener listener) {
        this.tutorialList = tutorialList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_tutorial, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Tutorial tutorial = tutorialList.get(position);
        holder.title.setText(tutorial.getTitle());
        holder.description.setText(tutorial.getDescription());
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(tutorial);
            }
        });
    }

    @Override
    public int getItemCount() {
        return tutorialList.size();
    }

    public void updateData(List<Tutorial> newList) {
        this.tutorialList = newList;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, description;
        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tutorialTitle);
            description = itemView.findViewById(R.id.tutorialDescription);
        }
    }
}
