package com.example.csci3130_group21_project.core;

public class TutorialRegistrationManager {
    private final Tutorial tutorial;

    public TutorialRegistrationManager(Tutorial tutorial){
        this.tutorial = tutorial;
    }

    public boolean hasSpace() {
        return tutorial.getStudentCount() < tutorial.getMaxStudents();
    }

    public boolean isStudentAlreadyRegistered(String student) {
        return tutorial.getRegistrationsMap().containsKey(student);
    }

    /**
     * Attempts to register a student.
     * @return String message indicating success or specific failure reason.
     */
    public String registerStudent(String student) {
        if (isStudentAlreadyRegistered(student)) {
            return "ALREADY_REGISTERED";
        }

        if (!hasSpace()) {
            return "TUTORIAL_FULL";
        }

        tutorial.addRegistration(new Registration(student, "PENDING"));
        tutorial.setStudentCount(tutorial.getStudentCount() + 1);
        return "SUCCESS";
    }
}
