package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.Tutorial;

import java.util.ArrayList;
import java.util.List;

public class ViewRegistrationsActivity extends AppCompatActivity {

    public static final String EXTRA_TUTORIAL = "extra_tutorial";

    private TextView sessionTitle;
    private TextView registrationCount;
    private RecyclerView recyclerView;
    private TextView emptyStateMessage;
    private RegistrationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_registrations);

        sessionTitle = findViewById(R.id.sessionTitle);
        registrationCount = findViewById(R.id.registrationCount);
        recyclerView = findViewById(R.id.registrationsRecyclerView);
        emptyStateMessage = findViewById(R.id.emptyStateMessage);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RegistrationAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        Tutorial tutorial = (Tutorial) getIntent().getSerializableExtra(EXTRA_TUTORIAL);
        if (tutorial != null) {
            displayRegistrations(tutorial);
        } else {
            finish();
        }
    }

    private void displayRegistrations(Tutorial tutorial) {
        sessionTitle.setText(tutorial.getTitle() != null ? tutorial.getTitle() : "Session");

        List<Registration> registrations = tutorial.getRegistrations();
        int count = registrations.size();
        registrationCount.setText(count + " registered student" + (count != 1 ? "s" : ""));

        if (registrations.isEmpty()) {
            emptyStateMessage.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyStateMessage.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter.updateData(registrations);
        }
    }
}
