package com.example.csci3130_group21_project.core.entries;

import com.example.csci3130_group21_project.core.Entry;

public class RoleEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.isEmpty()) {
            isValid = false;
            errorMsg = "Role is required";
            return;
        }

        if ("student".equals(content) || "tutor".equals(content)) {
            super.validate();
        } else {
            isValid = false;
            errorMsg = "Role must be student or tutor";
        }
    }
}