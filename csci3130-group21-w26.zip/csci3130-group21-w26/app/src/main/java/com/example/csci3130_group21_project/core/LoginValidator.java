package com.example.csci3130_group21_project.core;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginValidator {

    /**
     * email has to follow dal email format i.e. "ab123456@dal.ca"
     * @param email email for login
     * @return true if its a valid email.
     */
    public boolean validateEmail(String email){


        if(email == null){
            return false;
        }

        String emailPattern = "^[a-zA-Z]{2}\\d{6}@dal\\.ca$";
        Pattern pattern = Pattern.compile(emailPattern);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    /**
     * Password must be at least 8 characters long, contain at least one digit,
     * and at least one special character.
     * @param password the password to validate
     * @return true if password meets the criteria
     */
    public boolean validatePassword(String password){
        if (password == null) {
            return false;
        }

        // Regex for: at least 8 chars, at least one digit, and at least one special character
        String passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$";
        Pattern pattern = Pattern.compile(passwordPattern);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

}
