package com.example.csci3130_group21_project.core.entries;

public class Post {

    public PostEntry title;
    public PostEntry subject;
    public PostEntry description;
    public PostEntry postCreator;
    public PostEntry location;
    public PostEntry date;
    public PostEntry time;
    public PostEntry maxStudents;

    public Post(
            String title,
            String subject,
            String description,
            String postCreator,
            String location,
            String date,
            String time,
            String maxStudents
    ) {
        this.title = new PostEntry(title);
        this.subject = new PostEntry(subject);
        this.description = new PostEntry(description);
        this.postCreator = new PostEntry(postCreator);
        this.location = new PostEntry(location);
        this.date = new PostEntry(date);
        this.time = new PostEntry(time);
        this.maxStudents = new PostEntry(maxStudents);
    }

    public void validateAll() {
        // TODO: implement validation logic
    }

    public static class PostEntry {
        /* If you don't want to use the nested class it's all good,
           that's just how it worked in my head lol
         */

        private final String value;

        private boolean valid = false;
        private String errorMsg;

        public PostEntry(String value) {
            this.value = value;
        }

        public boolean isValid() {
            return valid; // TODO: make isValid checks for the fields
        }

        public String getErrorMsg() {
            return errorMsg; // TODO: make error messages for the fields
        }
    }
}
