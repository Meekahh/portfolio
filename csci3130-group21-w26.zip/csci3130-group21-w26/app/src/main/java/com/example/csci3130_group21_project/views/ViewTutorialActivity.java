package com.example.csci3130_group21_project.views;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.TutorialPost;
import com.example.csci3130_group21_project.database.FirebaseManager;

/**
 * Activity that displays the full details of a tutorial post.
 * Requires a valid post ID passed via intent extra "postID".
 * Loads the post from Firebase and binds its fields to the UI.
 * Provides a register button if seats are available, and a map
 * button if the post has a location.
 */
public class ViewTutorialActivity extends AppCompatActivity {

    private TextView topicText;
    private TextView tutorText;
    private TextView dateTimeText;
    private TextView durationText;
    private TextView locationText;
    private TextView feeText;
    private TextView statusText;
    private TextView descriptionText;

    private Button registerBtn;
    private Button mapBtn;

    private final FirebaseManager db = FirebaseManager.getInstance();
    private TutorialPost currentPost;

    /**
     * Initializes the activity, retrieves the post ID from the intent,
     * loads the tutorial post from Firebase, and sets up button listeners.
     * Finishes immediately if no post ID is provided.
     *
     * @param savedInstanceState the previously saved instance state, if any
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_tutorial);

        topicText = findViewById(R.id.topicText);
        tutorText = findViewById(R.id.tutorText);
        dateTimeText = findViewById(R.id.dateTimeText);
        durationText = findViewById(R.id.durationText);
        locationText = findViewById(R.id.locationText);
        feeText = findViewById(R.id.feeText);
        statusText = findViewById(R.id.statusText);
        descriptionText = findViewById(R.id.descriptionText);

        registerBtn = findViewById(R.id.registerBtn);
        mapBtn = findViewById(R.id.mapBtn);

        String postId = getIntent().getStringExtra("postID");
        if (postId == null || postId.trim().isEmpty()) {
            Toast.makeText(this, "Missing tutorial ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadTutorial(postId);

        registerBtn.setOnClickListener(v -> {
            if (currentPost == null) return;

            if (currentPost.hasAvailableSeats()) {
                Intent intent = new Intent(ViewTutorialActivity.this, PaymentPaypalActivity.class);
                intent.putExtra("tutorial_post", currentPost);
                startActivity(intent);
            }
        });

        mapBtn.setOnClickListener(v -> {
            if (currentPost == null || currentPost.location == null || currentPost.location.trim().isEmpty()) {
                Toast.makeText(this, "No location available", Toast.LENGTH_SHORT).show();
                return;
            }

            Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(currentPost.location));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");

            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(currentPost.location))));
            }
        });
    }

    /**
     * Fetches a {@link TutorialPost} from Firebase by its ID and binds it to the UI.
     * Finishes the activity if the post cannot be loaded.
     *
     * @param postId the Firebase ID of the tutorial post to load
     */
    private void loadTutorial(String postId) {
        db.getTutorialPostById(postId, new FirebaseManager.TutorialPostCallback() {
            @Override
            public void onSuccess(TutorialPost post) {
                currentPost = post;
                bindPost(post);
            }

            @Override
            public void onFailure(String message) {
                Toast.makeText(ViewTutorialActivity.this, "Failed: " + message, Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    /**
     * Binds all fields of a {@link TutorialPost} to their corresponding UI views.
     * Shows or hides the register and map buttons based on seat availability and location.
     *
     * @param post the tutorial post whose data will be displayed
     */
    private void bindPost(TutorialPost post) {
        topicText.setText("Topic: " + safe(post.subject));
        tutorText.setText("Tutor: " + safe(post.tutorName));
        dateTimeText.setText("Date/Time: " + safe(post.date) + " " + safe(post.time));
        durationText.setText("Duration: " + safe(post.duration));
        locationText.setText("Location: " + safe(post.location));
        feeText.setText("Fee: " + safe(post.fee));
        statusText.setText("Status: " + post.getStatusText());
        descriptionText.setText("Description: " + safe(post.description));

        if (post.hasAvailableSeats()) {
            registerBtn.setVisibility(View.VISIBLE);
            registerBtn.setEnabled(true);
        } else {
            registerBtn.setVisibility(View.VISIBLE);
            registerBtn.setEnabled(false);
        }

        if (post.location == null || post.location.trim().isEmpty()) {
            mapBtn.setVisibility(View.GONE);
        } else {
            mapBtn.setVisibility(View.VISIBLE);
        }
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private String safe(int value) {
        return String.valueOf(value);
    }

    private String safe(double value) {
        return String.valueOf(value);
    }
}
