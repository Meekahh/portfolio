package com.example.csci3130_group21_project.views;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.database.TutorialSession;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    public GoogleMap mMap;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    // Default camera position — centres the map on Dalhousie's Studley campus
    public static final LatLng HALIFAX = new LatLng(44.6366, -63.5917);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Find the SupportMapFragment in our layout and ask it to call
        // onMapReady() when the map is fully initialised.
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    /**
     * Called by the Maps SDK once the GoogleMap object is ready to use.
     * Nothing map-related should happen before this fires.
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Start centred on Dal campus, zoom level 15 ≈ street level
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(HALIFAX, 15f));

        enableMyLocation();
        loadSessionMarkers();
    }

    /**
     * Shows the blue "my location" dot on the map.
     * On Android 6+, permissions are granted at runtime — we can't assume
     * they were granted just because they're in the manifest.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        } else {
            // Ask the user for permission — result arrives in onRequestPermissionsResult
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    /** Called by Android after the user responds to the permission dialog. */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
            }
        }
    }

    /**
     * Reads all sessions from Firebase once and places a marker for each.
     * Uses addListenerForSingleValueEvent (one-time read) rather than
     * addValueEventListener (live stream) — sessions don't need real-time updates here.
     */
    public void loadSessionMarkers() {
        FirebaseDatabase.getInstance()
                .getReference("sessions")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            // Firebase maps the JSON node to TutorialSession using field names
                            TutorialSession session = child.getValue(TutorialSession.class);
                            if (session != null) {
                                placeMarker(session);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(MapsActivity.this,
                                "Could not load tutorial sessions",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /**
     * Formats the marker title shown in bold when a student taps a pin.
     * Kept public and separate so it can be unit tested without a real GoogleMap.
     */
    public String buildMarkerTitle(TutorialSession session) {
        return session.subject + " — " + session.tutorName;
    }

    /**
     * Formats the subtitle shown below the title in the info window.
     * Kept public and separate so it can be unit tested without a real GoogleMap.
     */
    public String buildMarkerSnippet(TutorialSession session) {
        return session.locationName + " | " + session.date + " @ " + session.time;
    }

    /** Places a single marker on the map for the given session. */
    public void placeMarker(TutorialSession session) {
        LatLng position = new LatLng(session.latitude, session.longitude);
        mMap.addMarker(new MarkerOptions()
                .position(position)
                .title(buildMarkerTitle(session))
                .snippet(buildMarkerSnippet(session)));
    }
}
