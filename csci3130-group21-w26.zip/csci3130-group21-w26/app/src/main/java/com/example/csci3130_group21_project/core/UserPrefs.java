package com.example.csci3130_group21_project.core;

import android.content.Context;
import android.content.SharedPreferences;
//for user preferences
public class UserPrefs {

    private static final String PREFS = "user_prefs";
    private static final String EMAIL = "email";
    private static final String PASS_HASH = "pass_hash";
    private static final String SEC_Q = "sec_q";
    private static final String SEC_A_HASH = "sec_a_hash";

    // create default user if not created
    public static void seed(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!sp.contains(EMAIL)) {
            sp.edit()
                    .putString(EMAIL, "ab123456@dal.ca")
                    .putString(PASS_HASH, HashUtil.sha256("qweewqeqwrwq!"))
                    .putString(SEC_Q, "What is your favourite color?")
                    .putString(SEC_A_HASH, HashUtil.sha256(HashUtil.normalize("blue")))
                    .apply();
        }
    }

    public static String getEmail(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(EMAIL, "");
    }
    //return store security question
    public static String getQuestion(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(SEC_Q, "");
    }
    //check if security answer are correct
    public static boolean checkAnswer(Context ctx, String answer) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String stored = sp.getString(SEC_A_HASH, "");
        String given = HashUtil.sha256(HashUtil.normalize(answer));
        return !stored.isEmpty() && stored.equals(given);
    }
    //check login credentials
    public static boolean loginOk(Context ctx, String email, String password) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String e = sp.getString(EMAIL, "");
        String ph = sp.getString(PASS_HASH, "");
        String given = HashUtil.sha256(password);

        return e.equals(email == null ? "" : email.trim()) && ph.equals(given);
    }
    // change password to new hashed password
    public static void setNewPassword(Context ctx, String newPassword) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(PASS_HASH, HashUtil.sha256(newPassword)).apply();
    }
}

