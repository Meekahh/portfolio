package com.example.csci3130_group21_project.core;
import com.example.csci3130_group21_project.core.entries.CardEntry;
import com.paypal.android.sdk.payments.*;
import java.math.BigDecimal;
public class Paypal {

    private PayPalConfiguration payPalConfig;
    public Paypal(){
        configPayPal();
    }

    private void configPayPal(){
        //Entering your own ClientID from Paypal
        String CLIENT_ID = "AdIFj7OuKrhhiXd630McdbZ2eaCmfIlZoOjRkFb97dS8pNpxnSZwU6S6vYHfMZOiWPV6_lcl093GWCoR";
        payPalConfig = new PayPalConfiguration()
                .environment(PayPalConfiguration.ENVIRONMENT_SANDBOX)
                .clientId(CLIENT_ID);
    }
    public PayPalConfiguration getConfig(){
        return payPalConfig;
    }
    public PayPalPayment buildPayment(double amount, String Currency, String Detail) {
        return new PayPalPayment(
                new BigDecimal(amount),
                Currency,
                Detail,
                PayPalPayment.PAYMENT_INTENT_SALE
        );
    }
}
