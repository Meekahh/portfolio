package com.example.csci3130_group21_project.views;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.entries.CardEntry;
import com.example.csci3130_group21_project.core.Registration;
import com.example.csci3130_group21_project.core.TutorialPost;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.example.csci3130_group21_project.core.Paypal;
import com.paypal.android.sdk.payments.PayPalPayment;
import com.paypal.android.sdk.payments.PaymentActivity;
import com.paypal.android.sdk.payments.PayPalService;
import androidx.activity.result.contract.ActivityResultContracts;

/**
 * Handles student payment processing and session registration
 */
public class PaymentPaypalActivity extends AppCompatActivity {
    // UI
    private TextView tutorial, amount, error;
    private EditText name, cardNum, expiry, cvv;
    private Button pay;

    // Data
    private TutorialPost post;
    private final FirebaseManager db = FirebaseManager.getInstance();

    private final ActivityResultLauncher<Intent> paypalLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    save();
                } else if (result.getResultCode() == RESULT_CANCELED) {
                    error.setText("Payment cancelled");
                    error.setVisibility(View.VISIBLE);
                } else if (result.getResultCode() == PaymentActivity.RESULT_EXTRAS_INVALID) {
                    error.setText("Payment invalid");
                    error.setVisibility(View.VISIBLE);
                }
            }
    );

    @Override
    // Init
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_payment);

        tutorial = findViewById(R.id.paymentTutorialTitle);
        amount = findViewById(R.id.paymentAmount);
        error = findViewById(R.id.paymentErrorText);
        name = findViewById(R.id.cardHolderNameBox);
        cardNum = findViewById(R.id.cardNumberBox);
        expiry = findViewById(R.id.expiryDateBox);
        cvv = findViewById(R.id.cvvBox);
        pay = findViewById(R.id.submitPaymentBtn);

        post = (TutorialPost) getIntent().getSerializableExtra("tutorial_post");
        if (post != null) {
            tutorial.setText(post.subject);
            amount.setText("$" + post.fee);
        } else {
            //Fake data for testing
            post = new TutorialPost();
            post.subject = "Test Tutorial";
            post.fee = 25.0;
            post.postID = "test_post_123";
            tutorial.setText(post.subject);
            amount.setText("$" + post.fee);
        }

        pay.setOnClickListener(v -> process());

    }


    // Processing
    private void process() {
        String namePro = name.getText().toString().trim();
        String cardPro = cardNum.getText().toString().trim();

        if (namePro.isEmpty() || cardPro.length() != 16) {
            error.setText("Invalid name or card number");
            error.setVisibility(View.VISIBLE);
            return;
        }
        String[] date = expiry.getText().toString().split("/");
        if (date.length != 2) {
            error.setText("Invalid expiry date, use MM/YY");
            error.setVisibility(View.VISIBLE);
            return;
        }

        //Save card

        int month = Integer.parseInt(date[0]);
        int year = Integer.parseInt(date[1]);
        String cvvPro = cvv.getText().toString();
        CardEntry card = new CardEntry(cardPro, month, year, cvvPro, namePro);

        //Charge
        Paypal paypal = new Paypal();
        PayPalPayment payment = paypal.buildPayment(post.fee, "CAD", "Tuition fee");

        Intent intent = new Intent(this, PaymentActivity.class);
        intent.putExtra(PayPalService.EXTRA_PAYPAL_CONFIGURATION, paypal.getConfig());
        intent.putExtra(PaymentActivity.EXTRA_PAYMENT, payment);
        paypalLauncher.launch(intent);
    }

    // Database info
    private void save() {
        if (post == null || db.getCurrentUser() == null) return;

        String user = db.getCurrentUser().getEmail();
        Registration reg = new Registration(user, "CONFIRMED", true);

        db.getDatabaseReference("tutorialPosts")
                .child(post.postID)
                .child("registrations")
                .push()
                .setValue(reg)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Paid & Registered", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }
}
