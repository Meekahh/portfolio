package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.core.Tutorial;
import com.example.csci3130_group21_project.core.TutorialRegistrationManager;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class StudentDashboardActivity extends DashboardActivity implements TutorialSearchAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private TutorialSearchAdapter tutorialSearchAdapter;
    private SearchTutorial searchTutorial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);
        super.updateCommonUI();
        super.setupLogout(R.id.logoutButton);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        tutorialSearchAdapter = new TutorialSearchAdapter(new ArrayList<>(), this);
        recyclerView.setAdapter(tutorialSearchAdapter);

        if (searchTutorial == null) {
            searchTutorial = new SearchTutorial();
        }
        loadTutorials();
    }

    public void setSearchTutorial(SearchTutorial searchTutorial) {
        this.searchTutorial = searchTutorial;
    }

    private void loadTutorials() {
        searchTutorial.getAllTutorials(new SearchTutorial.FirebaseCallback() {
            @Override
            public void onCallback(List<Tutorial> list) {
                tutorialSearchAdapter.updateData(list);
            }

            @Override
            public void onError(String message) {
                Toast.makeText(StudentDashboardActivity.this,
                        "Check your internet and try again.", Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * Called when a tutorial is clicked in the list.
     */
    @Override
    public void onItemClick(Tutorial tutorial) {
        // Get the current user's ID from Firebase
        String currentUserId = FirebaseAuth.getInstance().getCurrentUser() != null 
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() 
                : "test_user_id";

        TutorialRegistrationManager registrationManager = new TutorialRegistrationManager(tutorial);
        String status = registrationManager.registerStudent(currentUserId);

        handleRegistrationFeedback(status);
    }

    private void handleRegistrationFeedback(String status) {
        switch (status) {
            case "SUCCESS":
                Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                break;
            case "ALREADY_REGISTERED":
                Toast.makeText(this, "You are already registered for this session.", Toast.LENGTH_SHORT).show();
                break;
            case "TUTORIAL_FULL":
                Toast.makeText(this, "This tutorial is full.", Toast.LENGTH_SHORT).show();
                break;
            default:
                Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
