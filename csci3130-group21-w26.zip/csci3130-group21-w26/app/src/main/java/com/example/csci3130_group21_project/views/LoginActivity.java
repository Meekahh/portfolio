package com.example.csci3130_group21_project.views;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.LoginValidator;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private LoginValidator validator;
    private FirebaseManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login);

        if (validator == null) {
            validator = new LoginValidator();
        }
        if (firebaseManager == null) {
            firebaseManager = FirebaseManager.getInstance();
        }

        setupClickListeners();
    }

    public void setLoginValidator(LoginValidator validator) {
        this.validator = validator;
    }

    public void setFirebaseManager(FirebaseManager firebaseManager) {
        this.firebaseManager = firebaseManager;
    }

    private void setupClickListeners() {
        findViewById(R.id.loginButton).setOnClickListener(this);
        findViewById(R.id.forgotPasswordButton).setOnClickListener(this);
        findViewById(R.id.signUpLink).setOnClickListener(this);
    }

    protected String getEmail() {
        EditText email = findViewById(R.id.emailAddress);
        return email.getText() != null ? email.getText().toString().trim() : "";
    }

    protected String getPassword() {
        EditText password = findViewById(R.id.password);
        return password.getText() != null ? password.getText().toString() : "";
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.loginButton) {
            handleLogin();
        } else if (id == R.id.forgotPasswordButton) {
            navigateTo(PasswordResetActivity.class);
        } else if (id == R.id.signUpLink) {
            navigateTo(SignupFeature.class);
        }
    }

    private void handleLogin() {
        String email = getEmail();
        String password = getPassword();
        TextView message = findViewById(R.id.messageLabel);

        if (!validator.validateEmail(email) || !validator.validatePassword(password)) {
            message.setText("INVALID_EMAIL_OR_PASSWORD");
            return;
        }

        firebaseManager.signIn(this, email, password, task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = firebaseManager.getCurrentUser();
                if (user != null) {
                    message.setText("LOGIN_SUCCESSFUL");
                    fetchUserRoleAndNavigate(user.getUid());
                } else {
                    message.setText("LOGIN_FAILED_USER_NULL");
                }
            } else {
                message.setText("INVALID_CREDENTIALS");
            }
        });
    }

    /**
     * Reads the "role" field from Realtime Database (not Firestore).
     * SignupFeature saves data via: getDatabaseReference().child(uid).setValue(userProfile)
     * So the structure is:  /{uid}/role  in Realtime DB.
     */
    private void fetchUserRoleAndNavigate(String uid) {
        firebaseManager.getDatabaseReference()
                .child(uid)
                .child("role")
                .get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        String role = snapshot.getValue(String.class);
                        routeByRole(role);
                    } else {
                        Toast.makeText(this, "User profile not found.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to fetch role: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    /**
     * "student" → StudentDashboardActivity
     * "tutor"   → TutorDashboardActivity
     *
     * Values must match exactly what SignupFeature saves (lowercase).
     */
    private void routeByRole(String role) {
        if (role == null) {
            Toast.makeText(this, "No role assigned to this account.", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (role.toLowerCase()) {
            case "student":
                navigateTo(StudentDashboardActivity.class);
                break;
            case "tutor":
                navigateTo(TutorDashboardActivity.class);
                break;
            default:
                Toast.makeText(this, "Unknown account type: " + role, Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void navigateTo(Class<?> destination) {
        Intent intent = new Intent(this, destination);
        startActivity(intent);
        finish();
    }
}