package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.database.FirebaseManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import android.content.Intent;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textview = findViewById(R.id.textview);

        Button btnGoSignup = findViewById(R.id.btnGoSignup);
        btnGoSignup.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SignupFeature.class);
            startActivity(intent);
        });

        Button btnGoLogin = findViewById(R.id.btnGoLogin);
        btnGoLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });
        com.example.csci3130_group21_project.database.FirebaseManager firebaseManager = FirebaseManager.getInstance();

        // Write exampl
        firebaseManager.write("Hello World");

        // Read example
        firebaseManager.read(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                textview.setText(value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                textview.setText("Error reading data");
            }
        });
    }
}
