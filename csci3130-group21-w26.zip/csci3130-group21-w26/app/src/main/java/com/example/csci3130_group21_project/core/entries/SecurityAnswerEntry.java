package com.example.csci3130_group21_project.core.entries;
import com.example.csci3130_group21_project.core.Entry;

public class SecurityAnswerEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.trim().isEmpty()) {
            errorMsg = "Security answer is required.";
            isValid = false;
        } else {
            errorMsg = null;
            isValid = true;
        }
    }
}