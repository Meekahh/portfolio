package com.example.csci3130_group21_project.core.entries;
import com.example.csci3130_group21_project.core.Entry;

public class SecurityQuestionEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.trim().isEmpty()
                || content.equalsIgnoreCase("Select a question")) {
            errorMsg = "Please select a security question.";
            isValid = false;
        } else {
            errorMsg = null;
            isValid = true;
        }
    }
}