package com.example.csci3130_group21_project.core.entries;

import android.widget.EditText;

public class CardEntry {
    private final String cardNumber;
    private final int expmonth;

    private final int expyear;
    private final String cvv;
    private final String nameOnCard;

    public CardEntry(String cardNumber, int month, int year, String cvv, String nameOnCard) {
        this.cardNumber = cardNumber;
        this.expmonth = month;
        this.expyear = year;
        this.cvv = cvv;
        this.nameOnCard = nameOnCard;
    }

    // Getters
    public String getCardNumber() { return cardNumber; }
    public String getExpiryDate() { return expmonth+"/"+expyear; }
    public String getCvv() { return cvv; }
    public String getNameOnCard() { return nameOnCard; }
}