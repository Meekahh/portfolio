package com.example.csci3130_group21_project.core;

import com.example.csci3130_group21_project.core.entries.ContactNumEntry;
import com.example.csci3130_group21_project.core.entries.EmailEntry;
import com.example.csci3130_group21_project.core.entries.NameEntry;
import com.example.csci3130_group21_project.core.entries.PasswordEntry;
import com.example.csci3130_group21_project.core.entries.RoleEntry;
import com.example.csci3130_group21_project.core.entries.SecurityQuestionEntry;
import com.example.csci3130_group21_project.core.entries.SecurityAnswerEntry;


public class RegistrationScreen {

    public EmailEntry email = new EmailEntry();
    public PasswordEntry password = new PasswordEntry();
    public NameEntry name = new NameEntry();
    public ContactNumEntry contactNum = new ContactNumEntry();
    public RoleEntry role = new RoleEntry();
    public static final SecurityQuestionEntry securityQuestion = new SecurityQuestionEntry();
    public static final SecurityAnswerEntry securityAnswer = new SecurityAnswerEntry();

    public RegistrationScreen(String emailContent,
                              String passwordContent,
                              String nameContent,
                              String contactNumContent,
                              String roleContent, String securityQuestionContent, String securityAnswerContent) {

        email.setContent(emailContent);
        password.setContent(passwordContent);
        name.setContent(nameContent);
        contactNum.setContent(contactNumContent);
        role.setContent(roleContent);
        securityAnswer.setContent(securityAnswerContent);
        securityQuestion.setContent(securityQuestionContent);
    }

    public void validateAll() {
        email.validate();
        password.validate();
        name.validate();
        contactNum.validate();
        role.validate();
        securityQuestion.validate();
        securityAnswer.validate();

        if ((email.errorMsg != null && !email.errorMsg.isEmpty())
                || (password.errorMsg != null && !password.errorMsg.isEmpty())
                || (name.errorMsg != null && !name.errorMsg.isEmpty())
                || (contactNum.errorMsg != null && !contactNum.errorMsg.isEmpty())
                || (role.errorMsg != null && !role.errorMsg.isEmpty())
                || (securityQuestion.errorMsg != null && !securityQuestion.errorMsg.isEmpty())
                || (securityAnswer.errorMsg != null && !securityAnswer.errorMsg.isEmpty())) {

            // ERROR MESSAGE POP UP ON SCREEN
        }

    }
}