package com.example.csci3130_group21_project.core;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
// hash string using sha-256
public class HashUtil {

    public static String sha256(String s) {
        try {
            //get the sha algo
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // change the input string into bytes, then change it to readable hex string
            byte[] out = md.digest((s == null ? "" : s).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : out) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    // sanitize user input
    public static String normalize(String s) {
        return s == null ? "" : s.trim().toLowerCase();
    }
}

