package com.example.csci3130_group21_project.views;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.SearchTutorial;
import com.example.csci3130_group21_project.core.Tutorial;

import java.util.ArrayList;
import java.util.List;

public class TutorDashboardActivity extends DashboardActivity {

    private RecyclerView sessionsRecyclerView;
    private TutorialSearchAdapter sessionsAdapter;
    private SearchTutorial searchTutorial;

    public void setSearchTutorial(SearchTutorial searchTutorial) {
        this.searchTutorial = searchTutorial;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_dashboard);
        super.updateCommonUI();
        super.setupLogout(R.id.logoutButton);

        Button postBtn = findViewById(R.id.postTutorialBtn);
        postBtn.setOnClickListener(v -> startActivity(new Intent(TutorDashboardActivity.this, PostTutorialActivity.class)));

        sessionsRecyclerView = findViewById(R.id.sessionsRecyclerView);
        sessionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        sessionsAdapter = new TutorialSearchAdapter(new ArrayList<>(), tutorial -> {
            Intent intent = new Intent(TutorDashboardActivity.this, ViewRegistrationsActivity.class);
            intent.putExtra(ViewRegistrationsActivity.EXTRA_TUTORIAL, tutorial);
            startActivity(intent);
        });
        sessionsRecyclerView.setAdapter(sessionsAdapter);

        loadSessions();
    }

    private void loadSessions() {
        if (searchTutorial == null) {
            searchTutorial = new SearchTutorial();
        }
        searchTutorial.getAllTutorials(new SearchTutorial.FirebaseCallback() {
            @Override
            public void onCallback(List<Tutorial> list) {
                sessionsAdapter.updateData(list);
            }

            @Override
            public void onError(String message) {
                Toast.makeText(TutorDashboardActivity.this,
                        "Failed to load sessions.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
