package com.example.csci3130_group21_project.core;

import java.io.Serializable;

/**
 * Handles tutorial registration and payment status
 */
public class Registration implements Serializable {
        // Fields
    private String name;
    private String status;
    private boolean paid;


        // Init
    public Registration() {}

    public Registration(String name, String s) {
        this.name = name;
        this.status = s;
        this.paid = false;
    }

    public Registration(String name, String s, boolean p) {
        this.name = name;
        this.status = s;
        this.paid = p;
    }


        // Get/Set
    public String getStudentName() { return name; }
    public void setStudentName(String n) { name = n; }

    public String getStatus() { return status; }
    public void setStatus(String s) { status = s; }

    public boolean getPay() { return paid; }
    public void setPay(boolean p) { paid = p; }


    /**
     * Marks registration as paid and confirmed
     */
    public void pay() {
        paid = true;
        status = "CONFIRMED";
    }
}
