package com.example.csci3130_group21_project.core.entries;

import com.example.csci3130_group21_project.core.Entry;

public class EmailEntry extends Entry {

    @Override
    public void validate() {
        if (content == null || content.isEmpty()) {
            isValid = false;
            errorMsg = "Email is required";
            return;
        }

        if (content.contains("@") && content.contains(".")) {
            super.validate();
        } else {
            isValid = false;
            errorMsg = "Email address must contain an '@' and a '.'";
        }
    }
}
