package com.example.csci3130_group21_project.database;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserData {
    private final DatabaseReference databaseReference;
    private final FirebaseUser currentUser;

    public UserData(FirebaseUser currentUser) {
        this.databaseReference = FirebaseDatabase.getInstance().getReference();
        this.currentUser = currentUser;
    }

    public String getUserStatus() {
        if (currentUser != null && currentUser.getEmail() != null && currentUser.getEmail().contains("tutor")) {
            return "Tutor";
        }
        return "Student";
    }

    public String getWelcomeMessage() {
        if (currentUser != null && currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
            return "Welcome, " + currentUser.getDisplayName() + " to Dal Tutor App";
        }
        return "Welcome to Dal Tutor App.";
    }


}
