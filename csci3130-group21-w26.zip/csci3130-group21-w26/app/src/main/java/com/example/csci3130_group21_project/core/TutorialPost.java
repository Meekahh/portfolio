package com.example.csci3130_group21_project.core;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TutorialPost implements Serializable {

    public String postID;

    public String title;
    public String description;
    public String subject;
    public String postedByUserID;
    public String tutorName;

    public String location;

    public String date;
    public String time;

    public int maxStudents;
    public int duration;
    public double fee;
    public int currentStudents;
    public boolean isClosed;
    
    public List<Registration> registrations = new ArrayList<>();

    public TutorialPost() {

    }

    public TutorialPost(String title, String description, String subject,
                        String postedByUserID, String location, String date,
                        String time, int maxStudents, int duration, double fee) {

        this.title = title;
        this.description = description;
        this.subject = subject;
        this.postedByUserID = postedByUserID;
        this.location = location;
        this.date = date;
        this.time = time;
        this.maxStudents = maxStudents;
        this.duration = duration;
        this.fee = fee;
        this.currentStudents = 0;
        this.isClosed = false;
        this.tutorName = "";
    }

    public TutorialPost(String title, String description, String subject,
                        String postedByUserID, String tutorName, String location,
                        String date, String time, int maxStudents, int duration, double fee) {

        this.title = title;
        this.description = description;
        this.subject = subject;
        this.postedByUserID = postedByUserID;
        this.tutorName = tutorName;
        this.location = location;
        this.date = date;
        this.time = time;
        this.maxStudents = maxStudents;
        this.duration = duration;
        this.fee = fee;
        this.currentStudents = 0;
        this.isClosed = false;
    }

    public boolean hasAvailableSeats() {
        return !isClosed && currentStudents < maxStudents;
    }

    public String getStatusText() {
        if (isClosed) {
            return "Closed";
        }
        if (currentStudents >= maxStudents) {
            return "Full";
        }
        return "Open";
    }
}
