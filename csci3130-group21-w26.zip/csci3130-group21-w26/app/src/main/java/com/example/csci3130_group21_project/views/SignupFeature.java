package com.example.csci3130_group21_project.views;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.csci3130_group21_project.R;
import com.example.csci3130_group21_project.core.HashUtil;
import com.example.csci3130_group21_project.core.RegistrationScreen;
import com.example.csci3130_group21_project.core.entries.*;
import com.example.csci3130_group21_project.database.FirebaseManager;

import java.util.HashMap;
import java.util.Map;

public class SignupFeature extends AppCompatActivity {

    private EditText inputEmail, inputPassword, inputName, inputContact;
    private EditText inputSecurityQuestion, inputSecurityAnswer;
    private Spinner spinnerRole;
    private Button btnRegister;

    private FirebaseManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signupfeature);

        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        inputName = findViewById(R.id.inputName);
        inputContact = findViewById(R.id.inputContact);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnRegister = findViewById(R.id.btnRegister);
        inputSecurityQuestion = findViewById(R.id.inputSecurityQuestion);
        inputSecurityAnswer = findViewById(R.id.inputSecurityAnswer);

        firebaseManager = FirebaseManager.getInstance();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"student", "tutor"}); // was "EMPLOYEE", "EMPLOYER"
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        btnRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString();
        String name = inputName.getText().toString().trim();
        String contact = inputContact.getText().toString().trim();
        String role = spinnerRole.getSelectedItem().toString();
        String securityQuestion = inputSecurityQuestion.getText().toString().trim();
        String securityAnswer = inputSecurityAnswer.getText().toString().trim();

        RegistrationScreen signup = new RegistrationScreen(
                email, password, name, contact, role, securityQuestion, securityAnswer
        );

        signup.validateAll();

        StringBuilder errors = new StringBuilder();
        if (!signup.email.isValid()) errors.append(signup.email.getErrorMsg()).append("\n");
        if (!signup.password.isValid()) errors.append(signup.password.getErrorMsg()).append("\n");
        if (!signup.name.isValid()) errors.append(signup.name.getErrorMsg()).append("\n");
        if (!signup.contactNum.isValid()) errors.append(signup.contactNum.getErrorMsg()).append("\n");
        if (!signup.role.isValid()) errors.append(signup.role.getErrorMsg()).append("\n");
        if (!signup.securityQuestion.isValid()) errors.append(signup.securityQuestion.getErrorMsg()).append("\n");
        if (!signup.securityAnswer.isValid()) errors.append(signup.securityAnswer.getErrorMsg()).append("\n");

        if (errors.length() > 0) {
            Toast.makeText(this, errors.toString().trim(), Toast.LENGTH_LONG).show();
            return;
        }
        firebaseManager.getAuth().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (!task.isSuccessful()) {
                        Toast.makeText(this, "Registration failed: " +
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        return;
                    }

                    String uid = firebaseManager.getAuth().getCurrentUser().getUid();
                    String passwordHash = HashUtil.sha256(password);
                    String answerHash = HashUtil.sha256(securityAnswer.toLowerCase().trim());

                    Map<String, Object> userProfile = new HashMap<>();
                    userProfile.put("email", email);
                    userProfile.put("name", name);
                    userProfile.put("contactNumber", contact);
                    userProfile.put("role", role);
                    userProfile.put("passwordHash", passwordHash);
                    userProfile.put("securityQuestion", securityQuestion);
                    userProfile.put("securityAnswerHash", answerHash);

                    firebaseManager.getDatabaseReference()
                            .child(uid)
                            .setValue(userProfile)
                            .addOnSuccessListener(unused -> {
                                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
//                                finish();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(this, "Failed to save profile: " +
                                        e.getMessage(), Toast.LENGTH_LONG).show();
                            });
                });
    }
}