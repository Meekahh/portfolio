package com.example.csci3130_group21_project.core;

import com.example.csci3130_group21_project.database.UserData;
import com.google.firebase.auth.FirebaseUser;

public class Dashboard {

    private UserData userData;
    FirebaseUser currentUser;

    public void setUserData(UserData userData) {
        this.userData = userData;
    }

    public void setCurrentUser(FirebaseUser currentUser) {
        this.currentUser = currentUser;
    }

    public String getUserStatus() {
        if (userData == null) return "";
        return userData.getUserStatus();
    }

    public String getWelcomeMessage() {
        if (userData == null) return "";
        return userData.getWelcomeMessage();
    }
}