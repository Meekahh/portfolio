package com.example.csci3130_group21_project.database;

/**
 * Mirrors the /sessions/{sessionId} node in Firebase Realtime Database.
 *
 * Firebase deserializes JSON into this object by matching field names to JSON keys.
 * Rules:
 *   1. Fields must be public (or have getters/setters)
 *   2. Must have a no-arg constructor — Firebase requires this to instantiate the object
 */
public class TutorialSession {
    public String sessionId;
    public String tutorName;
    public String subject;
    public String locationName;
    public double latitude;
    public double longitude;
    public String date;
    public String time;

    // Required by Firebase — without this, getValue(TutorialSession.class) will crash
    public TutorialSession() {}
}
