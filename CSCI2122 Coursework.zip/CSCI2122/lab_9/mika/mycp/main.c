#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

        // Check if the function is getting called w the right amt of arguments
    if (argc != 3) {
        return 1;
    }

        // Variable declaration zone (and also the file opening zone)
    FILE *inputFile = fopen(argv[1], "r");
    FILE *outputFile = fopen(argv[2], "w");
    char *buffer = malloc(sizeof(char));
    int bytesRead = fread(buffer, 1, sizeof(char), inputFile); // Put a byte of the input text into buffer

        // Processing
    while (bytesRead > 0) {
        fwrite(buffer, 1, bytesRead, outputFile); // Put the contents of the buffer into the output
        bytesRead = fread(buffer, 1, sizeof(char), inputFile); // Next byte
    }

        // Close the files back down
    fclose(inputFile);
    fclose(outputFile);

    return 0;
}