file(REMOVE_RECURSE
  "CMakeFiles/mycp.dir/main.c.o"
  "CMakeFiles/mycp.dir/main.c.o.d"
  "mycp"
  "mycp.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mycp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
