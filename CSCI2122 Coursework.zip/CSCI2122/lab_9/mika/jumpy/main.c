#include <stdio.h>
#include <strings.h>

int main(int argc, char **argv) {
        // Check to make sure the function is being called properly
    if (argc != 2) {
        return 1;
    }

        // Variable declaration zone + file opening
    FILE *inputFile = fopen(argv[1], "r");
    int output[10000];
    int offset = 0;
    int index = 0;
    int ranOnceFlag = 0; // Lets me use offset != 0 as my while condition but still initialize offset as 0

        // Processing
    while (offset != 0 || ranOnceFlag == 0) {
            // Store the offset in the output
        output[index] = offset;
        index++;

            // File processing part of it
        fseek(inputFile, offset, 0);
        fread(&offset, sizeof(offset), 1, inputFile);

        ranOnceFlag = 1; // Flag mentioned earlier
    }

        // Print the output
    for (int i = 0; i < index; i++) {
        printf("%d\n", output[i]);
    }

    return 0;
}
