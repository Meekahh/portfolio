file(REMOVE_RECURSE
  "CMakeFiles/jumpy.dir/main.c.o"
  "CMakeFiles/jumpy.dir/main.c.o.d"
  "jumpy"
  "jumpy.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/jumpy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
