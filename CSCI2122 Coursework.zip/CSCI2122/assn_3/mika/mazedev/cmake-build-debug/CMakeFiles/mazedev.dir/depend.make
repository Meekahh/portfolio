# Empty dependencies file for mazedev.
# This may be replaced when dependencies are built.
