file(REMOVE_RECURSE
  "CMakeFiles/mazedev.dir/main.c.o"
  "CMakeFiles/mazedev.dir/main.c.o.d"
  "mazedev"
  "mazedev.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mazedev.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
