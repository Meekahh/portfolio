#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "linkedlist/linkedlist.c"

int inRoomList(linked_list_t list, char *room) {
    struct ll_iterator *iter = ll_iterator_new(list);
        // Looks to make sure the room passed into the function is in the room list
    while (ll_has_next(iter)) {
        char *currentRoom = ll_next(iter);
        if (strcmp(currentRoom, room) == 0) {
            return 1;
        }
    }
    return 0;
}

int findConnection(linked_list_t list, char *conn) {
    struct ll_iterator *iter = ll_iterator_new(list);
        // Just checks through the connections list to see if the proposed connection exists
    while (ll_has_next(iter)) {
        char *currentConn = ll_next(iter);
        if (strcmp(currentConn, conn) == 0) {
            return 1;
        }
    }
    return 0;
}

void listInputReader(linked_list_t list, int isConnectionsList) {
    char input[100];
    while (1) {
        if (isConnectionsList) {
                // This is to make sure that the connections list entries all stay on the same line
            int i = 0;
            char c;
            while (((c = getchar()) != '\n') && (c != EOF)) {
                input[i++] = c;
            }
            input[i] = '\0';

        } else {
            scanf("%s", input);
        }

        char *string = strdup(input);
        if (strcmp(string, "END") == 0) {
            break;
        }
        ll_add_back(list, string);
    }
}

void checkRoomsInConnList(linked_list_t roomList, linked_list_t connList) {
    struct ll_iterator *iter = ll_iterator_new(connList);
    while (ll_has_next(iter)) {
            // Variable Declaration Zone
        char *currentConnection = ll_next(iter);
        char firstRoom[100];
        char secondRoom[100];
        int i = 0;
        int j = 0;

            // Seperating the 2 parts of the connections and then checking each against the room list
        while (currentConnection[i] != ' ' && currentConnection[i] != '\0') {
            firstRoom[j++] = currentConnection[i++];
        }
        firstRoom[j] = '\0';

            // Skip the space in the middle of the two room names
        i++;
        j = 0;
        while (currentConnection[i] != '\0') {
            secondRoom[j++] = currentConnection[i++];
        }
        secondRoom[j] = '\0';

            // Check the rooms
        if (firstRoom[0] != '\0' && !inRoomList(roomList, firstRoom)) {
            printf("Oops: Cannot find room %s.\n", firstRoom);
        }
        if (secondRoom[0] != '\0' && !inRoomList(roomList, secondRoom)) {
            printf("Oops: Cannot find room %s.\n", secondRoom);
        }
    }
}

int main() {
        // Variable Declaration Zone (reading in the list elements edition)
    linked_list_t roomList = ll_new();
    linked_list_t connList = ll_new();
    linked_list_t moveList = ll_new();

    listInputReader(roomList, 0);
    listInputReader(connList, 1);
    listInputReader(moveList, 0);

        // Make sure the connections list rooms actually exist before processing everything
    checkRoomsInConnList(roomList, connList);

        // Processing for specifically the first move
    struct ll_iterator *iter = ll_iterator_new(moveList);
    char *currentRoom = NULL;
    if (ll_has_next(iter)) {
        currentRoom = (char *)ll_next(iter);

        if (!inRoomList(roomList, currentRoom)) {
            printf("Oops: Cannot find room %s.\n", currentRoom);
            return 1;

        }
        printf("Entering room %s.\n", currentRoom);

    }

        /* This flag is for one of the tests, since if we end on
         * an error we shouldn't have the 'ended on' message */
    int noEndedFlag = 0;

        // Processing for the rest of the moves
    while (ll_has_next(iter)) {
        char *nextRoom = ll_next(iter);

        if (!inRoomList(roomList, nextRoom)) {
            printf("Oops: Cannot find room %s.\n", nextRoom);
            noEndedFlag = 1;
            break;
        }

        char conn[200];
        sprintf(conn, "%s %s", currentRoom, nextRoom);
        if (!findConnection(connList, conn)) {
            printf("Oops: Room %s does not connect to room %s.\n", currentRoom, nextRoom);
            noEndedFlag = 1;
            break;
        }

        printf("Entering room %s.\n", nextRoom);
        currentRoom = nextRoom;
        noEndedFlag = 0;
    }

    if (!noEndedFlag) {
        printf("Ended in room %s.\n", currentRoom);
    }

    return 0;
}