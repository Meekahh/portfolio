#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "linkedlist.h"

typedef struct ll_node {
    struct ll_node *prev;
    struct ll_node *next;
    void *item;
} ll_node_t;

typedef struct linked_list {
    ll_node_t *head;
    ll_node_t *tail;
} linked_list;

struct ll_iterator {
    ll_node_t *current;
    ll_node_t *prevAccessed; // A separate variable for dealing with the last thing that was next()'ed
};

extern linked_list_t ll_new() {
    linked_list_t *list = calloc(1, sizeof(linked_list_t));
    return list;
}

extern void ll_destroy(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list != NULL);

    while (list->head != NULL) {
        ll_node_t *tmp = list->head;
        list->head = list->head->next;
        free(tmp);
    }

    free(list);
}

static ll_node_t *new_node(void *item, ll_node_t *prev, ll_node_t *next) {
    ll_node_t *n = calloc(1, sizeof(ll_node_t));
    if (n != NULL) {
        n->item = item;
        n->prev = prev;
        n->next = next;
    }
    return n;
}

extern int ll_add_front(linked_list_t ll, void *item) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    ll_node_t *n = new_node(item, NULL, list->head);
    if (n != NULL) {
        if (list->tail == NULL) {
            list->tail = n;
        } else {
            list->head->prev = n;
        }
        list->head = n;
    }
    return n != NULL;
}

extern int ll_add_back(linked_list_t ll, void *item) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    ll_node_t *n = new_node(item, list->tail, NULL);
    if (n != NULL) {
        if (list->head == NULL) {
            list->head = n;
        } else {
            list->tail->next = n;
        }
        list->tail = n;
    }
    return n != NULL;
}

extern void *ll_remove_front(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        ll_node_t *n = list->head;
        list->head = list->head->next;
        if (list->head == NULL) {
            list->tail = NULL;
        } else {
            list->head->prev = NULL;
        }

        item = n->item;
        free(n);
    }
    return item;
}

extern void *ll_remove_back(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    void *item = NULL;
    if (list->tail != NULL) {
        ll_node_t *n = list->tail;
        list->tail = list->tail->prev;
        if (list->tail == NULL) {
            list->head = NULL;
        } else {
            list->tail->next = NULL;
        }

        item = n->item;
        free(n);
    }
    return item;
}

extern void *ll_get_front(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        item = list->head->item;
    }
    return item;
}

extern void *ll_get_back(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        item = list->tail->item;
    }
    return item;
}

extern int ll_size(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);
    int count = 0;
    for (ll_node_t *ptr = list->head; ptr != NULL; ptr = ptr->next) {
        count++;
    }
    return count;
}

extern int ll_is_empty(linked_list_t ll) {
    linked_list *list = (linked_list *)ll;
    assert(list);
    return list->head == NULL;
}

/************************************************************************
 * Your code below
 ************************************************************************/

int canRemoveFlag = 1;

extern ll_iterator_t ll_iterator_new(linked_list_t list) {
    struct ll_iterator *iter = malloc(sizeof(struct ll_iterator));
    iter->current = ((linked_list *)list)->head;
    iter->prevAccessed = NULL;
    return iter;
}

extern void ll_iterator_destroy(ll_iterator_t iter) {
    free(iter);
}

extern void *ll_next(ll_iterator_t iter) {
    struct ll_iterator *iterator = iter;

        /* Check for if the pointer is null right now but there have been new things added
         * after, was supposed to be a fix for test 8 but I cant figure it out right now
         */
    if (iterator->current == NULL && iterator->current->next != NULL) {
        iterator->current = iterator->current->next;
    } else if (iterator->current == NULL && iterator->current->next == NULL) {
        return NULL;
    }

        // Increment the iterator
    void *item = iterator->current->item;
    iterator->prevAccessed = iterator->current;
    iterator->current = iterator->current->next;

        // This is for the "you can only remove once per 'next'" rule
    canRemoveFlag = 1;
    return item;
}

extern int ll_has_next(ll_iterator_t iter) {
        // Just see if the current (which would be the next to be accessed) is null or not
    struct ll_iterator *iterator = iter;
    return (iterator->current != NULL);
}

extern int ll_add(ll_iterator_t iter, void *item) {
        // Not sure if this one is even being tested in the tests, but just make a new node to insert
    struct ll_iterator *iterator = iter;
    ll_node_t *new_node = malloc(sizeof(ll_node_t));

        // Set up all the elements of the node
    new_node->item = item;
    new_node->prev = iterator->prevAccessed;
    new_node->next = iterator->current;

        // Checks for if we're adding a head or a tail
    if (iterator->prevAccessed != NULL) {
        iterator->prevAccessed->next = new_node;
    }
    if (iterator->current != NULL) {
        iterator->current->prev = new_node;
    }

    return 1;
}

extern void *ll_set(ll_iterator_t iter, void *item) {
        // Just swaps the previously accessed item to the new one
    struct ll_iterator *iterator = iter;
    void *originalItem = iterator->prevAccessed->item;
    iterator->prevAccessed->item = item;
    return originalItem;
}

extern void *ll_remove(ll_iterator_t iter) {
        // I think this one may be the source of my test 8 problems.
    struct ll_iterator *iterator = iter;
    if (iterator->prevAccessed == NULL) {
        return NULL;
    }

        // Remove the node, with different checks for the head and tail of the list
    ll_node_t *item = iterator->prevAccessed->item;
    if (iterator->prevAccessed->next != NULL && iterator->prevAccessed->prev != NULL) {
        iterator->prevAccessed->prev->next = iterator->prevAccessed->next;
        iterator->prevAccessed->next->prev = iterator->prevAccessed->prev;
    } else if (iterator->prevAccessed->next == NULL) {
        iterator->prevAccessed->prev->next = NULL;
    } else if (iterator->prevAccessed->prev == NULL) {
        iterator->prevAccessed->next->prev = NULL;
    }

        // Free the space and return
    free(iterator->prevAccessed);
    return item;
}