#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "xis.h"
#include "xcpu.h"
#include "xmem.h"

int main(int argc, char **argv) {
  if (argc != 3) {
    return 1;
  }

  FILE *file = fopen(argv[2], "r");
  int numMaxCycles = atoi(argv[1]);
  xcpu cpu;
  memset(cpu.regs, 0, sizeof(cpu.regs));
  cpu.pc = 0;
  cpu.state = 0;

  xmem_init(65536);
  unsigned char buffer[65536] = {0};

  size_t bytesRead = fread(buffer, 1, sizeof(buffer), file);
  for (size_t i = 0; i < bytesRead; i++) {
    xmem_store(&buffer[i], i);
  }
  fclose(file);

  for (size_t i = 0; i < numMaxCycles; i++) {
    xcpu_execute(&cpu);
  }

  return 0;
}

