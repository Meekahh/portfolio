#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "xis.h"
#include "xcpu.h"
#include "xmem.h"

int main(int argc, char **argv) {
  if (argc != 3) {
    return 1;
  }

  FILE *file = fopen(argv[2], "rb");

  int numMaxCycles = atoi(argv[1]);
  xcpu cpu;
  memset(&cpu, 0, sizeof(cpu));
  cpu.pc = 0;
  cpu.state = 0x0002;

  xmem_init(65536);

  unsigned char buffer[2];
  unsigned short addr = 0;
  while (fread(buffer, 1, 2, file) == 2) {
    fclose(file);

    for (int i = 0; i < numMaxCycles; i++) {
      if (!xcpu_execute(&cpu)) {
        break;
      }
    }
  }
}