#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "xis.h"
#include "xcpu.h"
#include "xmem.h"

extern int xcpu_execute(xcpu *cpu) {
    unsigned char data[2];
    xmem_load(cpu->pc, data);
    unsigned short instruction = (data[0] << 8) | data[1];
    cpu->pc += 2;

    unsigned short opcode = (instruction >> 12) & 0xF;
    unsigned short r1 = (instruction >> 8) & 0xF;
    unsigned short r2 = (instruction >> 4) & 0xF;
    unsigned short imm4 = instruction & 0xF;
    unsigned short addr8 = instruction & 0xFF;
    unsigned short addr12 = instruction & 0xFFF;

    switch (opcode) {
        case I_ADD:
          cpu->regs[r1] += cpu->regs[r2]; break;
        case I_SUB:
          cpu->regs[r1] -= cpu->regs[r2]; break;
        case I_AND:
          cpu->regs[r1] &= cpu->regs[r2]; break;
        case I_OR:
          cpu->regs[r1] |= cpu->regs[r2]; break;
        case I_XOR:
          cpu->regs[r1] ^= cpu->regs[r2]; break;
        case I_NOT:
          cpu->regs[r1] = ~cpu->regs[r1]; break;
        case I_OUT:
          putchar(cpu->regs[r1] & 0xFF); break;
        case I_RET:
            xmem_load(cpu->regs[15], data);
            cpu->pc = (data[0] << 8) | data[1];
            cpu->regs[15] += 2;
            break;
        case I_CLD:
          cpu->state &= ~0x0002; break;
        case I_STD:
          cpu->state |= 0x0002; break;
        case I_MUL:
          cpu->regs[r1] *= cpu->regs[r2]; break;
        case I_DIV:
            cpu->regs[r1] /= cpu->regs[r2];
            break;
        case I_SHR:
          cpu->regs[r1] >>= cpu->regs[r2]; break;
        case I_SHL:
          cpu->regs[r1] <<= cpu->regs[r2]; break;
        case I_TEST:
            cpu->state = (cpu->regs[r1] & cpu->regs[r2]) ? 0x0003 : 0x0002;
            break;
        case I_CMP:
            cpu->state = (cpu->regs[r1] < cpu->regs[r2]) ? 0x0003 : 0x0002;
            break;
        case I_EQU:
            cpu->state = (cpu->regs[r1] == cpu->regs[r2]) ? 0x0003 : 0x0002;
            break;
        case I_MOV:
          cpu->regs[r1] = cpu->regs[r2]; break;
        case I_LOAD:
            xmem_load(cpu->regs[r2], data);
            cpu->regs[r1] = (data[0] << 8) | data[1];
            break;
        case I_STOR: {
            unsigned char store_data[2] = {
                (cpu->regs[r1] >> 8) & 0xFF,
                cpu->regs[r1] & 0xFF
            };
            xmem_store(store_data, cpu->regs[r2]);
            break;
        }
        case I_LOADB:
            xmem_load(cpu->regs[r2], data);
            cpu->regs[r1] = data[0];
            break;
        case I_STORB: {
            unsigned char store_data[2] = {cpu->regs[r1] & 0xFF, 0};
            xmem_store(store_data, cpu->regs[r2]);
            break;
        }
        case I_JMP:
          cpu->pc = addr12; break;
        case I_CALL:
            cpu->regs[15] -= 2;
            xmem_store((unsigned char[2]){
                (cpu->pc >> 8) & 0xFF,
                cpu->pc & 0xFF
            }, cpu->regs[15]);
            cpu->pc = addr12;
            break;
        case I_LOADI:
          cpu->regs[r1] = addr8; break;
        case I_PUSH:
            cpu->regs[15] -= 2;
            xmem_store((unsigned char[2]){
                (cpu->regs[r1] >> 8) & 0xFF,
                cpu->regs[r1] & 0xFF
            }, cpu->regs[15]);
            break;
        case I_POP:
            xmem_load(cpu->regs[15], data);
            cpu->regs[r1] = (data[0] << 8) | data[1];
            cpu->regs[15] += 2;
            break;
        case I_JMPR:
          cpu->pc = cpu->regs[r1]; break;
        case I_CALLR:
            cpu->regs[15] -= 2;
            xmem_store((unsigned char[2]){
                (cpu->pc >> 8) & 0xFF,
                cpu->pc & 0xFF
            }, cpu->regs[15]);
            cpu->pc = cpu->regs[r1];
            break;
        case I_BR:
            if (cpu->state & 0x0001) {
                cpu->pc += (char)addr8;
            }
            break;
        case I_JR:
          cpu->pc += (char)addr8; break;
        default:
            cpu->state = 0x0001;
            return 0;
    }
    cpu->state = 0x0002;
    return 1;
}
