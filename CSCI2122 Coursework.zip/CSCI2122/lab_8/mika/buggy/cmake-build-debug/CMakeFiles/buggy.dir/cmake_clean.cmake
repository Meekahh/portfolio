file(REMOVE_RECURSE
  "CMakeFiles/buggy.dir/main.c.o"
  "CMakeFiles/buggy.dir/main.c.o.d"
  "CMakeFiles/buggy.dir/str_list.c.o"
  "CMakeFiles/buggy.dir/str_list.c.o.d"
  "buggy"
  "buggy.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/buggy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
