
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/tmp.JKBRLtksl2/main.c" "CMakeFiles/buggy.dir/main.c.o" "gcc" "CMakeFiles/buggy.dir/main.c.o.d"
  "/tmp/tmp.JKBRLtksl2/str_list.c" "CMakeFiles/buggy.dir/str_list.c.o" "gcc" "CMakeFiles/buggy.dir/str_list.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
