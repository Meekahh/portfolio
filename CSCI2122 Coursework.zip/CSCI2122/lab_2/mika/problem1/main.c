#include <stdio.h>

int main() {

        // Number of inputs that will follow
    int n = 1;
    scanf("%d", &n);

        // Variable Declaration Zone
    float amt = 0;
    char name[100] = "";
    float unitCost = 0;
    float total = 0;

        // Results array and index counter
    char results[100][100];
    int index = 0;

        // Takes all the inputs, computes the unit costs and adds everything to the results array
    while (n > 0) {
        scanf("%f", &amt);
        scanf("%s", &name);
        scanf("%f", &unitCost);
        sprintf(results[index], "%s : %.2f", name, unitCost * amt);
        total += unitCost * amt;
        n--;
        index++;
    }

        // Prints the results
    for (int i = 0; i < index; i++) {
        printf("%s\n", results[i]);
    }

        // Prints the total
    printf("%s %s %.2f\n", "Total", ":", total);
}
