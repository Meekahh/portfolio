#include <cstring>
#include <stdio.h>

int f(int x) {
    return x + 1;
}

int main() {
    char buffer[20];
    strcpy(buffer, "Hello");
    strcpy(&buffer[5], " World");
    printf("%s\n", buffer);
    return 0;
}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.