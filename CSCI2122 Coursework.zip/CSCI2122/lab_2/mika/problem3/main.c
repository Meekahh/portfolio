#include <stdio.h>
#include <string.h>

static void count(const char *word, int *histogram) {
        // Very painfully go through and check if its each individual letter
    for (int i = 0; i < strlen(word); i++) {
        if (word[i] == 'a') {
            histogram[0]++;
        } else if (word[i] == 'b') {
            histogram[1]++;
        } else if (word[i] == 'c') {
            histogram[2]++;
        } else if (word[i] == 'd') {
            histogram[3]++;
        } else if (word[i] == 'e') {
            histogram[4]++;
        } else if (word[i] == 'f') {
            histogram[5]++;
        } else if (word[i] == 'g') {
            histogram[6]++;
        } else if (word[i] == 'h') {
            histogram[7]++;
        } else if (word[i] == 'i') {
            histogram[8]++;
        } else if (word[i] == 'j') {
            histogram[9]++;
        } else if (word[i] == 'k') {
            histogram[10]++;
        } else if (word[i] == 'l') {
            histogram[11]++;
        } else if (word[i] == 'm') {
            histogram[12]++;
        } else if (word[i] == 'n') {
            histogram[13]++;
        } else if (word[i] == 'o') {
            histogram[14]++;
        } else if (word[i] == 'p') {
            histogram[15]++;
        } else if (word[i] == 'q') {
            histogram[16]++;
        } else if (word[i] == 'r') {
            histogram[17]++;
        } else if (word[i] == 's') {
            histogram[18]++;
        } else if (word[i] == 't') {
            histogram[19]++;
        } else if (word[i] == 'u') {
            histogram[20]++;
        } else if (word[i] == 'v') {
            histogram[21]++;
        } else if (word[i] == 'w') {
            histogram[22]++;
        } else if (word[i] == 'x') {
            histogram[23]++;
        } else if (word[i] == 'y') {
            histogram[24]++;
        } else if (word[i] == 'z') {
            histogram[25]++;
        }
    }
}

static void print_histogram(int *histogram) {
    for (int i = 0; i < 26; i++) {
            // Puts the letter and the colon for each down
        if (histogram[i] > 0) {
            printf("%c : ", 'a' + i);

            // Deals with making all the asterisks
            for (int j = 0; j < histogram[i]; j++) {
                printf("*");
            }
            printf("\n");
        }
    }
}

int main() {
    int histogram[26];
    memset(histogram, 0, sizeof(histogram));
    char cur[100];
    scanf("%s", cur);
    while (1) {
        if (strcmp(cur, ".") == 0) {
            break;
        }
        count(cur, histogram);
        scanf("%s", cur);
    }
    print_histogram(histogram);
    return 0;
}

