#include <stdio.h>
#include <string.h>

int main() {
        // Variable Declaration Zone
    char cur[100];
    char nxt[100];
    char results[100][100];
    int n = 0; // Index counter

        // Add first word
    scanf("%s", cur);
    if (strcmp(cur, ".") == 0) {
        return 0;
    }
    strcpy(results[n], cur);
    n++;

        // Loop until period
    while (1) {
        scanf("%s", nxt);

        if (strcmp(nxt, ".") == 0) {
            break;
        }

        if (strcmp(cur, nxt) != 0) {
            strcpy(results[n], nxt);
            n++;
        }

            // Turn 'current' into 'next'
        strcpy(cur, nxt);
    }

    for (int i = 0; i < n; i++) {
        printf("%s\n", results[i]);
    }

    return 0;
}
