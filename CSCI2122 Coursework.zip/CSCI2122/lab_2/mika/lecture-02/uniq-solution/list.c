//
// Created by Alex Brodsky on 2021-04-29.
//

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "list.h"

extern list_t *list_new() {
    list_t * list = calloc(1, sizeof(list_t));
    assert(list != NULL);
    return list;
}


extern void list_add(list_t *list, char *word) {
    node_t * node = calloc(1, sizeof(node_t));

    assert(list != NULL);
    assert(node != NULL);

    strcpy(node->word, word);

    if (list->head == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
}


extern int list_contains(list_t *list, char *word) {
    assert(list != NULL);
    assert(word != NULL);

    for (node_t *ptr = list->head; ptr != NULL; ptr = ptr->next) {
        if (!strcmp(word, ptr->word)) {
            return 1;
        }
    }
    return 0;
}