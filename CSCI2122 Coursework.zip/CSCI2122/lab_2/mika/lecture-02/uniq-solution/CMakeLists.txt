cmake_minimum_required(VERSION 3.11)
project(uniq C)

set(CMAKE_C_STANDARD 99)

add_executable(uniq main.c list.h list.c)