/* Author: Alex Brodsky
 * Purpose: Example of coding, this program implements a
 *          simple uniq algorithm
 * Banner #: ???
 */

#include <stdio.h>
#include <string.h>
#include "list.h"

/* create empty list
 * loop
 *   word = next_word()
 *   if word == "end" break
 *   if word is not in list
 *     add word to list
 *     print word
 * return
 */

int main() {
    list_t *list = list_new();
    char word[100];

    for (;;) {
        if (scanf("%s", word) != 1) {
            break;
        } else if (!strcmp(word, "end")) {
            break;
        }

        if (!list_contains(list, word)) {
            list_add(list, word);
            printf("%s\n", word);
        }
    }
    return 0;
}
