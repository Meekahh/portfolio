//
// Created by Alex Brodsky on 2021-04-29.
//

#ifndef UNIQ_LIST_H
#define UNIQ_LIST_H

typedef struct node {
    struct node *next;
    char word[100];
} node_t;

typedef struct list {
    node_t *head;
    node_t *tail;
} list_t;

extern list_t *list_new();
extern void list_add(list_t *list, char *word);
extern int list_contains(list_t *list, char *word);
#endif //UNIQ_LIST_H
