//
// Created by Mika Molloy-Reilly on 2026-09-10.
//

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

struct linked_list;
struct linked_list *ll_create();
int ll_add(struct linked_list *ll, char *data);
int ll_search(struct linked_list *ll, char *data);
#endif //LINKED_LIST_H
