#include <stdio.h>
#include <string.h>

#include "linked_list.h"

int main() {
      struct linked_list *ll = ll_create();

      ll

      char buffer[100]; // 99 is max number of allowed char, but C needs a null character to terminate words


      while(1) {
        scanf("%99s", buffer);

        if (strcmp(buffer, "end") == 0) break;
        }



    printf("Hello, World!\n");
    return 0;
}
