//
// Created by Mika Molloy-Reilly on 2026-09-10.
//

#include "linked_List.h"

struct node {
  struct node *next;
  char *data;
};

struct linked_list {
  struct node *head;
  struct node *tail;
  };

  struct linked_list *ll_create() {


  }