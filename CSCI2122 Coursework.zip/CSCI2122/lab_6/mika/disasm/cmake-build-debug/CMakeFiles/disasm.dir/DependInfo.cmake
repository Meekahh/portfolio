
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/tmp.YZazhcH3fO/line.c" "CMakeFiles/disasm.dir/line.c.o" "gcc" "CMakeFiles/disasm.dir/line.c.o.d"
  "/tmp/tmp.YZazhcH3fO/main.c" "CMakeFiles/disasm.dir/main.c.o" "gcc" "CMakeFiles/disasm.dir/main.c.o.d"
  "/tmp/tmp.YZazhcH3fO/max3.c" "CMakeFiles/disasm.dir/max3.c.o" "gcc" "CMakeFiles/disasm.dir/max3.c.o.d"
  "/tmp/tmp.YZazhcH3fO/min.c" "CMakeFiles/disasm.dir/min.c.o" "gcc" "CMakeFiles/disasm.dir/min.c.o.d"
  "/tmp/tmp.YZazhcH3fO/sum.c" "CMakeFiles/disasm.dir/sum.c.o" "gcc" "CMakeFiles/disasm.dir/sum.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
