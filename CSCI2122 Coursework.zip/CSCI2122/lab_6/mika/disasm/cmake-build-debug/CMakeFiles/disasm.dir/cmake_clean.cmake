file(REMOVE_RECURSE
  "CMakeFiles/disasm.dir/line.c.o"
  "CMakeFiles/disasm.dir/line.c.o.d"
  "CMakeFiles/disasm.dir/main.c.o"
  "CMakeFiles/disasm.dir/main.c.o.d"
  "CMakeFiles/disasm.dir/max3.c.o"
  "CMakeFiles/disasm.dir/max3.c.o.d"
  "CMakeFiles/disasm.dir/min.c.o"
  "CMakeFiles/disasm.dir/min.c.o.d"
  "CMakeFiles/disasm.dir/sum.c.o"
  "CMakeFiles/disasm.dir/sum.c.o.d"
  "disasm"
  "disasm.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/disasm.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
