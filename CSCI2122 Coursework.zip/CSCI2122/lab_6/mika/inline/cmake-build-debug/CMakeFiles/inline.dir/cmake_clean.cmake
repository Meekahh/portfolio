file(REMOVE_RECURSE
  "CMakeFiles/inline.dir/main.c.o"
  "CMakeFiles/inline.dir/main.c.o.d"
  "inline"
  "inline.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/inline.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
