#include <stdio.h>

long min_bits(long x, long y) {
    long result;
    /* Determine which x or y has fewer bits.
     * Use the popcnt instruction to count the number of bits in a long
     * This instruction calculates the number of bits set to 1 in the source operand and
     * returns the count in the destination operand (must be a register).
     */
    asm ("popcnt %1, %%r8;"
        "popcnt %2, %%r9;"
        "cmp %%r8, %%r9;"
        "jl 1f;"
        "movq %1, %0;"
        "jmp 2f;"
        "1:;"
        "movq %2, %0;"
        "2:;"
        : "=r" (result)
        : "r" (x), "r" (y)
        : "r8", "r9" );

    return result;
}

int call_min_bits(long x, long y) {
    long n;
    /* Call the min_bits function above
     */
    asm ("movq %1, %%rdi;"
        "movq %2, %%rsi;"
        "call min_bits;"
        "movq %%rax, %0;"
        : "=r" (n)
        : "r" (x), "r" (y)
        : "rdi", "rsi", "rax" );

    return (int)n;
}

unsigned int sum(unsigned int *data, long size) {
    unsigned int result = 0;
    /* Computes the sum of the integers in data array
     */
    asm ("movq %1, %%rsi;"
        "movq %2, %%rcx;"
        "movl $0, %%eax;"
        "cmpq $0, %%rcx;"
        "jz 2f;"
        "1:;"
        "addl (%%rsi), %%eax;"
        "addq $4, %%rsi;"
        "subq $1, %%rcx;"
        "jnz 1b;"
        "2:;"
        "movl %%eax, %0;"
        : "=r" (result)
        : "r" (data), "r" (size)
        : "rsi", "rcx", "rax" );

    return result;
}

int main() {
    int n;
    int data[5] = {1, 2, 3, 4, 5};

    scanf("%d", &n);  /* read in the test to perform */
    switch(n) {
        case 0:
            printf("%ld = min_bits(%d, %d)\n", min_bits(8,7), 7, 8);
            break;

        case 1:
            printf("%d = call(%d, %d)\n", call_min_bits(15,16),15, 16);
            break;

        case 2:
            printf("%d = sum(data)\n", sum(data, 5));
            break;

        default:
            break;
    }
    return 0;
}


