//
// Created by Alex Brodsky on 2023-09-20.
//

#include <stdlib.h>
#include <assert.h>
#include "linked_list.h"

/**********************************
 * See bottom of file for your work
 *********************************/

extern linked_list_t * ll_new() {
    linked_list_t * list = calloc(1,sizeof(linked_list_t));
    return list;
}

extern void ll_destroy(linked_list_t *list) {
    assert(list != NULL);
    while (list->head != NULL) {
        ll_node_t *tmp = list->head;
        list->head = list->head->next;
        free(tmp);
    }

    free(list);
}

static ll_node_t *new_node(void *item, ll_node_t *prev, ll_node_t *next) {
    ll_node_t *n = calloc(1, sizeof(ll_node_t));
    if (n != NULL) {
        n->item = item;
        n->prev = prev;
        n->next = next;
    }
    return n;
}


extern int ll_add_front(linked_list_t *list, void *item) {
    assert(list);

    ll_node_t *n = new_node(item,NULL, list->head);
    if (n != NULL) {
        if (list->tail == NULL) {
            list->tail = n;
        } else {
            list->head->prev = n;
        }
        list->head = n;
    }
    return n != NULL;
}

extern int ll_add_back(linked_list_t *list, void *item) {
    assert(list);

    ll_node_t *n = new_node(item,list->tail, NULL);
    if (n != NULL) {
        if (list->head == NULL) {
            list->head = n;
        } else {
            list->tail->next = n;
        }
        list->tail = n;
    }
    return n != NULL;
}

extern void * ll_remove_front(linked_list_t *list) {
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        ll_node_t *n = list->head;
        list->head = list->head->next;
        if (list->head == NULL) {
            list->tail = NULL;
        } else {
            list->head->prev = NULL;
        }

        item = n->item;
        free(n);
    }
    return item;
}

extern void * ll_remove_back(linked_list_t *list) {
    assert(list);
    
    void *item = NULL;
    if (list->tail != NULL) {
        ll_node_t *n = list->tail;
        list->tail = list->tail->prev;
        if (list->tail == NULL) {
            list->head = NULL;
        } else {
            list->tail->next = NULL;
        }

        item = n->item;
        free(n);
    }
    return item;
}

extern void * ll_get_front(linked_list_t *list) {
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        item = list->head->item;
    }
    return item;
}

extern void * ll_get_back(linked_list_t *list) {
    assert(list);

    void *item = NULL;
    if (list->head != NULL) {
        item = list->tail->item;
    }
    return item;
}


/************************************************************************
 * Your code below 
 ************************************************************************/

extern int ll_size(linked_list_t *list) {
  ll_node_t *node = list->head;
  int counter = 0;

      /* Increment the counter and iterate through the loop until the node is found */
  while (node != NULL) {
    counter++;
    node = node->next;
  }

      /* Return the count */
  return counter;
}

extern int ll_is_empty(linked_list_t *list) {
        /* If a tail exists, list cannot be empty */
    if (list->tail == NULL) {
      return 1;
    }
    return 0;
}

extern int ll_insert(linked_list_t *list, ll_node_t *node, void *item) {
        /* Check for nulls */
    if (list == NULL || node == NULL) {
        return 0;
    }

        /* Loop until you find the node */
    ll_node_t *curr = list->head;
    while (curr != NULL && curr != node) {
        curr = curr->next;
    }

    if (curr == NULL) {
        return 0;
    }

        /* Create the new node and set the nexts and prevs and that to eachother */
    ll_node_t *next = curr->next;
    ll_node_t *nodeToInsert = new_node(item, curr, next);
    if (nodeToInsert == NULL) {
        return 0;
    }

    curr->next = nodeToInsert;
        /* Extra check in case the node is getting put at the tail */
    if (next != NULL) {
        next->prev = nodeToInsert;
    }

    return 1;
}


extern void * ll_remove(linked_list_t *list, ll_node_t *node) {
        /* Check for nulls */
    if (list == NULL || node == NULL) {
        return NULL;
    }

        /* Find the node that is getting removed */
    ll_node_t *curr = list->head;
    while (curr != node) {
        curr = curr->next;
    }

        /* Removes the node with an extra little check
           for if the head or tail is being removed */
    if (curr->prev != NULL) {
        curr->prev->next = curr->next;
    } else {
        list->head = curr->next;
    }
    if (curr->next != NULL) {
        curr->next->prev = curr->prev;
    } else {
        list->tail = curr->prev;
    }

         /* Free the node and return the item etc */
      char *item = node->item;
      free(curr);
      return item;
}
