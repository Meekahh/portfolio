#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linked_list.h"

int main() {

        /* Struct to hold the items */
    typedef struct {
        int amt;
        char name[100];
        float unitCost;
    } item;

        /* Variable Declaration Zone */
    int amt = 0;
    char name[100] = "";
    float unitCost = 0;
    linked_list_t *bill = ll_new();
    char endFlag = 0;

        /* Put all the items into the linked list */
    while (!endFlag) {
        scanf("%i", &amt);
        if (amt == 0) {
            endFlag = 1;
        } else {
            scanf("%s", name);
            scanf("%f", &unitCost);

            item *newItem = malloc(sizeof(item));
            newItem->amt = amt;
            strcpy(newItem->name, name);
            newItem->unitCost = unitCost;

            ll_add_back(bill, newItem);
        }
    }

        /* Check for duplicates and add them together */
    ll_node_t *curr = bill->head;
    while (curr != NULL) {
        ll_node_t *curr2 = curr->next;
        while (curr2 != NULL) {
                /* Check if the items are the same */
            if (strcmp(((item *)curr->item)->name, ((item *)curr2->item)->name) == 0
                && ((item *)curr->item)->unitCost == ((item *)curr2->item)->unitCost) {

                ((item *)curr->item)->amt += ((item *)curr2->item)->amt;
                ((item *)curr2->item)->amt = 0;
                }
            curr2 = curr2->next;
        }
        curr = curr->next;
    }

        /* Printing logic */
    curr = bill->head;
    while (curr != NULL) {
        if (((item *)curr->item)->amt > 0) { /* Make sure to only print positive amts */
            printf("%i %s %.2f\n", ((item *)curr->item)->amt,
                 ((item *)curr->item)->name, ((item *)curr->item)->unitCost);
        }
        curr = curr->next;
    }
    ll_destroy(bill);
    return 0;
}
