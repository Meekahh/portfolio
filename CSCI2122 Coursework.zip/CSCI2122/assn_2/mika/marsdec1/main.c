#include <stdio.h>
#include <stdint.h>

int main() {
        /* Variable Declaration Zone */
    int numInputs;
    scanf("%d", &numInputs);
    if (numInputs <= 0) {
        return 0;
    }

        /* Processing */
    for (int i = 0; i < numInputs; i++) {
            /* Read the next line */
        int numFollowing;
        scanf("%d", &numFollowing);
        unsigned int hexBytes[100] = {0};
        for (int j = 0; j < numFollowing; j++) {
            scanf("%x", &hexBytes[j]);
        }

            /* Put everything into 1 big number */
        int64_t totalVal = 0;
        for (int j = 0; j < numFollowing; j++) {
            totalVal = (totalVal << 8) | hexBytes[j];
        }

            /* Find L with a bitmask */
        int64_t L = (totalVal >> ((numFollowing * 8) - 5)) & 0b00011111;
        if (L == 0) {
            break;
        }

            /* Figure out the amount that it has to shift by to process the number */
        int64_t amtToShift = ((numFollowing * 8) - 5 - L);
        if (amtToShift < 0) {
            amtToShift = 0;
        } else if (amtToShift > 31) {
            amtToShift = 31;
        }

            /* Adjust to check the next L bits */
        int64_t finalVal = (totalVal >> amtToShift) & ((unsigned long long)1 << L) - 1;
        if (L > 0 && (finalVal & ((unsigned long long)1 << (L - 1)))) {
            finalVal -= ((unsigned long long)1 << L);
        }

            /* Print any lines with values */
        if (numFollowing > 0) {
            printf("Line %i, integer 1: %lld\n", i + 1, finalVal);
        }
    }
    return 0;
}