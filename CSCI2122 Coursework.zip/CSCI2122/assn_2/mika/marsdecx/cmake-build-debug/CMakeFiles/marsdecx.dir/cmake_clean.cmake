file(REMOVE_RECURSE
  "CMakeFiles/marsdecx.dir/main.c.o"
  "CMakeFiles/marsdecx.dir/main.c.o.d"
  "marsdecx"
  "marsdecx.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/marsdecx.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
