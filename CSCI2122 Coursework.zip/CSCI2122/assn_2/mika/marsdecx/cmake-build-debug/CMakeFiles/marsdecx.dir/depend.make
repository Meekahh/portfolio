# Empty dependencies file for marsdecx.
# This may be replaced when dependencies are built.
