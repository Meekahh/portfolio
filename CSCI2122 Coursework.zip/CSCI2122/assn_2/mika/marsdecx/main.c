#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int main() {
        /* Variable Declaration Zone */
    int numInputs;
    scanf("%d", &numInputs);
    if (numInputs <= 0) {
        return 0;
    }

        /* Processing */
    for (int i = 0; i < numInputs; i++) {
        int counter = 1;
        int numFollowing;
        scanf("%d", &numFollowing);
        uint64_t totalVal = 0;
        unsigned int hexBytes[100] = {0};

            /* Read all the bytes using the hex input thing (%x) */
        for (int j = 0; j < numFollowing; j++) {
            scanf("%x", &hexBytes[j]);
        }

            /* Put everything into 1 big number using the bitwise or */
        for (int j = 0; j < numFollowing; j++) {
            totalVal = (totalVal << 8) | hexBytes[j];
        }

            /* Set a variable that tracks how many bits are left to be processed */
        int remainingBits = numFollowing * 8;
        while (remainingBits > 5) {
            int shiftAmount = remainingBits - 5;
            if (shiftAmount < 0) {
                shiftAmount = 0;
            }

                /* Set up L and run a few checks to make sure it isnt an out of bounds number */
            int64_t L;
            if (shiftAmount > 63) {
                L = 0;
            } else {
                L = (totalVal >> shiftAmount) & 0b00011111;
            }
            if (L == 0) {
                break;
            }

                /* Update the remaining bits after processing L and find what part of the number should be skipped */
            remainingBits -= 5;
            int amtToShift = remainingBits - L;
                /* I'm not actually sure if these checks are necessary but they helped with one of the tests */
            if (amtToShift < 0) {
                amtToShift = 0;
            }
            if (amtToShift > 63) {
                amtToShift = 63;
            }

                /* Find the specific part of the grand input for this section, w some extra handling for negatives */
            int64_t finalVal = (totalVal >> amtToShift) & ((unsigned long long)1 << L) - 1;
            if (L > 0 && (finalVal & ((unsigned long long)1 << (L - 1)))) {
                finalVal -= ((unsigned long long)1 << L);
            }

                /* Print line, move the number along, repeat :) */
            printf("Line %i, integer %i: %ld\n", i + 1, counter, finalVal);
            counter++;
            remainingBits -= L;
            totalVal = totalVal & (((unsigned long long)1 << remainingBits) - 1);
        }
    }
    return 0;
}