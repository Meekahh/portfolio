//
// Created by Alex Brodsky on 2023-09-29.
//

#include "arraylst.h"
#include <stdlib.h>

extern arraylst_t *arraylst_new(int capacity) {
  arraylst_t *list = (arraylst_t *)malloc(sizeof(arraylst_t));
  list->capacity = capacity;
  list->size = 0;
  void **array = (void **)malloc(capacity * sizeof(void *));
  list->items = array;
  return list;
}

extern int arraylst_add(arraylst_t *list, void *item) {
  if (list->size < list->capacity) {
    list->items[list->size] = item;
    list->size += 1;
    return list->size;
  } else {
  return -1;
  }
}

extern void * arraylst_get(arraylst_t *list, int idx) {
  if (idx >= 0 && idx < list->size) {
    return list->items[idx];
  }
  return NULL;
}

extern int arraylst_remove(arraylst_t *list, int idx) {
  if (!(idx >= 0 && idx < list->size)) {
    return 0;
  }

  for (int i = idx; i < list->size - 1; i++) {
    list->items[i] = list->items[i + 1];
  }

  list->items[list->size - 1] = NULL;
  list->size--;
  return 1;
}

extern void arraylst_destroy(arraylst_t *list) {
  free(list->items);
  free(list);
}
