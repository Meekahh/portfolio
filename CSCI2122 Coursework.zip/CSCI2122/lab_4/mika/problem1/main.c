#include <stdio.h>
#include <string.h>

int main() {

      /* Struct to hold the items */
    typedef struct {
        int amt;
        char name[100];
        float unitCost;
    } item;

        /* Number of items to follow */
    int n = 0;
    scanf("%d", &n);

        /* Variable Declaration Zone */
    int amt = 0;
    char name[100] = "";
    float unitCost = 0;
    float total = 0;
    item bill[n];

        /* Add everything to the bill array */
    for (int i = 0; i < n; i++) {
        scanf("%i", &amt);
        scanf("%s", &name);
        scanf("%f", &unitCost);

        bill[i].amt = amt;
        strcpy(bill[i].name, name);
        bill[i].unitCost = unitCost;
    }

    int numOfDupes = 0;
        /* Check for dupes */
    for (int i = 1; i < n; i++) {
      for (int j = i - 1; j >= 0; j--) {
        if (strcmp(bill[i].name, bill[j].name) == 0 && bill[i].unitCost == bill[j].unitCost) {
          bill[j].amt = bill[i].amt + bill[j].amt;
          bill[i].amt = 0;
          numOfDupes++;
        }
      }
    }

        /* Printing logic */
    n = n - numOfDupes;
    printf("%d\n", n);
    for (int i = 0; i <= n; i++) {
      if (bill[i].amt > 0) { /* Make sure amt is positive */
        printf("%i %s %.2f\n", bill[i].amt, bill[i].name, bill[i].unitCost);
        }
    }

    return 0;
}
