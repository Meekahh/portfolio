#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "bitmap.h"

int problem2();

int main() {
    problem2();
    return 0;
}

int problem2() {
        // Variable Declaration Zone
    int m = 0;
    int n = 0;
    scanf("%i %i", &m, &n);
    char *bitmap = bitmap_new(m);
        // Read the input and put new stuff in the bitmap, and take out duplicates (only odd # of appearances)
    for (int i = 0; i < n; i++) {
        int cur;
        scanf("%i", &cur);

        if (bitmap_test(bitmap, cur)) {
            bitmap_reset(bitmap, cur);
        } else {
            bitmap_set(bitmap, cur);
        }
    }
    printf("Odd:");
    for (int i = 0; i <= m; i++) {
        if (bitmap_test(bitmap, i)) {
            printf(" %i", i);
        }
    }
    return 0;
}
