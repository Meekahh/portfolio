#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "bitmap.h"

int problem3();

int main() {
    problem3();
    return 0;
}

int problem3() {
        // Variable Declaration Zone
    int m = 0;
    int n = 0;
    scanf("%i %i", &m, &n);
    char *bitmap = bitmap_new(m);
        // Read the input and put stuff in the bitmap
    for (int i = 0; i < n; i++) {
        int cur;
        scanf("%i", &cur);
        if (!bitmap_test(bitmap, cur)) {
            bitmap_set(bitmap, cur);
        }
    }

        // Make variables to track the start index and length of both the current and max sequences
    int curStartI = 0;
    int curLength = 0;
    int maxStartI = 0;
    int maxLength = 0;

        // Check through the bitmap for any sequences
    for (int i = 0; i <= m; i++) {
        if (bitmap_test(bitmap, i)) {
            if (curLength == 0) {
                curStartI = i;
            }
            curLength++;
        } else {
            if (curLength > maxLength) {
                maxStartI = curStartI;
                maxLength = curLength;
            }
            curLength = 0;
        }
    }

    if (curLength > maxLength) {
        maxStartI = curStartI;
        maxLength= curLength;
    }

    printf("Max sequence:");
    for (int i = 0; i < maxLength; i++) {
        printf(" %i", maxStartI + i);
    }
    printf("\n");
    return 0;
}