#include <stdio.h>
#include <string.h>

int main() {
      /* Variable Declaration Zone */
    int numWords;
    scanf(" %i", &numWords);
    char result[numWords][30];
    char resultLetters[numWords][7];
    int resultTotalWords[numWords];
    char dictLetters[numWords][30];
    int panagrams = 0;
    int dupeFlag = 0;
    int uniqueCount = 0;
    int dictUniqueCount[numWords];

      /* Memset Zone */
    memset(resultTotalWords, 0, sizeof(resultTotalWords));
    memset(dictUniqueCount, 0, sizeof(dictUniqueCount));

      /* Processing loop */
    for (int i = 0; i < numWords; i++) {
          /* Reset variables */
        memset(dictLetters[i], 0, sizeof(dictLetters[i]));
        uniqueCount = 0;
        dictUniqueCount[i] = 0;
        char curr[30];
        char currLetters[30];
        memset(currLetters, 0, sizeof(currLetters));

          /* Scan and process */
        scanf(" %s", curr);
        for (int j = 0; j < strlen(curr); j++) {
              /* Create a dictionary entry with all the
               * letters that are in the current word */
            int dictDupeFlag = 0;
            for (int k = 0; k < dictUniqueCount[i]; k++) {
                if (curr[j] == dictLetters[i][k]) {
                    dictDupeFlag = 1;
                    break;
                }
            }

              /* If the letter is new, add it to the count */
            if (dictDupeFlag == 0) {
                dictLetters[i][dictUniqueCount[i]] = curr[j];
                dictUniqueCount[i]++;
            }
        }

          /* Only bother with processing words of length 7 or greater */
        if (strlen(curr) >= 7) {
            for (int j = 0; j < strlen(curr); j++) {
                dupeFlag = 0; /* Reset dupeFlag for each letter */

                for (int k = 0; k < j; k++) {
                    if (curr[j] == curr[k]) {
                        dupeFlag = 1; /* Toggle dupeFlag if letter already in word */
                    }
                }

                if (!dupeFlag) {
                      /* Add the letter to the current letter
                       * array, and add 1 to the count */
                    currLetters[uniqueCount] = curr[j];
                    uniqueCount++;
                }
            }

            if (uniqueCount == 7) {
                  /* Add the word to the results array if
                   * it has exactly 7 different letters in it */
                strcpy(result[panagrams], curr);
                memcpy(resultLetters[panagrams], currLetters, 7);

                  /* Bubble Sort into alphabetical order */
                for (int i = 0; i < 6; i++) {
                    for (int j = 0; j < 6 - i; j++) {
                        if (resultLetters[panagrams][j] > resultLetters[panagrams][j + 1]) {
                            char temp = resultLetters[panagrams][j];
                            resultLetters[panagrams][j] = resultLetters[panagrams][j + 1];
                            resultLetters[panagrams][j + 1] = temp;
                        }
                    }
                }

                resultTotalWords[panagrams] = 0;
                panagrams++;
            }
        }
    }

      /* Figure out how many words in the provided
       * dictionary can be created with each panagram */
    for (int i = 0; i < panagrams; i++) {
        for (int j = 0; j < numWords; j++) {
            int notInWordsFlag = 0;

              /* Skip words with more than 7 unique characters */
            if (dictUniqueCount[j] > 7) {
                continue;
            }

              /* Check each letter to see if they match individually */
            for (int k = 0; k < strlen(dictLetters[j]); k++) {
                int letterMatched = 0;
                for (int l = 0; l < 7; l++) {
                    if (dictLetters[j][k] == resultLetters[i][l]) {
                        letterMatched = 1;
                        break;
                    }
                }

                if (!letterMatched) {
                    notInWordsFlag = 1;
                    break;
                }
            }

              /* Increment the counter for each panagram based
               * on number of words in dictionary it can make */
            if (!notInWordsFlag) {
                resultTotalWords[i]++;
            }
        }
    }

      /* Printing logic */
    if (panagrams > 0) {
        for (int i = 0; i < panagrams; i++) {
            for (int j = 0; j < strlen(result[i]); j++) {
                printf("%c", result[i][j]);
            }

            printf(" : ");
            for (int j = 0; j < 6; j++) {
                printf("%c ", resultLetters[i][j]);
            }

            printf("%c", resultLetters[i][6]);
            printf(" ; %i", resultTotalWords[i]);
            printf("\n");
        }
    }

    return 0;
}