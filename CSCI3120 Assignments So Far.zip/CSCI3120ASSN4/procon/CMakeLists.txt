cmake_minimum_required(VERSION 3.25)
project(procon C)

set(CMAKE_C_STANDARD 99)

add_executable(procon main.c deque.c deque.h
        support.c
        support.h)
