#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "support.h"
#include "deque.h"

// This queue is NOT thread-safe.
static deque_t queue;

    // First slot is prod., second is cons.
static volatile int wants_a_turn[2] = {0, 0};

    // 0 = prod., 1 = cons.
static volatile int whos_turn = 0;


void lock(int user) {
  int other_user = 0;
  if (user == 0) {
    other_user = 1;
    }
  wants_a_turn[user] = 1;
  whos_turn = other_user;
  __sync_synchronize();
  while (wants_a_turn[other_user] == 1 && whos_turn == other_user) {
    // Hang out for a little bit
  }
  __sync_synchronize();
}

void unlock(int user) {
    __sync_synchronize();
    wants_a_turn[user] = 0;
}

// YOUR CODE HERE
// You will need to implement your own lock() and unlock() functions.
// YOU MAY NOT USE THE PTHREAD API or ANY SEMAPHORE or LOCK API.
// The lock() and unlock() functions must be a spin-lock.
// Hint: Any shared static variable you use must be volatile.
//       e.g., static volatile int flag = 0;
// Hint 2: Right before the while loop performing the spinning, add a
//         call to __sync_synchronize() to en-sure that all statements
//         prior to the while loop are completed. (Not reordered after
//         the while loop.)

void *producer(void *arg) {
    for (int done = 0; !done;) {
        struct msg *msg = make(&done);
        if (msg != NULL) {
            lock(0);
            deque_push_back(queue, msg);
            unlock(0);
        }
    }

        // YOUR CODE HERE
        // Enqueue the message to the back of queue.
        // Notes:
        // - The deque is NOT thread-safe, so you need to protect it with a lock.
    return NULL;
}

void *consumer(void *arg) {
    for (int done = 0; !done;) {
        struct msg *msg = NULL;
        while (msg == NULL) {
            lock(1);
            msg = deque_pop_front(queue);
            unlock(1);
        }

        // YOUR CODE HERE
        // Dequeue a message from the front of the queue.
        // Notes:
        // - The deque_pop_front() function returns NULL if the deque is empty.
        // - The deque is NOT thread-safe, so you need to protect it with a lock.

        use(msg, &done);
        free(msg);
    }
    return NULL;
}

int main(void) {
    queue = deque_new(4);
    if (queue == NULL) {
        perror("Failed to create deque");
        exit(1);
    }

    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);

    // YOUR CODE HERE
    // 1. Create two threads, storing the thread IDs in the global variables
    //    - producer_thread for the producer
    //    - consumer_thread for the consumer
    // 2. Join the threads before exiting

    return 0;
}
