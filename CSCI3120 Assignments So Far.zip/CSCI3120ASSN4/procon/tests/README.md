# Here's what each test covers:

- **00:** The example from the handout.
- **01:** Only `done 0`, the smallest possible input.
- **02:** Three messages plus `done`, which stays under the deque's starting capacity of 4.
- **03:** 1,000 messages with no sleeps, so the lock is contended the whole time.
- **04:** The consumer sleeps first while 2,000 messages pile up, so the deque has to grow several times while the consumer comes back and competes for the lock.
- **05:** A `producer_sleep` after every item, so the consumer keeps spinning on an empty queue.
- **06:** Producer and consumer sleeps alternate.
- **07:** A 5,000-message random stress test with a few short sleeps mixed in.
- **08:** Unusual inputs:
  - words that are close to the keywords (`Done`, `done_not`, `Producer_sleep`)
  - a 99-character word, which is the most the 100-byte buffer can hold
  - negative numbers, `INT_MAX` and `INT_MIN`
  - sleeps of zero
- **09:** Extra input after `done`, which must be ignored. This is why its `.in` has more lines than its `.out`.
