//
// Created by Alex Brodsky on 2026-03-23.
//

#ifndef MEDS_DEQUE_H
#define MEDS_DEQUE_H

typedef struct deque *deque_t;

/**
 * Creates a new deque with the specified initial capacity.
 *
 * @param capacity The desired initial capacity of the deque.
 * @return A newly allocated deque handle on success, or NULL if allocation fails.
 */
deque_t deque_new(int capacity);

/**
 * Frees a deque and all resources owned by it.
 *
 * @param deque The deque to free. May not be NULL.
 * @return None.
 */
void deque_free(deque_t deque);

/**
 * Returns the number of elements currently stored in the deque.
 *
 * @param deque The deque to query.  May not be NULL.
 * @return The current number of elements in the deque.
 */
int deque_size(deque_t deque);

/**
 * Returns the current capacity of the deque.
 *
 * @param deque The deque to query.  May not be NULL.
 * @return The maximum number of elements the deque can hold without resizing.
 */
int deque_capacity(deque_t deque);

/**
 * Inserts an element at the front of the deque.
 *
 * If the deque is full, the capacity of the deque is doubled by allocating
 * a new array twice the size of the old array and copying all the items
 * into the new array.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @param data Pointer to the element to insert.
 * @return 1 on success, or a zero value on failure.
 */
int deque_push_front(deque_t deque, void *data);

/**
 * Removes and returns the element at the front of the deque.
 *
 * @param deque The deque to modify. May not be NULL.
 * @return The removed front element, or NULL if the deque is empty.
 */
void *deque_pop_front(deque_t deque);

/**
 * Returns the element at the front of the deque without removing it.
 *
 * @param deque The deque to query. May not be NULL.
 * @return The front element, or NULL if the deque is empty.
 */
void *deque_peek_front(deque_t deque);

/**
 * Inserts an element at the back of the deque.
 *
 * If the deque is full, the capacity of the deque is doubled by allocating
 * a new array twice the size of the old array and copying all the items
 * into the new array.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @param data Pointer to the element to insert.
 * @return 1 on success, or a zero value on failure.
 */
int deque_push_back(deque_t deque, void *data);

/**
 * Removes and returns the element at the back of the deque.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @return The removed back element, or NULL if the deque is empty.
 */
void *deque_pop_back(deque_t deque);

/**
 * Returns the element at the back of the deque without removing it.
 *
 * @param deque The deque to query.    May not be NULL.
 * @return The back element, or NULL if the deque is empty.
 */
void *deque_peek_back(deque_t deque);

#endif //MEDS_DEQUE_H
