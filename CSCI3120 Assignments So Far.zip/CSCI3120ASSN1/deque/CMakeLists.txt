cmake_minimum_required(VERSION 3.25)
project(deque C)

set(CMAKE_C_STANDARD 99)

add_executable(deque main.c
        deque.c
        deque.h)
