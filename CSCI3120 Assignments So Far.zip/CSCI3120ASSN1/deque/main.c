#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include "deque.h"

static int myatoi(char *str) {
    long value = strtol(str, NULL, 10);
    if (value == 0 && errno == EINVAL) {
        printf("Invalid integer value in test script: %s", str);
        exit(1);
    }
    return (int)value;
}

static void check_bool(int success, char *op, int line) {
    if (!success) {
        printf("%d: FAILED: %s\n", line, op);
    } else {
        printf("%d: PASSED: %s\n", line, op);
    }
}

static void check_int(int result, int cmp, const char *op, int line) {
    if (result != cmp) {
        printf("%d: FAILED: %s\n", line, op);
        printf("  Expected: %d\n", cmp);
        printf("  Actual:   %d\n", result);
    } else {
        printf("%d: PASSED: %s\n", line, op);
    }
}

static void check_string(char *result, const char *cmp, const char *op, int line, int free_result) {
    assert(cmp != NULL);
    assert(op != NULL);

    if (result == NULL) {
        printf("%d: FAILED: %s (got NULL)\n", line, op);
    } else if (strcmp(result, cmp) != 0) {
        printf("%d: FAILED: %s\n", line, op);
        printf("  Expected: %s\n", cmp);
        printf("  Actual:   %s\n", result);
    } else {
        printf("%d: PASSED: %s\n", line, op);
    }

    if (free_result && result != NULL) {
        free(result);
    }
}

static int generate_deque_test(int n) {
    deque_t deque = deque_new(4);

    char buffer[100];

    for (int i = 0; i < n; i++) {
        long int r = random();
        switch (r % 10) {
            case 0:
            case 1:
                sprintf(buffer, "%lu", r);
                deque_push_back(deque, strdup(buffer));
                printf("push_back %s\n", buffer);
                break;
            case 2:
            case 3:
                sprintf(buffer, "%lu", r);
                deque_push_front(deque, strdup(buffer));
                printf("push_front %s\n", buffer);
                break;
            case 4:
            case 5:
                if (deque_size(deque) > 0) {
                    char *str = deque_pop_back(deque);
                    printf("pop_back %s\n", str);
                    free(str);
                } else {
                    i--;
                }
                break;
            case 6:
            case 7:
                if (deque_size(deque) > 0) {
                    char *str = deque_pop_front(deque);
                    printf("pop_front %s\n", str);
                    free(str);
                } else {
                    i--;
                }
                break;
            case 8:
                if (deque_size(deque) > 0) {
                    char *str = deque_peek_front(deque);
                    printf("peek_front %s\n", str);
                } else {
                    i--;
                }
                break;
            case 9:
                if (deque_size(deque) > 0) {
                    char *str = deque_peek_back(deque);
                    printf("peek_back %s\n", str);
                } else {
                    i--;
                }
                break;
            default:
                assert(0);
        }

        if (i % 10 == 0) {
            int size = deque_size(deque);
            printf("deq_size %d\n", size);
            int capacity = deque_capacity(deque);
            printf("deq_capacity %d\n", capacity);
        }
    }
    return 1;
}

int main(int argc, char **argv) {
    if (argc > 2) {
        srandom(time(NULL));
        generate_deque_test(myatoi(argv[1]));
        exit(0);
    }
    printf("Instantiating deque\n");
    deque_t deque = deque_new(4);
    assert(deque != NULL);

    printf("Commencing tests\n");
    char operation[100];
    for (int i = 1; scanf("%99s", operation) == 1 && strcmp(operation, "done") != 0; i++) {
        char buffer2[1000];
        if (scanf("%999s", buffer2) < 1) {
            printf("Input error, expecting argument.\n");
            return 1;
        }

        if (strcmp(operation, "push_front") == 0) {
            char *arg1 = strdup(buffer2);
            check_bool(deque_push_front(deque, arg1), operation, i);
        } else if (strcmp(operation, "pop_front") == 0) {
            check_string(deque_pop_front(deque), buffer2, operation, i, 1);
        } else if (strcmp(operation, "peek_front") == 0) {
            check_string(deque_peek_front(deque), buffer2, operation, i, 0);
        } else if (strcmp(operation, "push_back") == 0) {
            char *arg1 = strdup(buffer2);
            check_bool(deque_push_back(deque, arg1), operation, i);
        } else if (strcmp(operation, "pop_back") == 0) {
            check_string(deque_pop_back(deque), buffer2, operation, i, 1);
        } else if (strcmp(operation, "peek_back") == 0) {
            check_string(deque_peek_back(deque), buffer2, operation, i, 0);
        } else if (strcmp(operation, "deq_size") == 0) {
            check_int(deque_size(deque), myatoi(buffer2), operation, i);
        } else if (strcmp(operation, "deq_capacity") == 0) {
            check_int(deque_capacity(deque), myatoi(buffer2), operation, i);
        } else {
            printf("Unknown operation: %s\n", operation);
        }
    }

    printf("Done\n");
    deque_free(deque);
    exit(0);
}
