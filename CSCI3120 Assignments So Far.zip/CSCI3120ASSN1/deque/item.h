//
// Created by Alex Brodsky on 2026-03-24.
//

#ifndef MEDS_ITEM_H
#define MEDS_ITEM_H

/**
 * @typedef item_t
 * @brief Represents a piece of data paired with its size.
 *
 * The `item_t` type is used to encapsulate arbitrary data,
 * providing a pointer to the data and the size of the data in bytes.
 * It is typically used in hashing and key-value mapping operations
 * where data needs to be managed in a uniform and flexible way.
 *
 * @struct item
 * @var item::data
 * Pointer to the location of the data. The data can represent any type of
 * object or buffer.
 *
 * @var item::size
 * The size of the data in bytes. This value is used for memory operations
 * such as key comparison or data hashing to ensure correctness.
 *
 * Use cases:
 * - Storing keys and values in hash tables.
 * - Comparing and hashing data efficiently.
 */
typedef struct item {
    void *data;
    int size;
} item_t;

#endif //MEDS_ITEM_H