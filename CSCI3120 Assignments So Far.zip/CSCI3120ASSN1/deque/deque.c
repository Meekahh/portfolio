//
// Created by Alex Brodsky on 2026-05-01.
//

#include "deque.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>

struct deque {
    int head;
    int back;
    int max;
    void **items;
};


deque_t deque_new(int capacity) {
    assert(capacity > 0);
    deque_t deque= calloc(1, sizeof(struct deque));
    deque->head = 0;
    deque->back = 0;
    deque->max = capacity;
    deque->items = calloc(capacity, sizeof(void *));
    return deque;
}


void deque_free(deque_t deque) {
    assert(deque);
    free(deque->items);
    free(deque);
}


int deque_size(deque_t deque) {
    assert(deque);
    int count = 0;
    for (int i = 0; i < deque->max; i++) {
        if (deque->items[i] != NULL) {
            count++;
        }
    }
    return count;
}

static void deque_double_size(deque_t deque) {
    void **new_items = calloc(deque->max * 2, sizeof(void *));

    for (int i = 0; i < deque_size(deque); i++) {
        new_items[i] = deque->items[deque->head];
        deque->head = (deque->head+ 1) % deque->max;
    }

    free(deque->items); // not using free_deque() so i can just reuse the same deque w/ new items

    deque->items = new_items;
    deque->max = deque->max * 2;
    deque->head = 0;
    deque->back = deque_size(deque);
}


int deque_capacity(deque_t deque) {
    assert(deque);
    return deque->max;
}


int deque_push_front(deque_t deque, void *data) {
    assert(deque);
    assert(data);

    if (deque_size(deque) == deque->max) {
        deque_double_size(deque);
    }

    deque->head = (deque->head - 1 + deque->max) % deque->max;
    deque->items[deque->head] = data;

    return 1;
}

void * deque_pop_front(deque_t deque) {
    assert(deque);
    void *data = deque->items[deque->head];
    deque->items[deque->head] = 0;
    deque->head = (deque->head + 1) % deque->max;

    return data;
}

void * deque_peek_front(deque_t deque) {
    assert(deque);

    return deque->items[deque->head];
}

int deque_push_back(deque_t deque, void *data) {
    assert(deque);
    assert(data);

    if (deque_size(deque) == deque->max) {
        deque_double_size(deque);
    }

    deque->items[deque->back] = data;
    deque->back = (deque->back + 1) % deque->max;

    return 1;
}

void * deque_pop_back(deque_t deque) {
    assert(deque);

    deque->back = (deque->back - 1 + deque->max) % deque->max;
    void *data = deque->items[deque->back];
    deque->items[deque->back] = 0;

    return data;
}

void * deque_peek_back(deque_t deque) {
    assert(deque);
    int last_used_spot = (deque->back - 1 + deque->max) % deque->max;
    return deque->items[last_used_spot];
}
