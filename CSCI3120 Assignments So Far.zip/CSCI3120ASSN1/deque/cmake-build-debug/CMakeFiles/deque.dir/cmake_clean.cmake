file(REMOVE_RECURSE
  "CMakeFiles/deque.dir/deque.c.o"
  "CMakeFiles/deque.dir/deque.c.o.d"
  "CMakeFiles/deque.dir/main.c.o"
  "CMakeFiles/deque.dir/main.c.o.d"
  "deque"
  "deque.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/deque.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
