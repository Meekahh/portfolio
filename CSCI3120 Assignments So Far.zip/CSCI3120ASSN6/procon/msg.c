    //
    // Created by Alex Brodsky on 2026-10-19.
    //


    // YOUR CODE HERE (you will need some static variables and structs

    #include <pthread.h>
    #include <stdio.h>
    #include <stdlib.h>
#include <string.h>

#include "deque.h"

    struct thread_info {
        deque_t deque;
        pthread_mutex_t mutex;
        pthread_cond_t cond;
        pthread_t thread;
    };
    typedef struct thread_info *thread_info_t;

    struct message {
        pthread_t thread;
        void* message;
        int length;
    };
    typedef struct message *message_t;

    static pthread_mutex_t big_lock = PTHREAD_MUTEX_INITIALIZER;

    static thread_info_t used_ids[100];
    static int id_count = 0;

    static thread_info_t thread_info_new(pthread_t thread) {
        if (id_count >= 100) {
            fprintf(stderr, "Error: too many threads\n");
            exit(1);
        }
        for (int i = 0; i < id_count; i++) {
            if (pthread_equal(thread, used_ids[i]->thread)) {
                fprintf(stderr, "Error: thread already registered\n");
                exit(1);
            }
        }
        thread_info_t thread_info = calloc(1, sizeof(struct thread_info));
        if (thread_info == NULL) {
            fprintf(stderr, "Error: calloc failed\n");
            exit(1);
        }

        thread_info->thread = thread;

        deque_t queue = deque_new(4);
        if (queue == NULL) {
            fprintf(stderr, "Error: deque creation failed\n");
            exit(1);
        }
        thread_info->deque = queue;

        pthread_mutex_init(&thread_info->mutex, NULL);
        pthread_cond_init(&thread_info->cond, NULL);

        return thread_info;
    }

    extern void msg_register(void) {
        pthread_t self = pthread_self();

        pthread_mutex_lock(&big_lock); // !
        used_ids[id_count] = thread_info_new(self);
        id_count++;
        pthread_mutex_unlock(&big_lock); // !
    }

    extern void msg_send(pthread_t dst, const void *msg, int len) {
        if (len < 0) {
            fprintf(stderr, "Error: Message length negative\n");
            exit(1);
        }

        pthread_mutex_lock(&big_lock); // !
        thread_info_t dst_info = 0;
        for (int i = 0; i < id_count; i++) {
            if (pthread_equal(dst, used_ids[i]->thread)) {
                dst_info = used_ids[i];
                break;
            }
        }

        if (dst_info == 0) {
            fprintf(stderr, "Error: destination thread not registered\n");
            exit(1);
        }
        pthread_mutex_unlock(&big_lock); // !

        void* buffer = malloc(len);
        if (len != 0) {
            if (buffer == NULL) {
                fprintf(stderr, "Error: malloc failed\n");
                exit(1);
            }
        }
        if (len > 0) {
            memcpy(buffer, msg, len);
        }

        message_t message = calloc(1, sizeof(struct message));
        if (message == NULL) {
            fprintf(stderr, "Error: calloc failed\n");
            exit(1);
        }
        message->thread = pthread_self();
        message->message = buffer;
        message->length = len;
        pthread_mutex_lock(&dst_info->mutex);
        deque_push_back(dst_info->deque, message);
        pthread_cond_signal(&dst_info->cond);
        pthread_mutex_unlock(&dst_info->mutex);
    }

    extern int msg_recv_any(pthread_t *src, void *msg, int len) {
        if (len < 0) {
            fprintf(stderr, "Error: Message length negative\n");
            exit(1);
        }

        pthread_mutex_lock(&big_lock); // !
        thread_info_t self_info = 0;
        for (int i = 0; i < id_count; i++) {
            if (pthread_equal(pthread_self(), used_ids[i]->thread)) {
                self_info = used_ids[i];
                break;
            }
        }

        if (self_info == 0) {
            fprintf(stderr, "Error: calling thread not registered\n");
            exit(1);
        }
        pthread_mutex_unlock(&big_lock); // !

        message_t received = 0;
        pthread_mutex_lock(&self_info->mutex);
        while (deque_size(self_info->deque) == 0) {
            pthread_cond_wait(&self_info->cond, &self_info->mutex);
        }

        received = deque_pop_front(self_info->deque);
        pthread_mutex_unlock(&self_info->mutex);

        int msg_length = len;
        if (len > received->length) {
            msg_length = received->length;
        }

        if (msg_length > 0) {
            memcpy(msg, received->message, msg_length);
        }

        *src = received->thread;

        free(received->message);
        free(received);

        return msg_length;
    }
