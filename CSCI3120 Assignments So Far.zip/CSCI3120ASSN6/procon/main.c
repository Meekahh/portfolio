#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "support.h"
#include "msg.h"

static volatile int consumer_ready;
static volatile int producer_ready;

static void *producer(void *arg) {
    msg_register();
    producer_ready = 1;
    while (!consumer_ready);

    for (int done = 0; !done;) {
        struct msg *msg = make(&done);
        msg_send(consumer_thread, msg, sizeof(struct msg));
    }
    return NULL;
}

static void *consumer(void *arg) {
    msg_register();
    consumer_ready = 1;
    while (!producer_ready);

    for (int done = 0; !done;) {
        struct msg msg;
        pthread_t src;
        int len = msg_recv_any(&src, &msg, sizeof(struct msg));
        assert(len == sizeof(struct msg));
        assert(src == producer_thread);

        use(&msg, &done);
    }
    return NULL;
}

int main(void) {
    pthread_create(&consumer_thread, NULL, consumer, NULL);
    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);
    return 0;
}
