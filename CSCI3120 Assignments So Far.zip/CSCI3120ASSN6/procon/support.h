//
// Created by Alex Brodsky on 2026-09-22.
//

#ifndef PROCON_SUPPORT_H
#define PROCON_SUPPORT_H


struct msg {
    char buffer[100];
    int num;
};

extern pthread_t producer_thread;
extern pthread_t consumer_thread;

struct msg *make(int *done);
void use(struct msg *mst, int *done);

#endif //PROCON_SUPPORT_H
