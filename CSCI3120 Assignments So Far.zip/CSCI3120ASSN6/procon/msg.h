//
// Created by Alex Brodsky on 2026-10-19.
//

#ifndef PROCON_MSG_H
#define PROCON_MSG_H

#include <pthread.h>

/**
 * @file msg.h
 * @brief Simple inter-thread message passing.
 *
 * Each participating thread owns a mailbox.  Threads send byte messages to
 * one another's mailboxes, and each thread receives from its own mailbox.
 * Up to 100 threads may be registered.  Any fatal error (allocation
 * failure, pthread failure, too many threads, unknown thread) prints a
 * message and terminates the process.
 */

/**
 * @brief Register the calling thread so it can send and receive messages.
 *
 * Allocates and initializes a mailbox for the calling thread.  Must be
 * called exactly once by each thread, before it calls msg_recv_any() and
 * before any other thread sends to it.  Registering the same thread twice
 * is a fatal error.  This function is thread-safe.
 */
extern void msg_register(void);

/**
 * @brief Send a message to a thread's mailbox.
 *
 * Does not block (other than briefly acquiring the mailbox lock).  If the
 * destination thread is currently blocked in msg_recv_any(), the message is
 * copied directly into its buffer (truncated to the buffer size) and the
 * thread is woken.  Otherwise, a copy of the message is queued in the
 * destination's mailbox, so the caller may reuse @p msg immediately.
 *
 * @param dst The destination thread; must have been registered with
 *            msg_register().
 * @param msg Pointer to the message bytes; must not be NULL.
 * @param len Number of bytes in the message; must be >= 0.
 */
extern void msg_send(pthread_t dst, const void *msg, int len);

/**
 * @brief Receive the next message from the calling thread's mailbox.
 *
 * If one or more messages are queued, the oldest is removed and copied into
 * @p msg.  Otherwise, the caller blocks until another thread sends it a
 * message.  Messages longer than @p len are truncated to @p len bytes.
 * The calling thread must have been registered with msg_register().
 *
 * @param src Output: set to the sending thread's ID.
 * @param msg Buffer into which the message is copied; must not be NULL.
 * @param len Size of @p msg in bytes; must be >= 0.
 * @return The number of bytes copied into @p msg, i.e., the smaller of
 *         @p len and the length of the message sent.
 */
extern int msg_recv_any(pthread_t *src, void *msg, int len);

#endif //PROCON_MSG_H
