//
// Created by Alex Brodsky on 2026-09-22.
//

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include "support.h"

pthread_t producer_thread;
pthread_t consumer_thread;

struct msg *make(int *done) {
    if (pthread_self() != producer_thread) {
        printf("Oops, this function should only be called by the producer thread\n");
        exit(1);
    }

    struct msg *msg = calloc(1, sizeof(struct msg));
    if (msg == NULL) {
        perror("Failed to allocate memory for message");
        exit(1);
    }

    if (scanf("%s %d", msg->buffer, &msg->num) != 2) {
        perror("Failed to read input");
        exit(1);
    }

    if (strcmp(msg->buffer, "done") == 0) {
        *done = 1;
    } else if (strcmp(msg->buffer, "producer_sleep") == 0) {
        struct timespec t = {0};
        long ns = msg->num * 1000000;
        t.tv_nsec =  ns % 1000000000;
        t.tv_sec = ns / 1000000000;
        if (nanosleep(&t, NULL)) {
            perror("Failed to sleep producer");
        }
    }
    return msg;
}

void use(struct msg *msg, int *done) {
    if (pthread_self() != consumer_thread) {
        printf("Oops, this function should only be called by the consumer thread\n");
        exit(1);
    }

    printf("Received: %s %d\n", msg->buffer, msg->num);

    if (strcmp(msg->buffer, "done") == 0) {
        *done = 1;
    } else if (strcmp(msg->buffer, "consumer_sleep") == 0) {
        struct timespec t = {0};
        long ns = msg->num * 1000000;
        t.tv_nsec =  ns % 1000000000;
        t.tv_sec = ns / 1000000000;
        if (nanosleep(&t, NULL)) {
            perror("Failed to sleep consumer");
        }
    }
}
