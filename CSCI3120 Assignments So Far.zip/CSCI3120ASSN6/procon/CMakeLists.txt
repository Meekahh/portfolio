cmake_minimum_required(VERSION 3.25)
project(procon C)

set(CMAKE_C_STANDARD 99)

add_executable(procon main.c support.c support.h msg.c msg.h deque.h deque.c)
