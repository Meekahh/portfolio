#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "heap.h"

typedef struct heap_chunk {   // Notes for me :)
   void *address;              // Where it starts
   unsigned size;              // Chunk size afterwards
   struct heap_chunk *next;
} heap_chunk_t;

static heap_chunk_t *free_list = NULL;
static heap_chunk_t *allocated_list = NULL;

extern void heap_init(void *new_base, unsigned new_limit) {
      // Error checks
   if (new_limit <= 128) { fprintf(stderr, "heap_init: new_limit must be greater than 128\n"); exit(1); }
   if (new_base == NULL) { fprintf(stderr, "heap_init: new_base is NULL\n"); exit(1); }

   heap_chunk_t *heap_head = malloc(sizeof(heap_chunk_t));
   if (heap_head == NULL) { fprintf(stderr, "heap_init: malloc failed\n"); exit(1); }

   heap_head->address = new_base;
   heap_head->size = new_limit;
   heap_head->next = NULL;

   free_list = heap_head;
   allocated_list = NULL;
}

extern void * heap_alloc(unsigned size) {
   if (size == 0 || free_list == NULL) { return NULL; }

   heap_chunk_t *claimed_chunk = NULL;
   heap_chunk_t *previous_chunk = NULL;     // node before iterator
   heap_chunk_t *prev_to_claimed = NULL;    // node before claimed_chunk
   heap_chunk_t *iterator = free_list;

      // Check the free list for the closest size match
   while (iterator != NULL) {
      if (iterator->size >= size && (claimed_chunk == NULL || iterator->size < claimed_chunk->size)) {
         prev_to_claimed = previous_chunk;
         claimed_chunk = iterator;
      }
      previous_chunk = iterator;
      iterator = iterator->next;
   }

   if (claimed_chunk == NULL) { return NULL; }    // nothing big enough

   heap_chunk_t *allocated_chunk;
   void *result = claimed_chunk->address;

   if (claimed_chunk->size == size) {
         // if the size fits exactly then just move the whole thing
      if (prev_to_claimed == NULL) {
         free_list = claimed_chunk->next;
      } else {
         prev_to_claimed->next = claimed_chunk->next;
      }
      allocated_chunk = claimed_chunk;

   } else {
         // If not an exact fit then split it up
      allocated_chunk = malloc(sizeof(heap_chunk_t));
      if (allocated_chunk == NULL) { return NULL; }
      allocated_chunk->address = claimed_chunk->address;
      allocated_chunk->size = size;

      claimed_chunk->address = claimed_chunk->address + size;
      claimed_chunk->size -= size;
   }

      // Add to the end of the allocated list
   allocated_chunk->next = NULL;
   if (allocated_list == NULL) {
      allocated_list = allocated_chunk;
   } else {
      iterator = allocated_list;
      while (iterator->next != NULL) {
         iterator = iterator->next;
      }
      iterator->next = allocated_chunk;
   }

   return result;
}

extern int heap_free(void *address) {
   if (address == NULL) { return 0; }

   heap_chunk_t *previous_chunk = NULL;
   heap_chunk_t *iterator = allocated_list;

      // Iterate through the allocation list to find the chunk
   while (iterator != NULL && iterator->address != address) {
      previous_chunk = iterator;
      iterator = iterator->next;
   }

   heap_chunk_t *freed_chunk = iterator;

      // Remove it from the list
   if (previous_chunk == NULL) {
      allocated_list = freed_chunk->next;
   } else {
      previous_chunk->next = freed_chunk->next;
   }

      // Insert it into the free list in order of the addresses
   previous_chunk = NULL;
   iterator = free_list;
   while (iterator != NULL && iterator->address < freed_chunk->address) {
      previous_chunk = iterator;
      iterator = iterator->next;
   }

   freed_chunk->next = iterator;
   if (previous_chunk == NULL) {
      free_list = freed_chunk;
   } else {
      previous_chunk->next = freed_chunk;
   }

      // Combine it with the next chunk if they're touching
   if (iterator != NULL && freed_chunk->address + freed_chunk->size == iterator->address) {
      freed_chunk->size += iterator->size;
      freed_chunk->next = iterator->next;
      free(iterator);
   }

      // Or with the previous chunk
   if (previous_chunk != NULL && previous_chunk->address + previous_chunk->size == freed_chunk->address) {
      previous_chunk->size += freed_chunk->size;
      previous_chunk->next = freed_chunk->next;
      free(freed_chunk);
   }

   return 1;
}