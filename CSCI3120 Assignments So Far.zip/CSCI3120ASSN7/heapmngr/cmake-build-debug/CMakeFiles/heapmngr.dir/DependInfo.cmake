
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/users/cs/mika/tmp/tmp.K7HRoOKaMK/heapmngr/heap.c" "CMakeFiles/heapmngr.dir/heap.c.o" "gcc" "CMakeFiles/heapmngr.dir/heap.c.o.d"
  "/users/cs/mika/tmp/tmp.K7HRoOKaMK/heapmngr/main.c" "CMakeFiles/heapmngr.dir/main.c.o" "gcc" "CMakeFiles/heapmngr.dir/main.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
