# Empty compiler generated dependencies file for heapmngr.
# This may be replaced when dependencies are built.
