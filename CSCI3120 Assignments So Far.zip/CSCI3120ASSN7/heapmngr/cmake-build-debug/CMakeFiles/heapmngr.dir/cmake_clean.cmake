file(REMOVE_RECURSE
  "CMakeFiles/heapmngr.dir/heap.c.o"
  "CMakeFiles/heapmngr.dir/heap.c.o.d"
  "CMakeFiles/heapmngr.dir/main.c.o"
  "CMakeFiles/heapmngr.dir/main.c.o.d"
  "heapmngr"
  "heapmngr.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/heapmngr.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
