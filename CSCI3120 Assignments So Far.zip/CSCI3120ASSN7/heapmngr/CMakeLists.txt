cmake_minimum_required(VERSION 3.25)
project(heapmngr C)

set(CMAKE_C_STANDARD 99)

add_executable(heapmngr main.c request.h heap.c heap.h)
