//
// Created by Alex Brodsky on 2026-05-25.
//

#ifndef STORAGE_REQUEST_H
#define STORAGE_REQUEST_H

/**
 * @brief Type of operation a request performs on the backend store.
 *
 * Identifies which action the backend should execute when processing a request.
 */
enum request_action {
    REQUEST_ALLOC,    /**< Store (insert or update) a key/value pair. */
    REQUEST_FREE, /**< Remove the key/value pair associated with a key. */
};

/**
 * @brief Represents a single client request handled by the scheduler and backend.
 *
 * A request_t captures the operation to be performed, its inputs and outputs,
 * its scheduling priority, and timing information used to measure how the
 * request progresses through the system.
 */
typedef struct request {
    enum request_action action;       /**< Operation to perform (PUT, GET, or REMOVE). */
    unsigned tag;                     /**< Tag` associated with the request. */
    int size;                         /**< Size of the data associated with the request. */
    void *data;                       /**< Data associated with the request (used by GET; populated by PUT). */
} request_t;

#endif //STORAGE_REQUEST_H
