/**
 * @file storage.h
 * @brief Thread-safe dynamic storage allocator backed by a backstore region.
 *
 * Provides a best-fit allocator that manages a single @c memory region.
 * Allocated blocks are tracked in an ordered allocation list; freed blocks are
 * coalesced with adjacent free regions and returned to the free list.
 *
 * Typical usage:
 * @code
 *   heap_init(void *base, unsigned limit);
 *
 *   void *addr = heap_alloc(unsigned size);   // allocate
 *   ...
 *   heap_free(addr);                          // free
 * @endcode
 *
 * Created by Alex Brodsky on 2026-07-14.
 */

#ifndef HEAP_H
#define HEAP_H

/**
 * @brief Initialise the heap manager over an existing memory region.
 *
 * Must be called exactly once before any other heap function.  The entire
 * memory region is placed on the free list as a single contiguous region.
 * Calling this function a second time without an intervening clean-up results
 * in undefined behaviour.
 *
 * @param base    A pointer to the start of the memory region.  Must not be @c NULL.
 * @param limit   The size of the memory region in bytes.  Must be greater than the
 *                internal block record overhead (128 bytes).
 *
 */
extern void heap_init(void *base, unsigned limit);

/**
 * @brief Allocate space in the memory region and return a pointer to it.
 *
 * Selects the smallest free block that is at least @p size bytes (best-fit
 * strategy).  If the chosen free block is larger than @p size, the
 * remainder is kept on the free list.
 *
 * @param size  Number of bytes to allocate.  Must be greater than 0.
 * @return      The pointer to allocated memory, or @c  NULLif no free block
 *              large enough exists.
 */
extern void *heap_alloc(unsigned size);


/**
 * @brief Free an allocated region.
 *
 * Removes the block at [@p address) from the allocation
 * list and returns it to the free list.  Adjacent free regions are coalesced
 * automatically.  Both @p offset and @p size must match exactly the values
 * used in the corresponding @c storage_put call.
 *
 * @param address Address of the block to free, as returned by
 *                @c heap_alloc.  Must not be NULL.
 * @return        1 if the free succeeded and 0 on failure.
 */
extern int heap_free(void *address);

#endif //HEAP_H
