#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#include "request.h"
#include "heap.h"

#define PACKET_SIZE 1500

static int my_atoi(char *str) {
    long value = strtol(str, NULL, 10);
    if (value == 0 && errno == EINVAL) {
        printf("Invalid integer value in test script: %s", str);
        exit(1);
    }
    return (int)value;
}


static void generate_tests(int reqs, int limit) {
    assert(reqs > 0);

    unsigned tag = 0;
    unsigned int n = 0;

    request_t *requests = calloc(reqs, sizeof(request_t));
    if (requests == NULL) {
        perror("calloc in generate_tests");
        exit(1);
    }

    printf("%u %u\n", reqs, limit);

    for (int i = 0; i < reqs; i++) {
        unsigned long r = (unsigned long)random();
        if (n < 5 || r & 1) {
            requests[n].action = REQUEST_ALLOC;
            requests[n].tag = tag;
            tag++;
            requests[n].size = 128;
            for (r >>= 1; r & 1; r >>= 1) {
                requests[n].size = (requests[n].size << 1) + requests[n].size;
            }
            printf("alloc %u %u\n", requests[n].tag, requests[n].size);
            n++;
        } else {
            unsigned j = r % n;
            printf("free %u\n", requests[j].tag);
            requests[j] = requests[n - 1];
            n--;
        }
    }
}


static request_t *load_test_file(unsigned *num_requests, unsigned *store_size, unsigned *max_tag) {
    if (scanf("%d %d", num_requests, store_size) != 2) {
        printf("Input error, expecting three integers: N S\n");
        printf("  N: number of requests\n");
        printf("  S: size of backstore\n");
        exit(1);
    }

    request_t *requests = calloc(*num_requests, sizeof(request_t));
    if (requests == NULL) {
        perror("calloc(requests)");
        exit(1);
    }

    *max_tag = 0;
    for (int i = 0; i < *num_requests; i++) {
        char operation[10];

        if (scanf("%9s %u", operation, &requests[i].tag) != 2) {
            printf("Input error, operation and tag expected at line %d\n", i);
            exit(1);
        }

        if (*max_tag < requests[i].tag) {
            *max_tag = requests[i].tag;
        }

        if (!strcmp(operation, "alloc")) {
            if (scanf("%d", &requests[i].size) != 1) {
                printf("Input error, size expected at line %d\n", i);
                exit(1);
            }
            requests[i].action = REQUEST_ALLOC;
        } else if (!strcmp(operation, "free")) {
            requests[i].action = REQUEST_FREE;
        } else {
            printf("Unknown operation: %s\n", operation);
            exit(1);
        }
    }
    return requests;
}

int main(int argc, char **argv) {
    if (argc > 2) {
        srandom(time(NULL));
        generate_tests(my_atoi(argv[1]), my_atoi(argv[2]));
        exit(0);
    }

    unsigned num_requests;
    unsigned heap_size;
    unsigned max_tag;
    request_t *requests = load_test_file(&num_requests, &heap_size, &max_tag);
    request_t **allocated = calloc(max_tag + 1, sizeof(request_t *));
    if (allocated == NULL) {
        perror("calloc in main: allocated");
        exit(1);
    }


    void *memory = malloc(heap_size);
    if (memory == NULL) {
        perror("malloc in main: memory");
        exit(1);
    }
    heap_init(memory, heap_size);

    for (int i = 0; i < num_requests; i++) {
        unsigned tag = requests[i].tag;
        switch (requests[i].action) {
        case REQUEST_ALLOC:
                assert(allocated[tag] == NULL);
                assert(requests[i].size > 0);
                allocated[tag] = &requests[i];
                assert(requests[i].size > 0);
                requests[i].data = heap_alloc(requests[i].size);
                if (requests[i].data != NULL) {
                    printf("Allocated %d bytes on request %d on line %d\n", requests[i].size, tag, i + 1);
                } else {
                    printf("Failed to allocate %d bytes on request %d on line %d\n", requests[i].size, tag, i + 1);
                    exit(1);
                }

                for (int j = 0; j < max_tag; j++) {
                    if (allocated[j] != NULL && j != tag) {
                        request_t *other = allocated[j];
                        if (other->data + other->size > requests[i].data &&
                            requests[i].data + requests[i].size > other->data) {
                            printf("Memory overlap detected: ");
                            printf("  allocated memory [%lx %lx] allocated on tag %d overlaps with\n",
                                (unsigned long)other->data, (unsigned long)other->data + other->size, j);
                            printf("  allocated memory [%lx %lx] allocated on tag %d on line %d\n",
                                (unsigned long)requests[i].data, (unsigned long)requests[i].data + requests[i].size, tag, i + 1);
                            exit(1);
                        }
                    }
                }

                for (int j = 0; j < requests[i].size; j += sizeof(void *)) {
                    int len = requests[i].size - j >= sizeof(void *) ? sizeof(void *) : requests[i].size - j;
                    memcpy((void *)((char *)requests[i].data + j), &requests[i].data, len);
                }
                break;
        case REQUEST_FREE:
                assert(allocated[tag] != NULL);
                for (int j = 0; j < allocated[tag]->size; j += sizeof(void *)) {
                    int len = allocated[tag]->size - j >= sizeof(void *) ? sizeof(void *) : allocated[tag]->size - j;
                    if (memcmp((void *)((char *)allocated[tag]->data + j), &allocated[tag]->data, len) != 0) {
                        printf("Memory corruption detected at address %lx on request %d on line %d\n", (unsigned long)(requests[i].data + j), tag, i + 1);
                        exit(1);
                    }
                }
                if (!heap_free(allocated[tag]->data)) {
                    printf("Failed to free %d bytes on request %d on line %d\n", requests[i].size, tag, i + 1);
                    exit(1);
                }
                printf("Freed %d bytes on request %d on line %d\n", allocated[tag]->size, tag, i + 1);
                allocated[tag] = NULL;
                break;
        default:
            printf("Invalid operation: %d\n", requests[i].action);
            exit(1);
        }
    }

    free(memory);
    free(allocated);
    free(requests);
    exit(0);
}