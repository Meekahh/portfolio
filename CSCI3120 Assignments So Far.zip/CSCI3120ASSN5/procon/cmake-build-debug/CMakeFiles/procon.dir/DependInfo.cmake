
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/users/cs/mika/tmp/tmp.VTHtv4Ied2/procon/main.c" "CMakeFiles/procon.dir/main.c.o" "gcc" "CMakeFiles/procon.dir/main.c.o.d"
  "/users/cs/mika/tmp/tmp.VTHtv4Ied2/procon/mtdeque.c" "CMakeFiles/procon.dir/mtdeque.c.o" "gcc" "CMakeFiles/procon.dir/mtdeque.c.o.d"
  "/users/cs/mika/tmp/tmp.VTHtv4Ied2/procon/support.c" "CMakeFiles/procon.dir/support.c.o" "gcc" "CMakeFiles/procon.dir/support.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
