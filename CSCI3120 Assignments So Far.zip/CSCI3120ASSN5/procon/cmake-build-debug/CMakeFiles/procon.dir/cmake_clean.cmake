file(REMOVE_RECURSE
  "CMakeFiles/procon.dir/main.c.o"
  "CMakeFiles/procon.dir/main.c.o.d"
  "CMakeFiles/procon.dir/mtdeque.c.o"
  "CMakeFiles/procon.dir/mtdeque.c.o.d"
  "CMakeFiles/procon.dir/support.c.o"
  "CMakeFiles/procon.dir/support.c.o.d"
  "procon"
  "procon.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/procon.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
