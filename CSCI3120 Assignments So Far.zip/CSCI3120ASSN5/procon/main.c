#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "support.h"
#include "mtdeque.h"

// This queue is thread-safe.
static mt_deque_t queue;


void *producer(void *arg) {
    for (int done = 0; !done;) {
        struct msg *msg = make(&done);

        if (!mt_deque_push_back(queue, msg)) {
            perror("Failed to push message to deque");
            exit(1);
        }
    }
    return NULL;
}

void *consumer(void *arg) {
    for (int done = 0; !done;) {
        struct msg *msg;

        msg = mt_deque_pop_front(queue);
        if (msg == NULL) {
            perror("Failed to pop message from deque");
            exit(1);
        }

        use(msg, &done);
    }
    return NULL;
}

int main(void) {
    queue = mt_deque_new(4);
    if (queue == NULL) {
        perror("Failed to create deque");
        exit(1);
    }

    // YOUR CODE HERE
    // 1. Create two threads, storing the thread IDs in the global variables
    //    - producer_thread for the producer
    //    - consumer_thread for the consumer
    // 2. Join the threads before exiting
    // SOLUTION START
    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);
    // SOLUTION END
    return 0;
}
