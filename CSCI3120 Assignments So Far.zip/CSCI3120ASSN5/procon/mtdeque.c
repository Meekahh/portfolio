#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

#include "mtdeque.h"

struct mt_deque {
    int head;
    int back;
    int e_count;   // count of e(lements) in the deque
    int max;
    void **items;
    pthread_mutex_t lock;
    pthread_cond_t isnt_empty;
};


mt_deque_t mt_deque_new(int capacity) {
    assert(capacity > 0);

    mt_deque_t deque = calloc(1, sizeof(struct mt_deque));
    if (deque == NULL) {
        return NULL;
    }

    deque->items = calloc(capacity, sizeof(void *));
    pthread_mutex_init(&deque->lock, NULL);
    pthread_cond_init(&deque->isnt_empty, NULL);
    deque->head = 0;
    deque->back = 0;
    deque->e_count = 0;
    deque->max = capacity;
    return deque;
}


void mt_deque_free(mt_deque_t deque) {
    assert(deque);

    free(deque->items);
    free(deque);
}


int mt_deque_size(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    int count = deque->e_count;
    pthread_mutex_unlock(&deque->lock);

    return count;
}

static int mt_deque_double_size(mt_deque_t deque) {
    void **new_items = calloc(deque->max * 2, sizeof(void *));
    if (new_items == NULL) {
        return 0;
    }

    for (int i = 0; i < deque->e_count; i++) {
        new_items[i] = deque->items[(deque->head + i) % deque->max];
    }

    free(deque->items);
    deque->items = new_items;
    deque->max *= 2;
    deque->head = 0;
    deque->back = deque->e_count;
    return 1;
}


int mt_deque_capacity(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    int max = deque->max;
    pthread_mutex_unlock(&deque->lock);

    return max;
}


int mt_deque_push_front(mt_deque_t deque, void *data) {
    assert(deque);
    assert(data);
    pthread_mutex_lock(&deque->lock);

    if (deque->e_count == deque->max) {
        pthread_mutex_unlock(&deque->lock);
        return 0;
    }

    deque->head = (deque->head - 1 + deque->max) % deque->max;
    deque->items[deque->head] = data;
    deque->e_count++;

    pthread_cond_signal(&deque->isnt_empty);
    pthread_mutex_unlock(&deque->lock);
    return 1;
}


void *mt_deque_pop_front(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    while (deque->e_count == 0) {
        pthread_cond_wait(&deque->isnt_empty, &deque->lock);
    }

    void *data = deque->items[deque->head];
    deque->items[deque->head] = NULL;
    deque->head = (deque->head + 1) % deque->max;
    deque->e_count--;

    pthread_mutex_unlock(&deque->lock);
    return data;
}


void *mt_deque_peek_front(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    void *data = (deque->e_count == 0) ? NULL : deque->items[deque->head];

    pthread_mutex_unlock(&deque->lock);
    return data;
}


int mt_deque_push_back(mt_deque_t deque, void *data) {
    assert(deque);
    assert(data);
    pthread_mutex_lock(&deque->lock);

    if (deque->e_count == deque->max && !mt_deque_double_size(deque)) {
        pthread_mutex_unlock(&deque->lock);
        return 0;
    }

    deque->items[deque->back] = data;
    deque->back = (deque->back + 1) % deque->max;
    deque->e_count++;

    pthread_cond_signal(&deque->isnt_empty);
    pthread_mutex_unlock(&deque->lock);
    return 1;
}


void *mt_deque_pop_back(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    while (deque->e_count == 0) {
        pthread_cond_wait(&deque->isnt_empty, &deque->lock);
    }

    deque->back = (deque->back - 1 + deque->max) % deque->max;
    void *data = deque->items[deque->back];
    deque->items[deque->back] = NULL;
    deque->e_count--;

    pthread_mutex_unlock(&deque->lock);
    return data;
}


void *mt_deque_peek_back(mt_deque_t deque) {
    assert(deque);
    pthread_mutex_lock(&deque->lock);

    void *data = NULL;
    if (deque->e_count > 0) {
        data = deque->items[(deque->back - 1 + deque->max) % deque->max];
    }

    pthread_mutex_unlock(&deque->lock);
    return data;
}