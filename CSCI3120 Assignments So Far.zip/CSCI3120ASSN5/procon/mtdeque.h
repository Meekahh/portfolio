//
// Created by Alex Brodsky on 2026-03-23.
//

/* This is a multi-threaded deque implementation.  All functions are threadsafe.
 * The pop functions block the calling thread if the deque is empty.
 */

#ifndef MT_DEQUE_H
#define MT_DEQUE_H

typedef struct mt_deque *mt_deque_t;

/**
 * Creates a new deque with the specified initial capacity.
 *
 * @param capacity The desired initial capacity of the deque.
 * @return A newly allocated deque handle on success, or NULL if allocation fails.
 */
mt_deque_t mt_deque_new(int capacity);

/**
 * Frees a deque and all resources owned by it.
 *
 * @param deque The deque to free. May not be NULL.
 * @return None.
 */
void mt_deque_free(mt_deque_t deque);

/**
 * Returns the number of elements currently stored in the deque.
 *
 * @param deque The deque to query.  May not be NULL.
 * @return The current number of elements in the deque.
 */
int mt_deque_size(mt_deque_t deque);

/**
 * Returns the current capacity of the deque.
 *
 * @param deque The deque to query.  May not be NULL.
 * @return The maximum number of elements the deque can hold without resizing.
 */
int mt_deque_capacity(mt_deque_t deque);

/**
 * Inserts an element at the front of the deque.
 *
 * If the deque is full, the capacity of the deque is doubled by allocating
 * a new array twice the size of the old array and copying all the items
 * into the new array.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @param data Pointer to the element to insert.
 * @return 1 on success, or a zero value on failure.
 */
int mt_deque_push_front(mt_deque_t deque, void *data);

/**
 * Removes and returns the element at the front of the deque.
 * If the deque is empty, the thread is blocked until an element is available.
 *
 * @param deque The deque to modify. May not be NULL.
 * @return The removed front element.
 */
void *mt_deque_pop_front(mt_deque_t deque);

/**
 * Returns the element at the front of the deque without removing it.
 *
 * @param deque The deque to query. May not be NULL.
 * @return The front element, or NULL if the deque is empty.
 */
void *mt_deque_peek_front(mt_deque_t deque);

/**
 * Inserts an element at the back of the deque.
 *
 * If the deque is full, the capacity of the deque is doubled by allocating
 * a new array twice the size of the old array and copying all the items
 * into the new array.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @param data Pointer to the element to insert.
 * @return 1 on success, or a zero value on failure.
 */
int mt_deque_push_back(mt_deque_t deque, void *data);

/**
 * Removes and returns the element at the back of the deque.
 * If the deque is empty, the thread is blocked until an element is available.
 *
 * @param deque The deque to modify.  May not be NULL.
 * @return The removed back element.
 */
void *mt_deque_pop_back(mt_deque_t deque);

/**
 * Returns the element at the back of the deque without removing it.
 *
 * @param deque The deque to query.    May not be NULL.
 * @return The back element, or NULL if the deque is empty.
 */
void *mt_deque_peek_back(mt_deque_t deque);

#endif //MT_DEQUE_H
