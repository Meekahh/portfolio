#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

int main(int argc, char **argv) {

    if (argc < 3) {
        printf("Minimum 3 arguments required\n");
        return 1;
    }

    int T;
        if (sscanf(argv[1], "%d", &T) != 1) {
            printf("Error with parsing time\n");
            return 1;
        }
        if (T <= 0) {
            printf("Time has to be positive\n");
            return 1;
        }

    char** remainder_args = argv + 2;
    int pid = fork();
    if (pid == 0) { // child
        execv(argv[2], remainder_args);
    }

    if (pid > 0) { // parent
        sleep(T);
        kill(pid, SIGKILL);
    }

    if (pid < 0) { // error
        printf("Process forking failed\n");
        return 1;
    }

}
