file(REMOVE_RECURSE
  "CMakeFiles/timeout.dir/main.c.o"
  "CMakeFiles/timeout.dir/main.c.o.d"
  "timeout"
  "timeout.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/timeout.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
