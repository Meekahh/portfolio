file(REMOVE_RECURSE
  "CMakeFiles/snooze.dir/tests/snooze.c.o"
  "CMakeFiles/snooze.dir/tests/snooze.c.o.d"
  "snooze"
  "snooze.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/snooze.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
