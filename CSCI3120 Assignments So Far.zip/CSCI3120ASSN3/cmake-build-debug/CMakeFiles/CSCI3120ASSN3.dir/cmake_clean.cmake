file(REMOVE_RECURSE
  "CMakeFiles/CSCI3120ASSN3.dir/main.c.o"
  "CMakeFiles/CSCI3120ASSN3.dir/main.c.o.d"
  "CSCI3120ASSN3"
  "CSCI3120ASSN3.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/CSCI3120ASSN3.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
