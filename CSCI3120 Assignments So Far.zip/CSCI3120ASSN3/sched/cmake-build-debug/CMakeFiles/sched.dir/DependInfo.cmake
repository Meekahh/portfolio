
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/users/cs/mika/tmp/tmp.7ksk8S60uL/sched/deque.c" "CMakeFiles/sched.dir/deque.c.o" "gcc" "CMakeFiles/sched.dir/deque.c.o.d"
  "/users/cs/mika/tmp/tmp.7ksk8S60uL/sched/main.c" "CMakeFiles/sched.dir/main.c.o" "gcc" "CMakeFiles/sched.dir/main.c.o.d"
  "/users/cs/mika/tmp/tmp.7ksk8S60uL/sched/prioq.c" "CMakeFiles/sched.dir/prioq.c.o" "gcc" "CMakeFiles/sched.dir/prioq.c.o.d"
  "/users/cs/mika/tmp/tmp.7ksk8S60uL/sched/scheduler.c" "CMakeFiles/sched.dir/scheduler.c.o" "gcc" "CMakeFiles/sched.dir/scheduler.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
