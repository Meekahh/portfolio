file(REMOVE_RECURSE
  "CMakeFiles/sched.dir/deque.c.o"
  "CMakeFiles/sched.dir/deque.c.o.d"
  "CMakeFiles/sched.dir/main.c.o"
  "CMakeFiles/sched.dir/main.c.o.d"
  "CMakeFiles/sched.dir/prioq.c.o"
  "CMakeFiles/sched.dir/prioq.c.o.d"
  "CMakeFiles/sched.dir/scheduler.c.o"
  "CMakeFiles/sched.dir/scheduler.c.o.d"
  "sched"
  "sched.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sched.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
