//
// Created by Alex Brodsky on 2026-05-25.
//

#ifndef SCHED_PCB_H
#define SCHED_PCB_H

/**
 * @brief Represents a process control block.
 *
 * A pcb_t captures the information needed by the scheduler to schedule the process.
 */
typedef struct pcb {
    unsigned priority;
    void *process_info;
} pcb_t;

#endif //SCHED_PCB_H
