cmake_minimum_required(VERSION 3.25)
project(sched C)

set(CMAKE_C_STANDARD 99)

add_executable(sched main.c deque.c deque.h scheduler.c scheduler.h
        pcb.h
        prioq.c
        prioq.h)
