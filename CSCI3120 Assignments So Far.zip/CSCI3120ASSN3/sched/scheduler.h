//
// Created by Alex Brodsky on 2026-05-23.
//

#ifndef SCHED_SCHEDULE_H
#define SCHED_SCHEDULE_H

#include "pcb.h"

/**
 * @brief Initializes the scheduler.
 *
 * Sets up the scheduler with the specified number of queues. Each queue
 * typically corresponds to a distinct priority level. This function must be
 * called before any processes are inserted or retrieved.
 *
 * @param queues The number of queues (priority levels) maintained by the scheduler.
 */
extern void scheduler_init(unsigned int queues);

/**
 * @brief Inserts a process into the scheduler.
 *
 * Places the given process into the appropriate queue based on its priority
 * so that it can be selected later by schedule_next().  The scheduler will use
 * the priority field in the pcb_t.  A lower value means higher priority.
 *
 * @param pcb Pointer to the pcb of the process to be scheduled.
 */
extern void scheduler_insert(pcb_t *pcb);

/**
 * @brief Retrieves the next process to run.
 *
 * This function performs two operations:
 * 1. Ages all queus - the process at the front of each queue is moved to the preceding queue.
 * 2. Selects and removes the next process (highest-priority non-empty queue).  If no process
 * is currently available, NULL is returned.
 *
 * @return Pointer to the pcb of the next process to run, or NULL if none is available.
 */
extern pcb_t * scheduler_next(void);

#endif //SCHED_SCHEDULE_H
