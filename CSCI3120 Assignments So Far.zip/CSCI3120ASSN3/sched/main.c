#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>

#include "prioq.h"
#include "scheduler.h"
#include "pcb.h"

#define PACKET_SIZE 1500

struct cpu_io_cycle {
    unsigned cpu;
    unsigned io;
};

enum {NEW, READY, RUNNING, BLOCKED, TERMINATED};

struct process {
    struct pcb pcb;
    unsigned state;
    unsigned pid;
    unsigned arrival;
    unsigned bursts;
    struct cpu_io_cycle cycles[];
};

static int my_atoi(char *str) {
    long value = strtol(str, NULL, 10);
    if (value == 0 && errno == EINVAL) {
        printf("Invalid integer value in test script: %s", str);
        exit(1);
    }
    return (int)value;
}


static void generate_tests(int argc, char **argv) {
    if (argc < 4) {
        printf("Usage: %s <procs> <priorities> <bursts>\n", argv[0]);
        exit(1);
    }

    int n = my_atoi(argv[1]);
    int priorities = my_atoi(argv[2]);
    int bursts = my_atoi(argv[3]);
    unsigned pid = 1;

    printf("%d %d\n", priorities, n);
    unsigned long r = (unsigned long)random();
    for (unsigned long clock = 1; pid <= n;) {
        if (r < 0x200000) {
            r = (unsigned long)random();
        }

        clock += r & 1;
        r >>= 1;

        if ((r & 1) == 0) {
            r >>= 1;
            continue;
        }
        r >>= 1;

        unsigned priority = 0;
        if (priorities > 1) {
            priority = r % priorities;
        }
        r >>= 8;

        unsigned cycles = r % bursts + 1;
        r >>= 8;

        printf("%lu %u %u", clock, priority, cycles);

        for (int i = 0; i < cycles; i++) {
            if (r < 0x20) {
                r = (unsigned long)random();
            }
            unsigned cpu = (r & 7) + 1;
            r >>= 3;
            unsigned io = 5 * ((r & 3) + 1);
            r >>= 2;
            printf(" %u %u", cpu, io);
        }
        printf("\n");
        pid++;
    }
}

static void transition(unsigned current_time, struct process *p, int new_state) {
    static char *states[] = {"NEW", "READY", "RUNNING", "BLOCKED", "TERMINATED"};
    printf("%5.5u: proc %u[%u:%u:%u] %s -> %s\n", current_time, p->pid,
        p->pcb.priority, p->cycles[p->bursts].cpu, p->cycles[p->bursts].io,
        states[p->state], states[new_state]);
    p->state = new_state;
}

static prioq_t load_test_file(unsigned int *priorities) {
    int num_requests;
    if (scanf("%u %d", priorities, &num_requests) != 2) {
        printf("Input error, expecting number of priorities and number of requests.\n");
        exit(1);
    } else if (num_requests <= 0) {
        perror("load_test_file: invalid number of requests");
        exit(1);
    } else if (*priorities < 1) {
        perror("load_test_file: invalid priorities");
        exit(1);
    }

    prioq_t prioq = prioq_new();

    for (int i = 0; i < num_requests; i++) {
        unsigned arrival;
        unsigned priority;
        unsigned bursts;
        if (scanf("%u %u %u", &arrival, &priority, &bursts) != 3) {
            printf("Input error, expecting arrival time, priority, and number of bursts. line %d\n", i);
            exit(1);
        } else if (bursts < 1) {
            perror("load_test_file: process must have positive number of bursts");
            exit(1);
        }

        struct process *pcb = calloc(1, sizeof(struct process) + sizeof(struct cpu_io_cycle) * bursts);
        if (pcb == NULL) {
            perror("malloc: pcb allocation");
            exit(1);
        }

        pcb->pid = i + 1;
        pcb->state = NEW;
        pcb->arrival = arrival;
        pcb->pcb.priority = priority;
        pcb->pcb.process_info = pcb;
        pcb->bursts = bursts - 1;

        for (int b = (int)pcb->bursts; b >= 0; b--) {
            if (scanf("%u %u", &pcb->cycles[b].cpu, &pcb->cycles[b].io) != 2) {
                printf("Input error, expecting arrival time, operation, key, and value size. line %d\n", i);
                exit(1);
            }
        }

        prioq_insert(prioq, pcb, arrival);
    }
    return prioq;
}



int main(int argc, char **argv) {
    if (argc > 2) {
        srandom(time(NULL));
        generate_tests(argc, argv);
        exit(0);
    }

    unsigned int priorities;
    prioq_t prioq = load_test_file(&priorities);
    scheduler_init(priorities);

    struct process *current = NULL;
    int n = prioq_size(prioq);
    printf("Running...\n");
    for (int current_time = 0; n > 0; current_time++) {
        // Process runs on CPU
        if (current) {
            current->cycles[current->bursts].cpu--;
            if (current->cycles[current->bursts].cpu == 0) {
                if (current->bursts > 0) {
                    current->arrival = current_time + current->cycles[current->bursts].io;
                    transition(current_time, current, BLOCKED);
                    prioq_insert(prioq, current, current->arrival);
                    current->bursts--;
                } else {
                    transition(current_time, current, TERMINATED);
                    n--;
                }
                current = NULL;
            }
        }

        // Processes are admitted / readmitted and possibly preempted
        for (struct process *p = prioq_peek(prioq); p != NULL && p->arrival <= current_time; p = prioq_peek(prioq)) {
            prioq_remove(prioq);
            transition(current_time, p, READY);
            scheduler_insert(&p->pcb);

            // check if process is preempted
            if (current && current->pcb.priority > p->pcb.priority) {
                transition(current_time, current, READY);
                scheduler_insert(&current->pcb);
                current = NULL;
            }
        }

        if (current == NULL) {
            struct pcb *pcb = scheduler_next();
            if (pcb != NULL) {
                current = pcb->process_info;
                transition(current_time, current, RUNNING);
            }
        }

    }

    exit(0);
}