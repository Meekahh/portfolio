//
// Created by Alex Brodsky on 2026-09-17.
//

#ifndef SCHED_PRIOQ_H
#define SCHED_PRIOQ_H

typedef struct prioq *prioq_t;

prioq_t prioq_new(void);
void prioq_insert(prioq_t prioq, void *item, unsigned long priority);
void *prioq_remove(prioq_t prioq);
void *prioq_peek(prioq_t prioq);
int prioq_size(prioq_t prioq);

#endif //SCHED_PRIOQ_H
