//
// Created by Alex Brodsky on 2026-05-23.
//
#include "scheduler.h"
#include "deque.h"

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>


static deque_t *dequeues = NULL;
static unsigned int num_priorities = 0;

extern void scheduler_init(unsigned int priorities) {
    num_priorities = priorities;
    dequeues = malloc(priorities * sizeof(deque_t));
    for (int i = 0; i < priorities; i++) {
            // 16 just a random number since it gets doubled if it's too small
        dequeues[i] = deque_new(16);
    }
}

extern void scheduler_insert(pcb_t *request) {
    deque_push_back(dequeues[request->priority], request);
}

extern pcb_t *scheduler_next(void) {
    pcb_t *pcb = NULL;
    for (int i = 1; i < num_priorities; i++) {
        if (deque_size(dequeues[i]) > 0) {
            pcb = deque_pop_front(dequeues[i]);
            deque_push_back(dequeues[i-1], pcb);
        }
    }

    pcb = NULL;

    for (int i = 0; i < num_priorities; i++) {
        if (deque_size(dequeues[i]) > 0) {
            pcb = deque_pop_front(dequeues[i]);
            break;
        }
    }
    return pcb;
}