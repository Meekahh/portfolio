//
// Created by Alex Brodsky on 2026-09-17.
//

#include "prioq.h"

#include <stdio.h>
#include <stdlib.h>

struct node {
    struct node *next;
    void *item;
    unsigned long priority;
};

struct prioq {
    struct node *head;
    int size;
};

static struct node *free_list = NULL;

prioq_t prioq_new(void) {
    prioq_t prioq = calloc(1, sizeof(struct prioq));
    if (!prioq) {
        perror("malloc: allocating prioq");
        exit(1);
    }
    return prioq;
}

void prioq_insert(prioq_t prioq, void *item, unsigned long priority) {
    struct node *node;
    if (free_list) {
        node = free_list;
        free_list = free_list->next;
    } else {
        node = calloc(1, sizeof(struct node));
        if (!node) {
            perror("malloc: allocating node");
            exit(1);
        }
    }

    node->item = item;
    node->priority = priority;

    if (!prioq->head || prioq->head->priority > priority) {
        node->next = prioq->head;
        prioq->head = node;
    } else {
        struct node *curr = prioq->head;
        for ( ; curr->next && curr->next->priority <= priority; curr = curr->next);
        node->next = curr->next;
        curr->next = node;
    }

    prioq->size++;
}

void *prioq_remove(prioq_t prioq) {
    struct node *node = prioq->head;
    if (!node) {
        return NULL;
    }

    prioq->head = node->next;
    node->next = free_list;
    free_list = node;
    prioq->size--;
    return node->item;
}

void *prioq_peek(prioq_t prioq) {
    return prioq->head ? prioq->head->item : NULL;
}

int prioq_size(prioq_t prioq) {
    return prioq->size;
}