# Scheduler tests (test.00 – test.39)

Expected outputs were produced by running the reference solution (main.c, scheduler.c, deque.c, prioq.c)
and include the harness's leading "Running..." line.  Run: ./sched < test.XX.in | diff - test.XX.out

## 00–09: single process, different scheduler configurations
00 Q=1, arrives t=0, one burst            05 Q=5, lowest priority (4)
01 Q=1, three bursts (Example-1 style)    06 Q=10, lowest priority, four cycles
02 Q=2, 1 ms bursts, priority 0           07 Q=4, long CPU burst (100) and I/O (50)
03 Q=2, lowest queue                      08 Q=3, eight cycles of increasing length
04 Q=3, middle queue, late arrival        09 Q=100, priority 57, arrives t=1000

## 10–19: multiple processes, single queue (FCFS)
10 simultaneous arrivals                  15 15 processes at t=0 (deque grows past capacity 10)
11 idle gaps, no contention               16 mixed bursts, overlapping I/O
12 convoy effect (long job first)         17 random, 8 procs
13 two procs alternating CPU / I/O        18 random, 15 procs
14 arrival at the exact tick of finish    19 random, 30 procs, dense arrivals

## 20–39: multiple processes, multi-queue
20 priority order at same arrival         30 Q=10, sparse queues (9,7,5,3)
21 preemption on arrival                  31 two equal-priority procs vs one higher, 2 cycles each
22 preemption when process returns from I/O   32 random Q=2, 10 procs
23 three levels arriving in reverse order 33 random Q=3, 12 procs
24 equal priority does not preempt        34 random Q=4, 15 procs
25 aging across three levels              35 random Q=5, 20 procs
26 low-priority job vs stream of high     36 random Q=8, 20 procs
27 preemption cascade + aging order       37 random Q=3, 25 procs, only priorities 0 and 2
28 12 procs in lowest queue (deque growth)  38 random Q=6, 30 procs
29 Q=5 mixed arrivals, preemption and aging 39 random Q=4, 50 procs, 6 cycles max
