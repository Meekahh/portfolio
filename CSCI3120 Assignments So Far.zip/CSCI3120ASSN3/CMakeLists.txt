cmake_minimum_required(VERSION 3.25)
project(CSCI3120ASSN3 C)

set(CMAKE_C_STANDARD 11)

add_executable(CSCI3120ASSN3 main.c)
