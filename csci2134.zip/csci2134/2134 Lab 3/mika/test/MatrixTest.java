import org.junit.jupiter.api.Test;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

class MatrixTest {

    /**
     * Strings encoding different matrices for test cases.
     * Format is: "num_rows num_columns a b c ..."
     * where a, b, c are integers and there should be
     * num_rows*num_columns integers following num_columns.
     */
    static final String matrix1 = "2 2 1 2 3 4"; //[ 1 2 ]
                                                 //[ 3 4 ]
    static final String matrix2 = "2 3 1 2 3 4 5 6"; //[ 1 2 3 ]
                                                     //[ 4 5 6 ]

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the add function works as intended, with two matrices
     * of the same dimensions. Assuming the code works and only worried about input/output,
     * so this would be a black box test.
     */
    @Test
    void testAddSameDimensions() {
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(2, 2);
        Matrix res = new Matrix(2, 2);

        m1.setElem(1, 1, 1); m1.setElem(1, 2, 2);
        m1.setElem(2, 1, 3); m1.setElem(2, 2, 4);

        m2.setElem(1, 1, 1); m2.setElem(1, 2, 2);
        m2.setElem(2, 1, 3); m2.setElem(2, 2, 4);

            m1.add(m2, res);

        assertEquals(2, res.getElem(1, 1));
        assertEquals(4, res.getElem(1, 2));
        assertEquals(6, res.getElem(2, 1));
        assertEquals(8, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the add function properly nullifies the result matrix when
     * dealing with two input matrices of differing dimensions. Concerned about the
     * inner-workings of the code, and as such is a white box test.
     */
    @Test
    void testAddDiffDimensions() {
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(3, 2);
        Matrix res = new Matrix(2, 2);

        m1.setElem(1, 1, 1); m1.setElem(1, 2, 2);
        m1.setElem(2, 1, 3); m1.setElem(2, 2, 4);

        m2.setElem(1, 1, 1); m2.setElem(1, 2, 2);
        m2.setElem(2, 1, 3); m2.setElem(2, 2, 4);
        m2.setElem(3, 1, 5); m2.setElem(3, 2, 6);

            assertNull(m1.add(m2, res));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a scalar function works as intended
     * with a negative scalar. Assuming the code works and only worried about input/output,
     * so this would be a black box test.
     */
    @Test
    void testMultNegative() {
        Matrix m = new Matrix(2, 2);
        double s = -2;
        Matrix res = new Matrix(2, 2);

        m.setElem(1, 1, 1); m.setElem(1, 2, 2);
        m.setElem(2, 1, 3); m.setElem(2, 2, 4);

        m.multiplyWithScalar(s, res);

        assertEquals(-2, res.getElem(1, 1));
        assertEquals(-4, res.getElem(1, 2));
        assertEquals(-6, res.getElem(2, 1));
        assertEquals(-8, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a scalar function properly
     * zeroes out the resulting matrix when dealing with a scalar of zero.
     * Concerned about the inner-workings of the code, and as such is a white box test.
     */
    @Test
    void testMultZero() {
        Matrix m = new Matrix(2, 2);
        double s = 0;
        Matrix res = new Matrix(2, 2);

        m.setElem(1, 1, 1); m.setElem(1, 2, 2);
        m.setElem(2, 1, 3); m.setElem(2, 2, 4);

        m.multiplyWithScalar(s, res);

        assertEquals(0, res.getElem(1, 1));
        assertEquals(0, res.getElem(1, 2));
        assertEquals(0, res.getElem(2, 1));
        assertEquals(0, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a scalar function works as intended
     * with a positive scalar. Assuming the code works and only worried about input/output,
     * so this would be a black box test.
     */
    @Test
    void testMultPos() {
        Matrix m = new Matrix(2, 2);
        double s = 2;
        Matrix res = new Matrix(2, 2);

        m.setElem(1, 1, 1); m.setElem(1, 2, 2);
        m.setElem(2, 1, 3); m.setElem(2, 2, 4);

        m.multiplyWithScalar(s, res);

        assertEquals(2, res.getElem(1, 1));
        assertEquals(4, res.getElem(1, 2));
        assertEquals(6, res.getElem(2, 1));
        assertEquals(8, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a matrix function works as intended
     * with a positive matrix. Assuming the code works and only worried about input/output,
     * so this would be a black box test.
     */
    @Test
    void testMultMtxPos() {
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(2, 2);
        Matrix res = new Matrix(2, 2);

        m1.setElem(1, 1, 1); m1.setElem(1, 2, 2);
        m1.setElem(2, 1, 3); m1.setElem(2, 2, 4);

        m2.setElem(1, 1, 1); m2.setElem(1, 2, 2);
        m2.setElem(2, 1, 3); m2.setElem(2, 2, 4);

        m1.multiplyWithMatrix(m2, res);

        assertEquals(7, res.getElem(1, 1));
        assertEquals(10, res.getElem(1, 2));
        assertEquals(15, res.getElem(2, 1));
        assertEquals(22, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a matrix function properly
     * zeroes out the resulting matrix when multiplying with the zero matrix.
     * Concerned about the inner-workings of the code, and as such is a white box test.
     */
    @Test
    void testMultMtxZero() {
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(2, 2);
        Matrix res = new Matrix(2, 2);

        m1.setElem(1, 1, 1); m1.setElem(1, 2, 2);
        m1.setElem(2, 1, 3); m1.setElem(2, 2, 4);

        m2.setElem(1, 1, 0); m2.setElem(1, 2, 0);
        m2.setElem(2, 1, 0); m2.setElem(2, 2, 0);

        m1.multiplyWithMatrix(m2, res);

        assertEquals(0, res.getElem(1, 1));
        assertEquals(0, res.getElem(1, 2));
        assertEquals(0, res.getElem(2, 1));
        assertEquals(0, res.getElem(2, 2));
    }

    /**
     * @author Mika Molloy-Reilly
     * @description Tests if the multiplication with a matrix function works as intended
     * with a negative matrix. Assuming the code works and only worried about input/output,
     * so this would be a black box test.
     */
    @Test
    void testMultMtxNeg() {
        Matrix m1 = new Matrix(2, 2);
        Matrix m2 = new Matrix(2, 2);
        Matrix res = new Matrix(2, 2);

        m1.setElem(1, 1, 1); m1.setElem(1, 2, 2);
        m1.setElem(2, 1, 3); m1.setElem(2, 2, 4);

        m2.setElem(1, 1, -1); m2.setElem(1, 2, -2);
        m2.setElem(2, 1, -3); m2.setElem(2, 2, -4);

        m1.multiplyWithMatrix(m2, res);

        assertEquals(-7, res.getElem(1, 1));
        assertEquals(-10, res.getElem(1, 2));
        assertEquals(-15, res.getElem(2, 1));
        assertEquals(-22, res.getElem(2, 2));
    }

    @Test
    void testEquals() {
    }

    @Test
    void negate() {
    }

    @Test
    void add() {
    }

    @Test
    void multiplyWithScalar() {
    }

    @Test
    void multiplyWithMatrix() {
    }

    @Test
    void getElem() {
    }

    @Test
    void setElem() {
    }

    /**
     * Test getHeight() on a square matrix.
     * This is an example test.
     */
    @Test
    void getHeight_square() {
        Matrix M = new Matrix(new Scanner(matrix1));
        assertEquals(2, M.getHeight());
    }

    /**
     * Test getHeight() on a rectangular matrix.
     * This is an example test.
     */
    @Test
    void getHeight_wide() {
        Matrix M = new Matrix(new Scanner(matrix2));
        assertEquals(2, M.getHeight());
    }

    /**
     * Test getWidth() on a square matrix.
     * This is an example test.
     */
    @Test
    void getWidth_square() {
        Matrix M = new Matrix(new Scanner(matrix1));
        assertEquals(2, M.getHeight());
    }

    /**
     * Test getWidth() on a rectangular matrix.
     * This is an example test.
     */
    @Test
    void getWidth_wide() {
        Matrix M = new Matrix(new Scanner(matrix2));
        assertEquals(3, M.getWidth());
    }

}
