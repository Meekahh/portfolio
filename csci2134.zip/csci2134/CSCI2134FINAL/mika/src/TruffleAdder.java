public class TruffleAdder {

    public boolean hasTruffleCheck(float rand) {
        return rand < 0.5;
    }

    public boolean whiteTruffleCheck(float rand) {
        return rand < 0.1;
    }
}
