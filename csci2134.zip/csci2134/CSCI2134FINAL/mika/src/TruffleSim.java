import java.util.Random;

/**
 * A class containing the main method for running a truffle-hunting
 * simulation game between a dog and a hog.
 * Using command-line argument, construct a forest of a certain width and height,
 * counted by number of forest patches, and perform the specified number of rounds of the hunt.
 * At the end of the number of rounds, total the value of all the truffles found by either
 * the dog or the hog to determine an overall winner.
 * The winner is determined by the total value of the found truffles
 * and not the number of truffles found.
 */
public class TruffleSim {

    public static void main(String[] args) {
        int width = 10;
        int height = 10;
        int nRounds = 50;

        if (args.length > 0) {
            try {
                width = Integer.parseInt(args[0]);
            } catch (NumberFormatException nfe) {
                System.out.println("Could not use args[0] as it was not an integer: " + args[0]);
                System.out.printf("Defaulting to width: %d.\n", width);
            }
        }
        if (args.length > 1) {
            try {
                height = Integer.parseInt(args[1]);
            } catch (NumberFormatException nfe) {
                System.out.println("Could not use args[0] as it was not an integer: " + args[0]);
                System.out.printf("Defaulting to height: %d.\n", height);
            }
        }
        if (args.length > 2) {
            try {
                nRounds = Integer.parseInt(args[2]);
            } catch (NumberFormatException nfe) {
                System.out.println("Could not use args[2] as it was not an integer: " + args[2]);
                System.out.printf("Defaulting to %d rounds.\n", nRounds);
            }
        }

        Random r = new Random();
        int seed = r.nextInt();
        RandomNumber.init(seed);

        Forest truffleFarm = new Forest(width, height);
        TruffleDog dog = new TruffleDog();
        dog.setCurrentPatch(truffleFarm.getPatch(0,0));
        TruffleHog hog = new TruffleHog();
        hog.setCurrentPatch(truffleFarm.getPatch(0,0));
        for (int i = 0; i < nRounds; ++i) {
            dog.lookForTruffles();
            hog.lookForTruffles();
        }

        float dogTotal = dog.totalTruffleValue();
        int dogCount = dog.numTrufflesFound();
        float hogTotal = hog.totalTruffleValue();
        int hogCount = hog.numTrufflesFound();

        System.out.printf("The truffle hunt lasted for %d rounds.\n", nRounds);
        System.out.printf("The dog found %d truffles worth $%.2f.\n", dogCount, dogTotal);
        System.out.printf("The hog found %d truffles worth $%.2f.\n", hogCount, hogTotal);
        if (dogTotal > hogTotal) {
            System.out.println("The dog wins!");
        } else if (hogTotal > dogTotal) {
            System.out.println("The hog wins!");
        } else {
            System.out.println("The dog and hog tied.");
        }
    }
}
