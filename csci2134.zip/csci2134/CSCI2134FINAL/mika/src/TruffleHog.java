import java.util.ArrayList;

/**
 * A truffle-hunting pig (hog).
 * The hog searches slowly and methodically through a forest,
 * searching one patch of forest for each "round of the hunt".
 * In particular, the hog "sweeps" through the forest, moving from
 * west to east as far as possible, then east to west as far as possible, then repeating.
 * It moves one patch south whenever it reaches an edge of the forest.
 * It thus zigzags through the forest. With this slow pace, the hog
 * has a high success rate of finding a truffle, if one exists, at 75%
 */
public class TruffleHog {

    private float truffleChance;
    private ForestPatch currPatch;
    private ArrayList<Object> findings;
    private boolean movingEast;

    /**
     * Construct a truffle-hunting hog.
     * Their success rate of finding a truffle is 75%.
     */
    public TruffleHog() {
        truffleChance = 0.75f;
        findings = new ArrayList<>();
        movingEast = true;
    }

    /**
     * Set the ForestPatch the hog is currently within.
     * @param patch the ForestPatch
     */
    public void setCurrentPatch(ForestPatch patch) {
        currPatch = patch;
        if (patch == null) {
            throw new IllegalArgumentException("Patch must not be null.");
        }
    }

    /**
     * Perform one round of the truffle hunt and look for truffles.
     */
    public void lookForTruffles() {
        if (currPatch == null) {
            return;
        }

        Object shroom = currPatch.search(truffleChance);
        findTruffle(shroom);
        hogMovement();
    }

    public void hogMovement() {
        if (movingEast) {
            if (currPatch.getEastNeighbour() == null) {
                movingEast = false;
                currPatch = currPatch.getSouthNeighbour();

            } else {
                currPatch = currPatch.getEastNeighbour();
            }
        } else {
            if (currPatch.getWestNeighbour() == null) {
                movingEast = true;
                currPatch = currPatch.getSouthNeighbour();
            } else {
                currPatch = currPatch.getWestNeighbour();
            }
        }
    }
    /**
     * Add a found truffle to the collection of findings.
     * @param find the found object, should not be null
     */
    public void findTruffle(Object find) {
        if (find != null) {
            findings.add(find);
        }
    }

    /**
     * Get how many truffles have so far been found.
     * @return the number of truffles found
     */
    public int numTrufflesFound() {
        return findings.size();
    }

    /**
     * Get the total value of all truffles found.
     * @return the total value of all truffles.
     */
    public float totalTruffleValue() {
        TruffleValueCalculator calc = new TruffleValueCalculator();
        return calc.totalTruffleValue(findings);
    }
}

