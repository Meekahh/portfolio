import java.util.ArrayList;

/**
 * A truffle-hunting dog.
 * This dog searches randomly, and quickly, through several patches of forest
 * for each "round of the hunt".
 * In particular, the dog can search through three patches of forest per round,
 * with a 30% chance of finding a truffle in each patch, if one exists there.
 * If the dog gets to the edge of the forest
 * and tries to move out of the forest, they instead stay in their current patch.
 */
public class TruffleDog {

    private float truffleChance;
    private ForestPatch currPatch;
    private int moveSpeed;

    private ArrayList<Object> findings;

    /**
     * Construct a truffle-hunting dog.
     * Their success rate of finding a truffle is 30% and they
     * are able to search three patches of forest per "round"
     */
    public TruffleDog() {
        truffleChance = 0.3f;
        moveSpeed = 2;
        currPatch = null;
        findings = new ArrayList<>();
    }

    /**
     * Set the ForestPatch the dog is currently within.
     * @param patch the ForestPatch
     */
    public void setCurrentPatch(ForestPatch patch) {
        currPatch = patch;
    }

    /**
     * Perform one round of the truffle hunt and look for truffles.
     */
    public void lookForTruffles() {
        assert currPatch != null: "The patch currently being searched cannot be null.";
        for (int i = 0; i <= moveSpeed; ++i) {
            Object shroom = currPatch.search(truffleChance);
            findTruffle(shroom);

            int moveDirection = RandomNumber.nextInt();
            moveDirection %= 4;

            directionDecider(moveDirection);

        }
    }

    public void directionDecider(int moveDirection) {

        if (moveDirection == 0) {
            ForestPatch p = currPatch.getNorthNeighbour();
            if (p != null) {
                currPatch = p;
            }
        } else if (moveDirection == 1) {
            ForestPatch p = currPatch.getEastNeighbour();
            if (p != null) {
                currPatch = p;
            }
        } else if (moveDirection == 2) {
            ForestPatch p = currPatch.getSouthNeighbour();
            if (p != null) {
                currPatch = p;
            }
        } else if (moveDirection == 3) {
            ForestPatch p = currPatch.getWestNeighbour();
            if (p != null) {
                currPatch = p;
            }
        }
    }

    /**
     * Add a found truffle to the collection of findings.
     * @param find the found object, should not be null
     */
    public void findTruffle(Object find) {
        if (find != null) {
            findings.add(find);
        }
    }

    /**
     * Get how many truffles have so far been found.
     * @return the number of truffles found
     */
    public int numTrufflesFound() {
        return findings.size();
    }

    /**
     * Get the total value of all truffles found.
     * @return the total value of all truffles.
     */
    public float totalTruffleValue() {
        TruffleValueCalculator calc = new TruffleValueCalculator();
        return calc.totalTruffleValue(findings);
    }
}
