/**
 * A class representing a white truffle.
 */
public class WhiteTruffle {

    /**
     * Get the current market price of this truffle.
     * @return its price
     */
    public float getPrice() {
        return 500.00f;
    }
}
