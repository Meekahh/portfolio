import java.util.ArrayList;

public class TruffleValueCalculator {

    public float totalTruffleValue(ArrayList<Object> findings) {
        float total = 0.0f;
        for (int i = 0; i < findings.size(); ++i) {
            Object found = findings.get(i);
            if (found instanceof BlackTruffle) {
                total += ((BlackTruffle) found).getPrice();
            }
            else if (found instanceof WhiteTruffle) {
                total += ((WhiteTruffle) found).getPrice();
            }
            else {
                throw new IllegalStateException("Items of findings[] must either be BlackTruffle or WhiteTruffle.");
            }
        }
        return total;
    }
}
