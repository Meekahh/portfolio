public class ForestNeighbourHelper {
    public static void arrangeNeighbours(ForestPatch[][] grid, int width, int height) {
        //corners: NW, NE, SW, SE
        grid[0][0].setNeighbours(null, grid[1][0], grid[0][1], null);
        grid[width-1][0].setNeighbours(null, null, grid[width-1][1], grid[width-2][0]);
        grid[0][height-1].setNeighbours(grid[0][height-2], grid[1][height-1], null, null);
        grid[width-1][height-1].setNeighbours(grid[width-1][height-2], null, null, grid[width-2][height-1]);
        //north edge
        for (int i = 1; i < width-1; ++i) {
            grid[i][0].setNeighbours(null, grid[i+1][0], grid[i][1], grid[i-1][0]);
        }
        //south edge
        for (int i = 1; i < width-1; ++i) {
            grid[i][height-1].setNeighbours(grid[i][height-2], grid[i+1][height-1], null, grid[i-1][height-1]);
        }
        //east edge
        for(int j = 1; j < height-1; ++j) {
            grid[width-1][j].setNeighbours(grid[width-1][j-1], null, grid[width-1][j+1], grid[width-2][j]);
        }
        //west edge
        for(int j = 1; j < height-1; ++j) {
            grid[0][j].setNeighbours(grid[0][j-1], grid[1][j], grid[0][j+1], null);
        }
        //center patches
        for (int i = 1; i < width-1; ++i) {
            for (int j = 1; j < height-1; ++j) {
                grid[i][j].setNeighbours(grid[i][j-1], grid[i+1][j], grid[i][j+1], grid[i-1][j]);
            }
        }
    }
}
