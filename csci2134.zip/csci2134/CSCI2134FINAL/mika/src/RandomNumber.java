import java.util.Random;

/**
 * A class with static methods offering a common source of random numbers.
 * It is illegal to call any method in this class before first calling init().
 */
public class RandomNumber {

    private static Random rng;

    /**
     * Initialize the random number generation with a seed.
     * @param seed a seed value for the random number generator.
     */
    public static void init(int seed) {
        rng = new Random(seed);
    }

    /**
     * Get the next random number from this generator.
     * The returned number is between 0.0 (inclusive) and 1.0 (exclusive).
     * @return the randomly generated number.
     */
    public static float next() {
       return rng.nextFloat();
    }

    /**
     * Get the number random integer number from this generator.
     * The returned number is a positive integer between 0 (inclusive)
     * and Integer.MAX_VALUE (exclusive)
     * @return the randomly generated positive integer.
     */
    public static int nextInt() {
        return rng.nextInt(Integer.MAX_VALUE);
    }
}
