/**
 * A class representing a rectangular truffle-bearing forest.
 * It contains a grid of ForestPatch patches with
 * (0,0) being the north-west corner
 * and larger indices in the grid being more easterly and more southerly.
 */
public class Forest {
    private ForestPatch[][] grid;
    /**
     * Construct a square forest with a default number of 100 patches.
     */
    public Forest() {
        this(10,10);
    }
    /**
     * Construct a rectangular forest that is width patches wide (west to east)
     * and height patches long (north to south).
     * A forest must have a positive width and a positive height.
     * @param width the number of patches running west to east
     * @param height the number of patches running north to south
     */
    public Forest(int width, int height) {
        grid = new ForestPatch[width][height];
        for (int i = 0; i < width; ++i) {
            for (int j = 0; j < height; ++j) {
                grid[i][j] = new ForestPatch(i, j);
            }
        }

        ForestNeighbourHelper.arrangeNeighbours(grid, width, height);
    }
    /**
     * Get a ForestPatch by its position in the forest.
     * Position (0,0) is the north-west corner with
     * larger values being more easterly and more southerly.
     * @param x: the west to east index of the patch
     * @param y: the north to south index of the patch.
     * @return the patch at index (x,y) within this forest.
     */
    public ForestPatch getPatch(int x, int y) {
        return grid[x][y];
    }
}
