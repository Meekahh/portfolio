/**
 * A class representing a black truffle.
 */
public class BlackTruffle {

    /**
     * Get the current market price of this truffle.
     * @return its price
     */
    public float getPrice() {
        return 100.00f;
    }
}
