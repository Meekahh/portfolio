/**
 * A part or "patch" within a larger forest.
 * A patch of forest may contain at most one truffle.
 * It may be a black truffle or a rare white truffle.
 * There is a 50% chance that a patch of forest contains a truffle,
 * and, if it does, there is a 20% chance for that truffle to be white.
 */
public class ForestPatch {

    private ForestPatch[] neighbours;
    private boolean hasTruffle;
    private boolean whiteTruffle;
    int x;
    int y;

    /**
     * Construct a new patch of forest at position (xpos,ypos)
     * within its larger forest.
     * Larger x values are more east.
     * Larger y values are more south.
     * @param xpos
     * @param ypos
     */
    public ForestPatch(int xpos, int ypos) {

        if (xpos < 0 || ypos < 0) {
            throw new IllegalArgumentException("X and Y positions for the patch cannot be negative.");
        }

        x = xpos;
        y = ypos;
        neighbours = new ForestPatch[4]; //north, east, south, west
        hasTruffle = false;
        whiteTruffle = false;

        float rand = RandomNumber.next();
        TruffleAdder truffleAdder = new TruffleAdder();
            hasTruffle = truffleAdder.hasTruffleCheck(rand);
            whiteTruffle = truffleAdder.whiteTruffleCheck(rand);
        }

    /**
     * Search this patch of a forest for a truffle.
     * @param successChance the chance of successfully finding something, if it exists
     * @return the found object, or null if nothing is found
     */
    public Object search(float successChance) {
        Object ret = null;
        if (RandomNumber.next() < successChance) {
            if (hasTruffle) {
                hasTruffle = false;
                if (whiteTruffle) {
                    ret = new WhiteTruffle();
                } else {
                    ret = new BlackTruffle();
                }
            }
        }
        return ret;
    }

    /**
     * Set the adjacent patches of forest to this one.
     * A null value indicates that there is no further forest in that direction.
     * @param north the patch of forest to the north
     * @param east the patch of forest to the east
     * @param south the patch of forest to the south
     * @param west the patch of forest to the west
     */
    public void setNeighbours(ForestPatch north, ForestPatch east, ForestPatch south, ForestPatch west) {
        ForestPatch[] neighbourArray = {north, east, south, west};
        for (int i = 0; i < neighbourArray.length; i++) {
            setNeighbour(neighbourArray[i], i);
        }
    }

    /**
     * Set the neighbouring forest patch by index.
     * North: 0, East: 1, South: 2, West: 3.
     * @param patch the adjacent ForestPatch
     * @param idx the index representing the direction of the neighbouring patch
     */
    private void setNeighbour(ForestPatch patch, int idx) {
        neighbours[idx] = patch;
    }

    /**
     * Get the ForestPatch to the north of this patch
     * @return the neighbouring patch, or null if there is no more forest to the north.
     */
    public ForestPatch getNorthNeighbour() {
        return getNeighbour(0);
    }

    /**
     * Get the ForestPatch to the east of this patch
     * @return the neighbouring patch, or null if there is no more forest to the east.
     */
    public ForestPatch getEastNeighbour() {
        return getNeighbour(1);
    }

    /**
     * Get the ForestPatch to the south of this patch
     * @return the neighbouring patch, or null if there is no more forest to the south.
     */
    public ForestPatch getSouthNeighbour() {
        return getNeighbour(2);
    }

    /**
     * Get the ForestPatch to the west of this patch
     * @return the neighbouring patch, or null if there is no more forest to the west.
     */
    public ForestPatch getWestNeighbour() {
        return getNeighbour(3);
    }

    /**
     * Get the neighbouring forest patch by index.
     * North: 0, East: 1, South: 2, West: 3.
     * @param idx the index representing the direction of the neighbouring patch
     * @return the neighbouring patch, or null if there is no more forest in the specified direction.
     */
    public ForestPatch getNeighbour(int idx) {
        return neighbours[idx];
    }

}
