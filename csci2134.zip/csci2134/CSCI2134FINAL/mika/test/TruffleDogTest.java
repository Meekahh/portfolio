import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TruffleDogTest {

    @Test
    void numTrufflesFound() {
        TruffleDog dog = new TruffleDog();
        assertEquals(0, dog.numTrufflesFound(), "TruffleDog should not have found any truffles by default.");
    }

    @Test
    void findTruffle_case1() {
        TruffleDog dog = new TruffleDog();
        dog.findTruffle(new BlackTruffle());
        assertEquals(1, dog.numTrufflesFound(), "TruffleDog should have found 1 truffle.");
    }

    @Test
    void findTruffle_case2() {
        TruffleDog dog = new TruffleDog();
        dog.findTruffle(new WhiteTruffle());
        assertEquals(1, dog.numTrufflesFound(), "TruffleDog should have found 1 truffle.");
    }


    @Test
    void truffleValue() {
        TruffleDog dog = new TruffleDog();
        WhiteTruffle wt = new WhiteTruffle();
        dog.findTruffle(wt);
        assertEquals(wt.getPrice(), dog.totalTruffleValue(), "Dog's truffle value should equal 1 white truffle's price.");
    }

    @Test
    void findingsEntries() {
        TruffleDog dog = new TruffleDog();
        dog.findTruffle(null);
        assertEquals(0, dog.numTrufflesFound(), "Dog should not have found a truffle.");
    }




}