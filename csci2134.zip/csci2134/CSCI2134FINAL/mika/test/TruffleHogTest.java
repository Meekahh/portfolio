import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Executable;

class TruffleHogTest {

    @Test
    void numTrufflesFound() {
        TruffleHog hog = new TruffleHog();
        assertEquals(0, hog.numTrufflesFound(), "TruffleHog should not have found any truffles by default.");
    }

    @Test
    void findTruffle_case1() {
        TruffleHog hog = new TruffleHog();
        hog.findTruffle(new BlackTruffle());
        assertEquals(1, hog.numTrufflesFound(), "TruffleHog should have found 1 truffle.");
    }

    @Test
    void findTruffle_case2() {
        TruffleHog hog = new TruffleHog();
        hog.findTruffle(new WhiteTruffle());
        assertEquals(1, hog.numTrufflesFound(), "TruffleHog should have found 1 truffle.");
    }

    @Test
    void truffleValue() {
        TruffleHog hog = new TruffleHog();
        WhiteTruffle wt = new WhiteTruffle();
        hog.findTruffle(wt);
        assertEquals(wt.getPrice(), hog.totalTruffleValue(), "Hog's truffle value should equal 1 white truffle's price.");
    }

    @Test
    void findingsEntries() {
        TruffleHog hog = new TruffleHog();
        hog.findTruffle(null);
        assertEquals(0, hog.numTrufflesFound(), "Dog should not have found a truffle.");
    }

    @Test
    void truffleValueBlack() {
        TruffleHog hog = new TruffleHog();
        BlackTruffle bt = new BlackTruffle();
        hog.findTruffle(bt);
        assertEquals(bt.getPrice(), hog.totalTruffleValue(), "Hog's truffle value should equal 1 white truffle's price.");
    }

    @Test
    void nullPatch() {
        TruffleHog hog = new TruffleHog();
        assertThrows(IllegalArgumentException.class, () -> hog.setCurrentPatch(null), "Null patch should throw " +
                "an Illegal Arg. Exception.");
    }

}