import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComponentTests {

    @Test
    void componentTest0() {
        assertTrue(true, "Yay I compile!");
    }

    @Test
    void componentTest1() {
        int rounds = 10;
        int dogTruffles = 4;
        RandomNumber.init(0);

        Forest forest = new Forest(5, 5);
        TruffleDog dog = new TruffleDog();
        dog.setCurrentPatch(forest.getPatch(0,0));
        for (int i = 0; i < rounds; ++i) {
            dog.lookForTruffles();
        }

        assertEquals(dogTruffles, dog.numTrufflesFound(), "After 10 rounds, dog should have found 4 truffles.");
    }

    @Test
    void componentTest2() {
        int rounds = 10;
        int hogTruffles = 4;
        RandomNumber.init(0);

        Forest forest = new Forest(5, 5);
        TruffleHog hog = new TruffleHog();
        hog.setCurrentPatch(forest.getPatch(0,0));
        for (int i = 0; i < rounds; ++i) {
            hog.lookForTruffles();
        }

        assertEquals(hogTruffles, hog.numTrufflesFound(), "After 10 rounds, hog should have found 4 truffles.");
    }

    @Test
    void componentTest3() {
        int rounds = 20;
        int dogTruffles = 4;
        int hogTruffles = 4;
        RandomNumber.init(100);

        Forest forest = new Forest(10, 10);
        TruffleDog dog = new TruffleDog();
        dog.setCurrentPatch(forest.getPatch(0,0));
        TruffleHog hog = new TruffleHog();
        hog.setCurrentPatch(forest.getPatch(0,0));
        for (int i = 0; i < rounds; ++i) {
            dog.lookForTruffles();
            hog.lookForTruffles();
        }

        assertEquals(dogTruffles, dog.numTrufflesFound(), "After 20 rounds, dog should have found 4 truffles.");
        assertEquals(hogTruffles, hog.numTrufflesFound(), "After 20 rounds, hog should have found 4 truffles.");
    }

    @Test
    void componentTest4() {
        int rounds = 50;
        int dogTruffles = 8;
        float dogValue = 800.0f;
        int hogTruffles = 14;
        float hogValue = 3000.0f;
        RandomNumber.init(100);

        Forest forest = new Forest(10, 10);
        TruffleDog dog = new TruffleDog();
        dog.setCurrentPatch(forest.getPatch(0,0));
        TruffleHog hog = new TruffleHog();
        hog.setCurrentPatch(forest.getPatch(0,0));
        for (int i = 0; i < rounds; ++i) {
            dog.lookForTruffles();
            hog.lookForTruffles();
        }

        assertEquals(hogTruffles, hog.numTrufflesFound(), "After 50 rounds, hog should have found 14 truffles.");
        assertEquals(dogTruffles, dog.numTrufflesFound(), "After 50 rounds, dog should have found 8 truffles.");

        assertEquals(hogValue, hog.totalTruffleValue(), "After 50 rounds, hog's truffle value should total 3000.");
        assertEquals(dogValue, dog.totalTruffleValue(), "After 50 rounds, dog's truffle value should total 800.");

    }

}
