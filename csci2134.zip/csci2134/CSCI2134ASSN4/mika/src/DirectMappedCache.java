public class DirectMappedCache extends Cache {

    /**
     * Create a new Cache with a positive capacity and backing store
     * as a file located at filePath.
     *
     * @param capacity a positive integer capacity of the cache
     * @param filePath the file path to the file acting as backing store.
     */
    public DirectMappedCache(int capacity, String filePath) {
        super(capacity, filePath);
    }

    /**
     * Caclulates the incoming key modulo the capacity
     * @param inKey the incoming key to be installed
     * @return the key modulo capacity
     */
    @Override
    protected int findEvictCandidate(int inKey) {
        return (inKey % this.capacity);
    }

    /**
     * Finds the data in the cache with the same key as the incoming key modulo the capacity, and removes it
     * @param inKey the incoming key to be installed
     * @return the index that was replaced
     */
    @Override
    public int evictData(int inKey) {
        int index = findEvictCandidate(inKey);
        this.data[index] = null;
        return index;
    }

    /**
     * Installs new data into the cache, removing any data in the way.
     * @param key  the key of the data to install in the cache.
     * @param data the data to install in the cache.
     * @param time amount of time to complete procedures relating to this data entry
     * @return the index of the new entry
     */
    @Override
    protected int installData(int key, int data, float time) {
        int insertIndex = -1;
        if (this.size >= this.capacity) {
            insertIndex = evictData(key);
        }

        if (insertIndex < 0) {
            insertIndex = (key % this.capacity);
        }

        this.data[insertIndex] = new CacheItem(key, data, time);
        this.size++;
        return insertIndex;
    }
}
