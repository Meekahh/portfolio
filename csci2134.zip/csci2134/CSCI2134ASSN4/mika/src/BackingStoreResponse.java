public class BackingStoreResponse {

    private int data;
    private float time;

    public BackingStoreResponse(int data, float time) {
        this.data = data;
        this.time = time;
    }

        // Getters and Setters
    public int getData() {return data;}
    public float getTime() {return time;}

    public void setData(int data) {this.data = data;}
   public void setTime(float time) {this.time = time;}
}
