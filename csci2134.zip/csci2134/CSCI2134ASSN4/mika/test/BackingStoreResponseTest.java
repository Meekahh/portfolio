import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BackingStoreResponseTest {

    @Test
    void getTime() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 1));
        assertEquals(1, br.getTime());
    }

    @Test
    void getTime_Empty() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 0));
        assertEquals(0, br.getTime());
    }

    @Test
    void setTime() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 0));
        br.setTime(1);
        assertEquals(1, br.getTime());
    }

    @Test
    void setTime_Empty() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 1));
        br.setTime(0);
        assertEquals(0, br.getTime());
    }

    @Test
    void getData() {
        BackingStoreResponse br = (new BackingStoreResponse(1, 0));
        assertEquals(1, br.getData());
    }
    @Test
    void getData_Empty() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 0));
        assertEquals(0, br.getData());
    }

    @Test
    void setData() {
        BackingStoreResponse br = (new BackingStoreResponse(0, 0));
        br.setData(1);
        assertEquals(1, br.getData());
    }

    @Test
    void setData_Empty() {
        BackingStoreResponse br = (new BackingStoreResponse(1, 0));
        br.setData(0);
        assertEquals(0, br.getData());
    }
}
