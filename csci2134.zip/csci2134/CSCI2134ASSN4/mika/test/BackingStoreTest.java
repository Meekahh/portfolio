import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import static org.junit.jupiter.api.Assertions.*;

class BackingStoreTest {

    // ---- From CacheTest.java ----
    static String testFile = "tests.txt";

    void prepareTestFile() {
        File fp = new File(testFile);
        try {
            if (!fp.exists()) {
                fp.createNewFile();
            }
            PrintWriter pw = new PrintWriter(fp);
            for (int i = 0; i < 10; i++) {
                pw.println(Integer.toString(i) + " " + Integer.toString(i));
            }
            pw.close();
        } catch (IOException e) {
            fail();
        }
    }
    // ---- From CacheTest.java ----

    // Extra method for deleting the file so that I can do empty fetchData tests etc.
    void removeTestFile() {
        File file = new File(testFile);
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    void getName() {
        Cache cache = new Cache(5, testFile);
        assertEquals("tests.txt", cache.backingStore.getName());
    }

    @Test
    void getName_Empty() {
        Cache cache = new Cache(5, null);
        assertNull(cache.backingStore.getName());
    }

    @Test
    void setName() {
        Cache cache = new Cache(5, testFile);
        cache.backingStore.setName("changedName");
        assertEquals("changedName", cache.backingStore.getName());
    }

    @Test
    void setName_Empty() {
        Cache cache = new Cache(5, testFile);
        cache.backingStore.setName(null);
        assertNull(cache.backingStore.getName());
    }

    @Test
    void fetchData() throws NotFoundException {
        prepareTestFile();
        Cache cache = new Cache(5, testFile);
        assertEquals(1, cache.backingStore.fetchData(1).getData());
        assertEquals(2, cache.backingStore.fetchData(2).getData());
        assertEquals(3, cache.backingStore.fetchData(3).getData());
        assertEquals(4, cache.backingStore.fetchData(4).getData());
        assertEquals(5, cache.backingStore.fetchData(5).getData());
        removeTestFile();
    }

    @Test
    void fetchData_Empty() throws NotFoundException {
        removeTestFile();
        Cache cache = new Cache(5, testFile);
        try {
            cache.backingStore.fetchData(1);
            fail("NFE not thrown");
        } catch (NotFoundException e) {
            // Passed, since the NFE was thrown
            assertTrue(true);
        }
    }

    @Test
    void fetchData_BadKey() throws NotFoundException {
        prepareTestFile();
        Cache cache = new Cache(5, testFile);
        try {
            cache.backingStore.fetchData(10);
            fail("NFE not thrown");
        } catch (NotFoundException e) {
                // Passed, since the NFE was thrown
            assertTrue(true);
        }
        removeTestFile();
    }

    @Test
    void pushData() throws NotFoundException {
        prepareTestFile();
        Cache cache = new Cache(5, testFile);
        assertEquals(1, cache.backingStore.fetchData(1).getData());
        cache.backingStore.pushData(1, 5);
        assertEquals(5, cache.backingStore.fetchData(1).getData());
        removeTestFile();
    }

    @Test
    void pushData_FromEmpty() throws NotFoundException {
        removeTestFile();
        Cache cache = new Cache(5, testFile);
        try {
            cache.backingStore.pushData(1, 1);
            fail("NFE not thrown");
        } catch (NotFoundException e) {
                // Passed, since the NFE was thrown
            assertTrue(true);
        }
    }
}
