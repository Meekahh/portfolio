    import org.junit.jupiter.api.Test;
    import static org.junit.jupiter.api.Assertions.*;

    class CacheResponseTest {

        @Test
        void getMiss_False() {
            CacheResponse cr = new CacheResponse(new CacheItem(1,123, 0), false, 0);
            assertFalse(cr.getMiss());
        }

        @Test
        void getMiss_True() {
            CacheResponse cr = new CacheResponse(new CacheItem(1,123, 0), true, 0);
            assertTrue(cr.getMiss());
        }

        @Test
        void setMiss_FalseToTrue() {
            CacheResponse cr = new CacheResponse(new CacheItem(1,123, 0), false, 0);
            cr.setMiss(true);
            assertTrue(cr.getMiss());
        }

        @Test
        void setMiss_TrueToFalse() {
            CacheResponse cr = new CacheResponse(new CacheItem(1,123, 0), true, 0);
            cr.setMiss(false);
            assertFalse(cr.getMiss());
        }

        @Test
        void getData() {
            CacheResponse cr = new CacheResponse(new CacheItem(1,123, 0), true, 0);
            CacheItem test = new CacheItem(1,123, 0);
            CacheItem ci = cr.getData();
            assertEquals(test.getKey(), ci.getKey(), "Keys do not match for a CacheItem in CacheResponse.");
            assertEquals(test.getData(), ci.getData(), "Data does not match for a CacheItem in CacheResponse.");
        }
    }