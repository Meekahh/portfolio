import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import static org.junit.jupiter.api.Assertions.*;

public class DirectMappedCacheTest {

        // ---- From CacheTest.java ----
    static String testFile = "tests.txt";

    void prepareTestFile() {
        File fp = new File(testFile);
        try {
            if (!fp.exists()) {
                fp.createNewFile();
            }
            PrintWriter pw = new PrintWriter(fp);
            for (int i = 0; i < 10; i++) {
                pw.println(Integer.toString(i) + " " + Integer.toString(i));
            }
            pw.close();
        } catch (IOException e) {
            fail();
        }
    }
        // ---- From CacheTest.java ----

        // Extra method for deleting the file so that I can do empty file tests etc.
    void removeTestFile() {
        File file = new File(testFile);
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    void findEvictCandidate() {
        prepareTestFile();
        Cache cache = new DirectMappedCache(2, testFile);
        assertEquals(1, cache.findEvictCandidate(3));
        removeTestFile();
    }

    @Test
    void evictData() throws NotFoundException {
        Cache cache = new DirectMappedCache(2, testFile);
        cache.installData(0, 1, 0);
        cache.evictData(0);
        try {
            cache.backingStore.fetchData(0).getData();
            fail("NFE not thrown");
        } catch (NotFoundException e) {
                // Passes, since NFE is thrown
            assertTrue(true);
        }
    }

    @Test
    void evictData_Empty() throws NotFoundException {
        Cache cache = new DirectMappedCache(2, testFile);
        cache.evictData(0);
        try {
            cache.backingStore.fetchData(0);
            fail("NFE not thrown");
        } catch (NotFoundException e) {
                // Passes, since the NFE is thrown
            assertTrue(true);
        }
    }

    @Test
    void installData_FromEmpty() {
        Cache cache = new DirectMappedCache(2, testFile);
        cache.installData(1, 1, 0);
        assertEquals(1, cache.findEvictCandidate(3));
    }

    @Test
    void installData_FromFull() {
        prepareTestFile();
        Cache cache = new DirectMappedCache(2, testFile);
        cache.installData(1, 5, 0);
            // Shouldn't change if it's already full
        assertEquals(1, cache.findEvictCandidate(3));
        removeTestFile();
    }
}