# A1

In IntelliJ, open the folder containing this README (that is, the main folder of the Assignment 1 repository) as a project. 
This repo and its contents are exactly the file structure for an IntelliJ project. 

Find the most up to date instructions on our Brightspace site: Content > Assignments > Assignment 1  
