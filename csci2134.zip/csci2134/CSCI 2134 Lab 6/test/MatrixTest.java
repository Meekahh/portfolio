/**
 *  File: MatrixTester.java
 *  Author: Alex Brodsky
 *  Date: October 1, 2019
 *  Purpose: CSCI 2134, Lab 4
 *
 *  Description: This class implements Matrix objects for manipulating matrices.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.InputMismatchException;
import java.util.Scanner;

class MatrixTest {
    private final static String simpleMatrix = "2 2 1 2 3 4"; // [ 1 2 ]
    // [ 3 4 ]
    private final static String nonSqMatrix = "3 2 1 2 3 4 5 6"; // [ 1 2 ]
    // [ 3 4 ]

    @Test
    void getElemBasicTest() {
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        assertEquals(2, m.getElem(1,2),
                "getElem() did not return correct value");
    }

    @Test
    void getElem_IndexOutOfBounds() {
        /* Example test for throwing exceptions
         */
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        try {
            m.getElem(0, 0);
            fail("getElem() should have thrown Exception");
        } catch (IndexOutOfBoundsException e) {
            assertEquals(e.getMessage(), "i = 0, j = 0");
        }
    }

    @Test
    void setElem() {
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        try {
            m.setElem(0, 0, 0);
            fail("getElem() should have thrown Exception");
        } catch (IndexOutOfBoundsException e) {
            assertEquals(e.getMessage(), "i = 0, j = 0");
        }
        m.setElem(2, 1, 5);
        assertEquals(5, m.getElem(2,1),
                "setElem() may not have set correct value");
    }

    @Test
    void negate() {
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        m.negate();
        assertEquals(-1, m.getElem(1,1),
                "negate() did not negate element (1,1)");
        assertEquals(-2, m.getElem(1,2),
                "negate() did not negate element (1,2)");
        assertEquals(-3, m.getElem(2,1),
                "negate() did not negate element (2,1)");
        assertEquals(-4, m.getElem(2,2),
                "negate() did not negate element (2,2)");
    }

    @Test
    void add() {
        Matrix test1 = new Matrix(new Scanner(simpleMatrix));
        Matrix test2res = new Matrix(2, 2);
        try {
            test1.add(null, test2res);
            fail("Should have thrown NullPointerException since b is null.");
        } catch (NullPointerException e) {
            assertEquals("Matrices cannot be null for addition.", e.getMessage());
        }
        try {
            test1.add(test1, null);
            fail("Should have thrown NullPointerException since res is null.");
        } catch (NullPointerException e) {
            assertEquals("Matrices cannot be null for addition.", e.getMessage());
        }

        Matrix test3 = new Matrix(2, 2);
        Matrix test4 = new Matrix(3, 2);
        try {
            test3.add(test4, test2res);
            fail("Should have thrown InputMismatchExpcetion since input matrices are different sizes.");
        } catch (InputMismatchException e) {
            assertEquals("Matrices are different sizes.", e.getMessage());
        }

    Matrix m = new Matrix(new Scanner(simpleMatrix));
    Matrix n = new Matrix(new Scanner(simpleMatrix));
    Matrix res = new Matrix(2, 2);
        n.negate();
        m.add(n, res);
        assertEquals(0, res.getElem(1,1),
                "add() did not add element (1,1))");
        assertEquals(0, res.getElem(1,2),
                "add() did not add element (1,2)");
        assertEquals(0, res.getElem(2,1),
                "add() did not add element (2,1)");
        assertEquals(0, res.getElem(2,2),
                "add() did not add element (2,2)");
    }

    @Test
    void equals() {
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        Matrix n = new Matrix(m);
        assertTrue(m.equals(n), "equals() has a false negative");
    }

    @Test
    void equal2s() {
        Matrix m = new Matrix(new Scanner(simpleMatrix));
        Matrix n = new Matrix(m);
        n.negate();
        assertFalse(m.equals(n), "equals() has a false positive");
    }

    @Test
    void multiplyWithScalar() {
        Matrix test1 = new Matrix(2, 2);
        try {
            test1.multiplyWithScalar(2, null);
            fail("Should have thrown NullPointerException since res was null");
        } catch (NullPointerException e) {
            assertEquals("Result matrix can't be null for multiplication", e.getMessage());
        }

        Matrix test2 = new Matrix(3, 2);
        try {
            test1.multiplyWithScalar(2, test2);
            fail("multiplyWithScalar() should have thrown InputMismatchException for size mismatch.");
        } catch (InputMismatchException e) {
            assertEquals("Input matrix and result matrix are different sizes.", e.getMessage());
        }

        Matrix m = new Matrix(new Scanner(simpleMatrix));
        Matrix n = new Matrix(m);
        Matrix res = new Matrix(m);
        n.negate();
        m.multiplyWithScalar(-1, res);
        assertTrue(res.equals(n), "matrix not scaled by -1");
    }

    @Test
    void multiplyWithMatrix() {
        Matrix test1 = new Matrix(2, 2);
        try {
            test1.multiplyWithMatrix(null, test1);
            fail("multiplyWithMatrix() should have thrown NullPointerException for null b.");
        } catch (NullPointerException e) {
            assertEquals("Matrices cannot be null for multiplication.", e.getMessage());
        }
        try {
            test1.multiplyWithMatrix(test1, null);
            fail("multiplyWithMatrix() should have thrown NullPointerException for null res.");
        } catch (NullPointerException e) {
            assertEquals("Matrices cannot be null for multiplication.", e.getMessage());
        }

        Matrix test2 = new Matrix(2, 2);
        Matrix test3 = new Matrix(3, 3);
        Matrix test4res = new Matrix(2, 2);
        try {
            test2.multiplyWithMatrix(test3, test4res);
            fail("multiplyWithMatrix() should have thrown InputMismatchException for size mismatch.");
        } catch (InputMismatchException e) {
            assertEquals("Input matrices and/or result matrix are improperly sized.", e.getMessage());
        }

        Matrix m = new Matrix(new Scanner(simpleMatrix));
        Matrix n = new Matrix(m);
        Matrix res = new Matrix(m);
        m.multiplyWithMatrix(n, res);
        assertEquals(7, res.getElem(1,1),
                "matrix multiplication failed on element (1,1))");
        assertEquals(10, res.getElem(1,2),
                "matrix multiplication failed on element (1,2))");
        assertEquals(15, res.getElem(2,1),
                "matrix multiplication failed on element (2,1))");
        assertEquals(22, res.getElem(2,2),
                "matrix multiplication failed on element (2,2))");
    }

    @Test
    void getHeight() {
        Matrix m = new Matrix(new Scanner(nonSqMatrix));
        assertEquals(3, m.getHeight(),
                "getHeight() did not return correct height");
    }

    @Test
    void getWidth() {
        Matrix m = new Matrix(new Scanner(nonSqMatrix));
        assertEquals(2, m.getWidth(),
                "getWidth() did not return correct width");
    }
}