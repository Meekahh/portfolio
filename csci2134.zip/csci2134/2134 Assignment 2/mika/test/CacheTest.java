    import static org.junit.jupiter.api.Assertions.*;
    import org.junit.jupiter.api.Test;

    import java.io.*;
    import java.util.ArrayList;

    class CacheTest {

        static String ex1File = "example1.txt";

        void prepareExample1() {
            File fp = new File(ex1File);
            try {
                if (!fp.exists()) {
                    fp.createNewFile();
                }
                PrintWriter pw = new PrintWriter(fp);
                for (int i = 0; i < 10; i++) {
                    pw.println(Integer.toString(i) + " " + Integer.toString(i));
                }
                pw.close();
            } catch (IOException e) {
                fail();
            }
        }

        Cache getEmptyCache_Ex1() {
            prepareExample1();
            Cache cache = new Cache(4, ex1File);
            return cache;
        }

        Cache getPartiallyFullCache_Ex1() {
            prepareExample1();
            Cache cache = new Cache(4, ex1File);
            try {
                cache.requestData(1);
                cache.requestData(2);
            } catch (NotFoundException e) {
                fail("Data was not found in the backing store but should be.");
            }
            return cache;
        }

        Cache getFullCache_Ex1() {
            prepareExample1();
            Cache cache = new Cache(4, ex1File);
            try {
                cache.requestData(1);
                cache.requestData(2);
                cache.requestData(3);
                cache.requestData(4);
            } catch (NotFoundException e) {
                fail("Data was not found in the backing store but should be.");
            }
            return cache;
        }

        @Test
        void getCapacity_test1() {
            prepareExample1();
            Cache cache = new Cache(4, ex1File);
            assertEquals(4, cache.getCapacity(), "Cache capacity should be 4.");
        }

        @Test
        void getCapacity_test2() {
            prepareExample1();
            Cache cache = new Cache(128, ex1File);
            assertEquals(128, cache.getCapacity(), "Cache capacity should be 128.");
        }

        @Test
        void reset_empty() {
            Cache cache = getEmptyCache_Ex1();
            cache.reset();
            assertEquals(0, cache.getSize(), "Cache should be empty after reset.");
        }

        @Test
        void reset_partiallyFull() {
            Cache cache = getPartiallyFullCache_Ex1();
            cache.reset();
            assertEquals(0, cache.getSize(), "Cache should be empty after reset.");
        }

        @Test
        void reset_full() {
            Cache cache = getFullCache_Ex1();
            cache.reset();
            assertEquals(0, cache.getSize(), "Cache should be empty after reset.");
        }

        @Test
        void getSize() {
                // Check size when cache is full
            Cache cache = new Cache(10, null);
            for (int i = 1; i <= cache.getCapacity(); i++) {
                cache.installData(i, i);
            }

            assertEquals(10, cache.getSize(), "Cache size should be 10.");

                // Check size when cache has data, but isn't full
            Cache cache2 = new Cache(5, null);
            cache2.installData(1, 1);
            assertEquals(1, cache2.getSize(), "Cache size should be 1.");

                // Check size when cache is emptied after eviction of data
            Cache cache3 = new Cache(1, null);
            cache3.installData(1, 1);
            cache3.evictData(1);
            assertEquals(0, cache3.getSize(), "Cache size should be 0.");

                // Check size when cache is overflowed
            Cache cache4 = new Cache(1, null);
            cache4.installData(1, 1);
            cache4.installData(2, 2);
            assertEquals(1, cache4.getSize(), "Cache size should still be 1, since that's max capacity.");

                // Check size when cache is empty
            Cache cache5 = new Cache(1, null);
            assertEquals(0, cache5.getSize(), "Cache size should be 0.");
        }

        @Test
        void findData() {
                // Create a cache and fill it with values
            Cache cache = new Cache(4, null);
            cache.installData(1, 1);
            cache.installData(2, 5);
            cache.installData(4, 10);

                // Check that the index of the entered values can be found
            assertEquals(0, cache.findData(1), "Returned index should be 0.");
            assertEquals(1, cache.findData(2), "Returned index should be 1.");
            assertEquals(2, cache.findData(4), "Returned index should be 2.");

                // Check that the method properly returns -1 when given an invalid key
            assertEquals(-1, cache.findData(3), "Returned value should be -1, since there is no value at this key.");

                // Check that the method properly deals with negatives
            assertEquals(-1, cache.findData(-5), "Returned value should be -1 (impossible index).");
        }

        @Test
        void getRank() {
            Cache cache = new Cache(2, null);
            cache.installData(1, 1);
            cache.installData(5, 5);
            cache.findData(5);
            cache.findData(1);

                // Checks if cache properly updates ranks after finding data
            assertEquals(0, cache.getRank(1), "Rank should be 0.");
            assertEquals(1, cache.getRank(5), "Rank should be 1.");
        }

        @Test
        void evictData() {
                // Create cache and fill with values
            Cache cache = new Cache(2, null);
            cache.installData(1, 1);
            cache.installData(2, 5);

                // Access a value to cause other value to be least recently used
            cache.findData(1);

                // Check to see if index of evicted data is properly printed
            assertEquals(1, cache.evictData(3), "Index of evicted data should be 1.");
        }

        @Test
        void getContents() {
                // Create a Cache to test with
            Cache cache = new Cache(2, null);
            cache.installData(1, 1);
            cache.installData(2, 5);

                // Create the expected output as a list to compare with
            ArrayList<CacheItem> expectedList = new ArrayList<>();
            expectedList.add(0, new CacheItem(1, 1));
            expectedList.add(1, new CacheItem(2, 5));

                // Convert test Cache into a list
            ArrayList<CacheItem> actualList = cache.getContents();

                // Compare each list item with each-other
            for (int i = 0; i < expectedList.size(); i++) {
                CacheItem expected = expectedList.get(i);
                CacheItem actual = actualList.get(i);

                    // Check to make sure each value and key of the lists match
                assertTrue(expected.getKey() == actual.getKey() && expected.getData() == actual.getData(),
                        "Contents at index " + i + " should match.");
            }
        }

        @Test
        void fetchData() throws NotFoundException {

                // Create cache using example1.txt
            Cache cache = new Cache(10,"example1.txt");

                // Check that each value was properly initialized
                    /*  I'd like to note here that key 0 was causing a NotFoundException, and I could not tell if that was
                        one of the bugs or not, so I just removed it for these tests. If that was one of the bugs, I am aware
                        of it but am not including it here so the other tests can be shown, since there's a chance it's just my machine.
                     */
            assertEquals(1, cache.fetchData(1), "Returned value should be 1");
            assertEquals(2, cache.fetchData(2), "Returned value should be 2");
            assertEquals(3, cache.fetchData(3), "Returned value should be 3");
            assertEquals(4, cache.fetchData(4), "Returned value should be 4");
            assertEquals(5, cache.fetchData(5), "Returned value should be 5");
            assertEquals(6, cache.fetchData(6), "Returned value should be 6");
            assertEquals(7, cache.fetchData(7), "Returned value should be 7");
            assertEquals(8, cache.fetchData(8), "Returned value should be 8");
            assertEquals(9, cache.fetchData(9), "Returned value should be 9");

                // Check that NotFoundException is thrown for an incorrect key
            assertThrows(NotFoundException.class, () -> cache.fetchData(11), "Should throw NotFoundException for missing key.");

                // Check to make sure NullPointerException is thrown with a null filepath
            Cache cacheNull = new Cache(2, null);
            assertThrows(NullPointerException.class, () -> cacheNull.fetchData(1), "Cache should throw a NullPointerException when filepath is Null.");

        }
    }