import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

class CacheSimTest {

    static String ex1File = "example1.txt";

    void prepareExample1() {
        File fp = new File(ex1File);
        try {
            if (!fp.exists()) {
                fp.createNewFile();
            }
            PrintWriter pw = new PrintWriter(fp);
            for (int i = 0; i < 10; i++) {
                pw.println(Integer.toString(i) + " " + Integer.toString(i));
            }
            pw.close();
        } catch (IOException e) {
            fail();
        }
    }

    @Test
    void reset() {
            // Create test Cache
        prepareExample1();
        CacheSim cacheSim = new CacheSim(9, ex1File); // Capacity 9 for example1.txt entries

            // Record cache accesses (3 misses)
        int[] keys = {1, 2, 3};
        cacheSim.simulate(keys);

            // Check that the 3 misses were recorded
        assertEquals(3, cacheSim.getCacheMisses(), "There should be 3 cache misses before reset.");

            // Reset the cache and check that the history is now reset
        cacheSim.reset();
        assertTrue(cacheSim.getCacheHistory().isEmpty(), "Cache history should be empty after reset.");
    }

    @Test
    void getCacheMisses() {

            // Create test Cache
        prepareExample1();
        CacheSim cacheSim = new CacheSim(9, ex1File); // Capacity 9 for example1.txt entries

            // Simulate some cache requests, which should all be misses at first.
        int[] keys = {1, 2, 3, 4};
        cacheSim.simulate(keys);

            // Check the number of cache misses is one
        assertEquals(4, cacheSim.getCacheMisses(), "There should be 1 cache miss after the initial requests.");

            // Reset the cache and simulate. Should result in 3 misses with the resetted cache.
        cacheSim.reset();
        int[] keys2 = {1, 2, 3};
        cacheSim.simulate(keys2);

            // Check the number of cache misses again
        assertEquals(3, cacheSim.getCacheMisses(), "There should be 3 cache misses after reset.");
    }


    @Test
    void cacheToString() {
            // Create test Cache
        prepareExample1();
        CacheSim cacheSim = new CacheSim(8, ex1File); // Capacity 8 to test eviction later

            // Check that the Cache starts off empty
        String expected0 = "() () () () () () () ()";
        assertEquals(expected0, cacheSim.cacheToString(), "Cache should be empty");

            // Put some data into the cache
        int[] keys = {1, 2, 3, 4};
        cacheSim.simulate(keys);

            // Check the cache after adding data
        String expected1 = "(1,1) (2,2) (3,3) (4,4) () () () ()";
        assertEquals(expected1, cacheSim.cacheToString(), "Cache should contain keys 1, 2, 3, and 4.");

            // Fill the rest of the Cache
        int[] newKeys = {5, 6, 7, 8};
        cacheSim.simulate(newKeys);

            // Check cache again
        String expected2 = "(1,1) (2,2) (3,3) (4,4) (5,5) (6,6) (7,7) (8,8)";
        assertEquals(expected2, cacheSim.cacheToString(), "Cache should be full with entries 1 through 8");

            // Test how it works with eviction
        int[] lastKey = {9};
        cacheSim.simulate(lastKey);

            // Check cache one last time
        String expected3 = "(9,9) (2,2) (3,3) (4,4) (5,5) (6,6) (7,7) (8,8)";
        assertEquals(expected3, cacheSim.cacheToString(), "Cache should be the same as previous, with the 1 entry swapped for 9's");
    }


}