import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * A class representing an elven toy workshop.
 * Elves love making toys and eating cookies.
 *
 * In this workshop, maker elves process raw goods to make materials.
 * Using those materials, builder elves build toys.
 * Each "round" of work in the workshop consists of
 * maker elves making materials and adding them to a queue,
 * and builder elves taking materials from the queue to build a toy.
 * Maker elves always make the material with highest energy cost
 * that they have sufficient energy to make.
 * During each round, each elf can perform at most one action.
 *
 * As long as every elf in the workshop has energy, materials and toys
 * are produced during each "round" of work in the workshop.
 * If even one elf has no energy at the start of a round of work,
 * all elves skip work for that round and instead have a break together
 * to eat cookies and gain energy.
 */
public class Workshop {

    public ArrayList<BuilderElf> builders;
    public ArrayList<MakerElf> makers;
    public Queue<Object> materials;
    public ArrayList<Train> trains;
    public ArrayList<StuffedAnimal> animals;

    /**
     * Create a new elven Workshop with a certain number of
     * resident makers and builders.
     * There must be at least one maker and one builder in a Workshop.
     * @param numMakers: the number of MakerElfs in the workshop.
     * @param numBuilders: the number of BuilderElfs in the workshop.
     */
    public Workshop(int numMakers, int numBuilders) {
        makers = new ArrayList<>();
        for (int i = 0; i < numBuilders; ++i) {
            makers.add(new MakerElf());
        }
        builders = new ArrayList<>();
        for (int i = 0; i < numMakers; ++i) {
            builders.add(new BuilderElf());
        }

        materials = new LinkedList<>();
        trains = new ArrayList<>();
        animals = new ArrayList<>();
    }

    /**
     * Perform a round of work in the Workshop.
     *
     * Depending on the energy levels of the resident elves,
     * certain materials and toys may be made.
     * If there is insufficient energy among the elves,
     * they take a communal break instead.
     */
    public void nextRound() {
        boolean b = false;
        for (int i = 0; i < makers.size(); i++) {
            int e = makers.get(i).getEnergy();
            if (e <= 0) {
                b = true;
            }
        }
        for (int i = 0; i < builders.size(); i++) {
            int e = builders.get(i).getEnergy();
            if (e <= 0) {
                b = true;
            }
        }
        if (b) {
            breakTime();
            return;
        }

        for (int i = 0; i < makers.size(); i++) {
            MakerElf elf = makers.get(i);
            if (elf.getEnergy() >= 2) {
                materials.add(elf.chopWood());
            } else {
                materials.add(elf.weaveCotton());
            }
        }
        for (int i = 0; i < builders.size(); i++) {
            BuilderElf elf = builders.get(i);
            if (materials.isEmpty()) {
                elf.relax();
            } else {
                Object material = materials.peek();
                materials.remove();
                if (material instanceof Wood) {
                    trains.add(elf.build((Wood) material));
                } else if (material instanceof Cotton) {
                    animals.add(elf.build((Cotton) material));
                }
            }
        }
    }

    /**
     * Get the total number of toys built to far in this workshop.
     * @return the number of toys built.
     */
    public int buildCount() {
        return trains.size() + animals.size();
    }

    /**
     * Get the number of materials made in the workshop
     * which have not yet been transformed into toys.
     * @return the current number of materials in this workshop.
     */
    public int materialCount() {
        return materials.size();
    }

    /**
     * Initiate a communal break of the resident elves.
     * Every elf has a cookie break to gain energy to make more toys.
     */
    public void breakTime() {
        for (MakerElf maker : makers) {
            maker.cookieBreak();
        }
        for (BuilderElf builder : builders) {
            builder.cookieBreak();
        }
    }
}
