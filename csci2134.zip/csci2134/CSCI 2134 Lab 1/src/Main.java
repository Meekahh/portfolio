#!/usr/bin/python

from __future__ import print_function
import sys, string, tokenize, copy, re, types
        from collections import namedtuple

singletons = { '!', '&', '|', '*', '+', '-', '/', ',',
        '(', ')', '[', ']', '{', '}', '=', '<', '>', '#' }
        literals = { 'true', 'false', 'nil' }
        keywords = { 'let', 'letrec', 'def', 'set', 'lambda', 'if', 'elseif', 'else',
        'guard', 'raise', 'catch' }
        reserved = set().union(singletons, literals, keywords)
        ok_sexpr = { '!', '-', '(', '[', 'true', 'false', 'nil' }

        print_rules = "-r" in sys.argv
        verbose = "-v" in sys.argv


class Str(str):
        pass


class ScanError(Exception):
        def __init__(self, msg, tok):
        self.msg = msg
        self.tok = tok

        def __str__(self):
        return repr(self.msg)


        def reStr(s, t):
        r = Str(s)
        r.line = t.line
        r.col = t.col
        return r


        def char_generator(program):
        line = 1
        col = 0
        for b in program:
        c = Str(b);
        col = col + 1
        if c == '\n':
        line = line + 1
        col = 0

        c.line = line
        c.col = col
        yield c;

        c = Str("")
        c.line = line
        c.col = col
        yield c